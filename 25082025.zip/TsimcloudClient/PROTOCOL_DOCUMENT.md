# TSIM Cloud Client Protocol Document

## Overview

The TSIM Cloud Client is an Android application that acts as a gateway between mobile devices and a central server for SMS, MMS, USSD, and alarm management. This document describes the communication protocols, data structures, and system architecture.

## System Architecture

### Components

1. **Android Client (TSIM Cloud Client)**
   - MainActivity: User interface and configuration
   - SmsGatewayService: Background service for SMS/MMS/USSD handling
   - WebSocketClient: Real-time communication with server
   - SmsQueueManager: Local queue management for delivery reports and logs
   - SmsDatabase: SQLite database for persistent storage

2. **Server (Backend)**
   - WebSocket server for real-time communication
   - SMS retry management
   - Device management and monitoring
   - User authentication and authorization

## Communication Protocol

### WebSocket Connection

#### Connection URL Format
```
ws://host:port/ws/device/{imei}?api_key={api_key}
wss://host:port/ws/device/{imei}?api_key={api_key}
```

#### Authentication
- **Parameter**: `api_key` - Unique API key for device authentication
- **IMEI**: Device identifier (uses first SIM card's IMEI)

#### Connection Lifecycle
1. **Connect**: Client establishes WebSocket connection
2. **Authentication**: Server validates API key and IMEI
3. **Heartbeat**: Client sends heartbeat every 10 seconds
4. **Reconnection**: Automatic reconnection with exponential backoff

### Message Format

All messages follow this JSON structure:
```json
{
  "type": "message_type",
  "timestamp": 1234567890,
  "data": {
    // Message-specific data
  }
}
```

## Message Types

### 1. Device Status Messages

#### Device Status Update
```json
{
  "type": "device_status",
  "timestamp": 1234567890,
  "data": {
    "status": "online|offline|error",
    "device_group": "group_name",
    "country_site": "site_name",
    "details": {
      // Additional status information
    }
  }
}
```

#### Heartbeat
```json
{
  "type": "heartbeat",
  "timestamp": 1234567890,
  "data": {
    "device_id": "imei",
    "battery_level": 85,
    "signal_strength": -65,
    "network_type": "4G",
    "sim_status": "ready"
  }
}
```

### 2. SMS Messages

#### SMS Send Command (Server → Client)
```json
{
  "type": "send_sms",
  "timestamp": 1234567890,
  "data": {
    "phone_number": "+1234567890",
    "message": "Hello World",
    "sim_slot": 1,
    "message_id": "msg_123456"
  }
}
```

#### SMS Status Response (Client → Server)
```json
{
  "type": "sms_status",
  "timestamp": 1234567890,
  "data": {
    "message_id": "msg_123456",
    "phone_number": "+1234567890",
    "sim_slot": 1,
    "status": "SENT|FAILED|DELIVERED",
    "error_code": null,
    "error_message": null
  }
}
```

#### SMS Delivery Report (Client → Server)
```json
{
  "type": "delivery_report",
  "timestamp": 1234567890,
  "data": {
    "sms_id": "msg_123456",
    "phone_number": "+1234567890",
    "sim_slot": 1,
    "delivery_status": "delivered|failed",
    "delivery_time": 1234567890,
    "failure_reason": null,
    "sent_time": 1234567890
  }
}
```

### 3. MMS Messages

#### MMS Send Command (Server → Client)
```json
{
  "type": "send_mms",
  "timestamp": 1234567890,
  "data": {
    "phone_number": "+1234567890",
    "subject": "MMS Subject",
    "text": "MMS Text Content",
    "attachments": [
      {
        "type": "image|video|audio",
        "url": "https://example.com/file.jpg",
        "filename": "image.jpg"
      }
    ],
    "sim_slot": 1,
    "message_id": "mms_123456"
  }
}
```

#### MMS Status Response (Client → Server)
```json
{
  "type": "mms_status",
  "timestamp": 1234567890,
  "data": {
    "message_id": "mms_123456",
    "phone_number": "+1234567890",
    "sim_slot": 1,
    "status": "SENT|FAILED|DELIVERED",
    "error_code": null,
    "error_message": null
  }
}
```

### 4. USSD Messages

#### USSD Send Command (Server → Client)
```json
{
  "type": "send_ussd",
  "timestamp": 1234567890,
  "data": {
    "ussd_code": "*100#",
    "sim_slot": 1,
    "session_id": "ussd_123456",
    "message_id": "msg_123456"
  }
}
```

#### USSD Response (Client → Server)
```json
{
  "type": "ussd_response",
  "timestamp": 1234567890,
  "data": {
    "ussd_code": "*100#",
    "response": "Balance: $50.00",
    "session_id": "ussd_123456",
    "message_id": "msg_123456",
    "sim_slot": 1,
    "status": "SUCCESS|FAILED"
  }
}
```

#### USSD Log (Client → Server)
```json
{
  "type": "ussd_log",
  "timestamp": 1234567890,
  "data": {
    "ussd_code": "*100#",
    "response": "Balance: $50.00",
    "session_id": "ussd_123456",
    "message_id": "msg_123456",
    "sim_slot": 1,
    "log_type": "request|response|error",
    "log_time": 1234567890
  }
}
```

### 5. Alarm Messages

#### Alarm Command (Server → Client)
```json
{
  "type": "alarm_command",
  "timestamp": 1234567890,
  "data": {
    "alarm_type": "find_device|test_alarm|custom",
    "duration": 30000,
    "message": "Find my device",
    "message_id": "alarm_123456"
  }
}
```

#### Alarm Status Response (Client → Server)
```json
{
  "type": "alarm_status",
  "timestamp": 1234567890,
  "data": {
    "alarm_type": "find_device",
    "status": "STARTED|STOPPED|FAILED",
    "message_id": "alarm_123456",
    "error_message": null
  }
}
```

#### Alarm Log (Client → Server)
```json
{
  "type": "alarm_log",
  "timestamp": 1234567890,
  "data": {
    "alarm_type": "find_device",
    "alarm_message": "Find my device",
    "alarm_severity": "info|warning|error",
    "alarm_time": 1234567890
  }
}
```

### 6. Device Management Messages

#### Find Device Command (Server → Client)
```json
{
  "type": "find_device",
  "timestamp": 1234567890,
  "data": {
    "message_id": "find_123456",
    "duration": 30000
  }
}
```

#### Find Device Response (Client → Server)
```json
{
  "type": "find_device_response",
  "timestamp": 1234567890,
  "data": {
    "message_id": "find_123456",
    "status": "STARTED|FAILED",
    "duration": 30000,
    "error_message": null
  }
}
```

### 7. Configuration Messages

#### Settings Update (Server → Client)
```json
{
  "type": "connection_established",
  "timestamp": 1234567890,
  "data": {
    "settings": {
      "enable_battery_alarms": true,
      "enable_error_alarms": true,
      "enable_offline_alarms": true,
      "enable_signal_alarms": true,
      "enable_sim_balance_alarms": true,
      "auto_disable_sim_on_alarm": false
    }
  }
}
```

## Local Queue System

### Database Schema

#### Delivery Reports Queue
```sql
CREATE TABLE delivery_reports_queue (
    report_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sms_id TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    sim_slot INTEGER NOT NULL,
    delivery_status TEXT NOT NULL,
    delivery_time INTEGER,
    failure_reason TEXT,
    sent_time INTEGER NOT NULL,
    is_sent_to_server INTEGER DEFAULT 0,
    server_sent_time INTEGER
);
```

#### USSD Logs Queue
```sql
CREATE TABLE ussd_logs_queue (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    ussd_code TEXT NOT NULL,
    response TEXT,
    session_id TEXT NOT NULL,
    message_id TEXT NOT NULL,
    sim_slot INTEGER NOT NULL,
    log_type TEXT NOT NULL,
    log_time INTEGER NOT NULL,
    is_sent_to_server INTEGER DEFAULT 0,
    server_sent_time INTEGER
);
```

#### Alarm Logs Queue
```sql
CREATE TABLE alarm_logs_queue (
    alarm_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alarm_type TEXT NOT NULL,
    alarm_message TEXT NOT NULL,
    alarm_severity TEXT NOT NULL,
    alarm_time INTEGER NOT NULL,
    is_sent_to_server INTEGER DEFAULT 0,
    server_sent_time INTEGER
);
```

### Queue Processing

- **Delivery Reports**: Processed every 60 seconds
- **USSD Logs**: Processed every 30 seconds
- **Alarm Logs**: Processed every 15 seconds
- **Cleanup**: Old records removed every hour (30 days retention)

## Error Handling

### Connection Errors
- **Reconnection**: Automatic with exponential backoff (10s, 20s, 40s, 80s, 160s)
- **Max Attempts**: 5 reconnection attempts before stopping
- **Error Logging**: All connection errors logged locally

### Message Errors
- **Invalid Format**: Logged and ignored
- **Missing Fields**: Logged with warning
- **Service Errors**: Retried with exponential backoff

### Queue Errors
- **Database Errors**: Logged and retried
- **Network Errors**: Messages remain in queue for retry
- **Server Errors**: Messages marked for retry

## Security

### Authentication
- **API Key**: Required for all connections
- **IMEI Validation**: Server validates device IMEI
- **Session Management**: WebSocket session validation

### Data Protection
- **Local Storage**: SQLite database with encryption
- **Network**: WebSocket over TLS (WSS)
- **Sensitive Data**: Phone numbers and messages encrypted

## Configuration

### QR Code Configuration
```json
{
  "websocket_url": "wss://server.example.com/ws",
  "api_key": "device_api_key_here",
  "device_group": "group_name",
  "country_site": "site_name"
}
```

### Settings
- **Battery Alarms**: Enable/disable low battery alerts
- **Error Alarms**: Enable/disable error notifications
- **Offline Alarms**: Enable/disable offline alerts
- **Signal Alarms**: Enable/disable poor signal alerts
- **SIM Balance Alarms**: Enable/disable low balance alerts
- **Auto Disable SIM**: Automatically disable SIM on alarm

## Status Codes

### SMS Status Codes
- `SENT`: Message sent successfully
- `FAILED`: Message failed to send
- `DELIVERED`: Message delivered to recipient
- `PENDING`: Message pending delivery

### Alarm Status Codes
- `STARTED`: Alarm started successfully
- `STOPPED`: Alarm stopped successfully
- `FAILED`: Alarm failed to start/stop
- `ACTIVE`: Alarm currently active

### Connection Status Codes
- `CONNECTED`: WebSocket connected
- `DISCONNECTED`: WebSocket disconnected
- `RECONNECTING`: Attempting to reconnect
- `ERROR`: Connection error

## Version History

### v1.0.0
- Initial implementation
- Basic SMS/MMS/USSD functionality
- WebSocket communication
- Local queue system
- Alarm system
- QR code configuration

## Future Enhancements

### Planned Features
1. **RCS Support**: Rich Communication Services
2. **Multi-Device Support**: Multiple devices per account
3. **Advanced Analytics**: Detailed usage statistics
4. **Push Notifications**: Real-time notifications
5. **Offline Mode**: Enhanced offline functionality
6. **API Rate Limiting**: Server-side rate limiting
7. **Message Encryption**: End-to-end encryption
8. **Voice Calls**: Voice call management
9. **Location Services**: GPS tracking
10. **Remote Control**: Remote device control

### Technical Improvements
1. **Protocol Versioning**: Version-aware communication
2. **Compression**: Message compression for efficiency
3. **Caching**: Intelligent message caching
4. **Load Balancing**: Server load balancing
5. **Monitoring**: Enhanced system monitoring
6. **Logging**: Structured logging system
7. **Testing**: Comprehensive test suite
8. **Documentation**: API documentation
9. **SDK**: Client SDK for third-party integration
10. **Webhooks**: Webhook support for events 