package com.tsimcloud.tsimcloudclient

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import com.tsimcloud.tsimcloudclient.utils.UssdUtils

class DialerActivity : Activity() {
    
    companion object {
        private const val TAG = "DialerActivity"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        Log.d(TAG, "DialerActivity created with intent: ${intent?.action}")
        
        // Handle the dialer intent
        handleDialerIntent()
        
        // Close this activity immediately
        finish()
    }
    
    private fun handleDialerIntent() {
        val data = intent?.data
        val action = intent?.action
        
        Log.d(TAG, "Handling dialer intent: action=$action, data=$data")
        
        when (action) {
            Intent.ACTION_DIAL -> {
                // Handle dial action
                if (data != null) {
                    val phoneNumber = data.schemeSpecificPart
                    Log.d(TAG, "Dialing number: $phoneNumber")
                    
                    // Check if it's a USSD code
                    if (UssdUtils.isValidUssdCode(phoneNumber)) {
                        Log.d(TAG, "USSD code detected: $phoneNumber")
                        // Send USSD via service
                        val serviceIntent = Intent(this, SmsGatewayService::class.java)
                        serviceIntent.action = SmsGatewayService.ACTION_SEND_USSD
                        serviceIntent.putExtra("ussd_code", UssdUtils.formatUssdCode(phoneNumber))
                        serviceIntent.putExtra("sim_slot", 1)
                        startService(serviceIntent)
                    } else {
                        // Regular phone number - redirect to default dialer
                        val dialIntent = Intent(Intent.ACTION_DIAL, data)
                        startActivity(dialIntent)
                    }
                } else {
                    // No number provided - open dialer
                    val dialIntent = Intent(Intent.ACTION_DIAL)
                    startActivity(dialIntent)
                }
            }
            
            Intent.ACTION_CALL -> {
                // Handle call action
                if (data != null) {
                    val phoneNumber = data.schemeSpecificPart
                    Log.d(TAG, "Calling number: $phoneNumber")
                    
                    // Check if it's a USSD code
                    if (UssdUtils.isValidUssdCode(phoneNumber)) {
                        Log.d(TAG, "USSD code detected: $phoneNumber")
                        // Send USSD via service
                        val serviceIntent = Intent(this, SmsGatewayService::class.java)
                        serviceIntent.action = SmsGatewayService.ACTION_SEND_USSD
                        serviceIntent.putExtra("ussd_code", UssdUtils.formatUssdCode(phoneNumber))
                        serviceIntent.putExtra("sim_slot", 1)
                        startService(serviceIntent)
                    } else {
                        // Regular phone number - redirect to default dialer
                        val callIntent = Intent(Intent.ACTION_DIAL, data)
                        startActivity(callIntent)
                    }
                }
            }
            
            "android.intent.action.CALL_BUTTON" -> {
                // Handle call button action
                Log.d(TAG, "Call button pressed")
                val dialIntent = Intent(Intent.ACTION_DIAL)
                startActivity(dialIntent)
            }
            
            "android.intent.action.CALL_PRIVILEGED" -> {
                // Handle privileged call action
                if (data != null) {
                    val phoneNumber = data.schemeSpecificPart
                    Log.d(TAG, "Privileged call to: $phoneNumber")
                    
                    // Check if it's a USSD code
                    if (UssdUtils.isValidUssdCode(phoneNumber)) {
                        Log.d(TAG, "USSD code detected: $phoneNumber")
                        // Send USSD via service
                        val serviceIntent = Intent(this, SmsGatewayService::class.java)
                        serviceIntent.action = SmsGatewayService.ACTION_SEND_USSD
                        serviceIntent.putExtra("ussd_code", UssdUtils.formatUssdCode(phoneNumber))
                        serviceIntent.putExtra("sim_slot", 1)
                        startService(serviceIntent)
                    } else {
                        // Regular phone number - redirect to default dialer
                        val callIntent = Intent(Intent.ACTION_DIAL, data)
                        startActivity(callIntent)
                    }
                }
            }
            
            else -> {
                Log.w(TAG, "Unknown action: $action")
                // Redirect to main activity
                val mainIntent = Intent(this, MainActivity::class.java)
                startActivity(mainIntent)
            }
        }
    }
} 