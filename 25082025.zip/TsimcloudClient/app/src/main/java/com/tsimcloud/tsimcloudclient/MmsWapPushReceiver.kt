package com.tsimcloud.tsimcloudclient

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.tsimcloud.tsimcloudclient.utils.MmsPart
import com.tsimcloud.tsimcloudclient.utils.PreferencesManager
import com.tsimcloud.tsimcloudclient.utils.QrConfigManager
import com.tsimcloud.tsimcloudclient.utils.SmsMessageHandler
import com.tsimcloud.tsimcloudclient.utils.WebSocketClient
import java.io.ByteArrayInputStream
import java.io.IOException
import javax.mail.Session
import javax.mail.internet.MimeMessage
import javax.mail.Multipart

class MmsWapPushReceiver : BroadcastReceiver() {
    
    companion object {
        private const val TAG = "MmsWapPushReceiver"
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION -> {
                val mimeType = intent.type
                if (mimeType != null && mimeType.equals("application/vnd.wap.mms-message", ignoreCase = true)) {
                    handleMmsMessage(context, intent)
                }
            }
        }
    }
    
    private fun handleMmsMessage(context: Context, intent: Intent) {
        try {
            val qrConfigManager = QrConfigManager(context)
            
            // Check if device is configured
            if (!qrConfigManager.isDeviceConfigured()) {
                Log.w(TAG, "Device not configured, ignoring MMS")
                return
            }
            
            val data = intent.getByteArrayExtra("data")
            if (data != null) {
                // Parse MMS message
                val mmsData = parseMmsMessage(data)
                
                // Initialize WebSocket client if needed
                val config = qrConfigManager.getCurrentConfig()
                if (config != null) {
                    val deviceInfo = com.tsimcloud.tsimcloudclient.utils.DeviceInfo(context)
                    val webSocketClient = WebSocketClient(
                        context,
                        config.websocketUrl,
                        config.apiKey,
                        deviceInfo
                    )
                    
                    val preferencesManager = PreferencesManager(context)
                    val smsHandler = SmsMessageHandler(
                        context,
                        webSocketClient,
                        deviceInfo,
                        preferencesManager
                    )
                    
                    // Handle MMS
                    smsHandler.handleMmsMessage(
                        mmsData.sender,
                        mmsData.subject,
                        mmsData.parts,
                        mmsData.simSlot
                    )
                    
                    // Cleanup
                    webSocketClient.cleanup()
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling MMS message", e)
        }
    }
    
    private fun parseMmsMessage(data: ByteArray): MmsData {
        return try {
            val session = Session.getDefaultInstance(null)
            val inputStream = ByteArrayInputStream(data)
            val mimeMessage = MimeMessage(session, inputStream)
            
            val sender = mimeMessage.from?.firstOrNull()?.toString() ?: "Unknown"
            val subject = mimeMessage.subject ?: "No Subject"
            val parts = mutableListOf<MmsPart>()
            
            // Parse MMS parts
            val multipart = mimeMessage.content as? Multipart
            if (multipart != null) {
                for (i in 0 until multipart.count) {
                    val bodyPart = multipart.getBodyPart(i)
                    val contentType = bodyPart.contentType
                    val contentId = bodyPart.getHeader("Content-ID")?.firstOrNull() ?: ""
                    val fileName = bodyPart.fileName
                    val dataSize = bodyPart.size
                    
                    parts.add(MmsPart(contentType, contentId, fileName, dataSize))
                }
            }
            
            // Default to SIM1 for MMS (could be enhanced to detect SIM slot)
            val simSlot = 1
            
            MmsData(sender, subject, parts, simSlot)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing MMS message", e)
            MmsData("Unknown", "Error parsing MMS", emptyList(), 1)
        }
    }
    
    /**
     * Data class for MMS message
     */
    private data class MmsData(
        val sender: String,
        val subject: String,
        val parts: List<MmsPart>,
        val simSlot: Int
    )
}
