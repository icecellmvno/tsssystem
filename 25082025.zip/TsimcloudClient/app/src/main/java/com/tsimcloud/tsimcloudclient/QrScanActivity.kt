package com.tsimcloud.tsimcloudclient

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.camera.core.ExperimentalGetImage
import androidx.core.content.ContextCompat
import com.google.common.util.concurrent.ListenableFuture
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.tsimcloud.tsimcloudclient.utils.QrConfigManager
import com.tsimcloud.tsimcloudclient.utils.QrConfigResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.CameraControl
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.MeteringPoint
import com.google.mlkit.vision.barcode.BarcodeScannerOptions

class QrScanActivity : ComponentActivity() {
    
    private lateinit var cameraProviderFuture: ListenableFuture<ProcessCameraProvider>
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var qrConfigManager: QrConfigManager
    private lateinit var statusTextView: TextView
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startCamera()
        } else {
            Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
            finish()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_scan)
        
        cameraExecutor = Executors.newSingleThreadExecutor()
        qrConfigManager = QrConfigManager(this)
        statusTextView = findViewById(R.id.statusText)
        
        // Set up close button
        findViewById<ImageButton>(R.id.closeButton).setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
        
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }
    
    private fun startCamera() {
        cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            // Camera2Interop ile autofocus ve auto exposure
            val previewBuilder = Preview.Builder()
            val camera2PreviewExt = Camera2Interop.Extender(previewBuilder)
            camera2PreviewExt.setCaptureRequestOption(
                android.hardware.camera2.CaptureRequest.CONTROL_AF_MODE,
                android.hardware.camera2.CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            camera2PreviewExt.setCaptureRequestOption(
                android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE,
                android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE_ON
            )
            val preview = previewBuilder.build()

            val imageAnalysisBuilder = ImageAnalysis.Builder()
            val camera2ImageAnalysisExt = Camera2Interop.Extender(imageAnalysisBuilder)
            camera2ImageAnalysisExt.setCaptureRequestOption(
                android.hardware.camera2.CaptureRequest.CONTROL_AF_MODE,
                android.hardware.camera2.CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            camera2ImageAnalysisExt.setCaptureRequestOption(
                android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE,
                android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE_ON
            )
            val imageAnalysis = imageAnalysisBuilder
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setTargetResolution(android.util.Size(1280, 720)) // Daha düşük çözünürlük
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, QrCodeAnalyzer { qrCode ->
                        processQrCode(qrCode)
                    })
                }

            try {
                cameraProvider.unbindAll()
                val previewView = findViewById<PreviewView>(R.id.previewView)
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val camera = cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalysis
                )
                // İlk açılışta merkeze odaklama yap
                previewView.post {
                    val factory: MeteringPointFactory = previewView.meteringPointFactory
                    val point: MeteringPoint = factory.createPoint(0.5f, 0.5f)
                    val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF)
                        .setAutoCancelDuration(3, java.util.concurrent.TimeUnit.SECONDS)
                        .build()
                    camera.cameraControl.startFocusAndMetering(action)
                }
            } catch (exc: Exception) {
                Toast.makeText(this, "Failed to start camera", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }
    
    private fun processQrCode(qrCode: String) {
        runOnUiThread {
            Log.d(TAG, "Processing QR code: $qrCode")
            val result = qrConfigManager.parseAndSaveQrConfig(qrCode)
            
            when (result) {
                is QrConfigResult.Success -> {
                    Log.d(TAG, "QR configuration saved successfully")
                    Log.d(TAG, "Device Group: ${result.config.deviceGroup}")
                    Log.d(TAG, "Site Name: ${result.config.countrySite}")
                    Log.d(TAG, "WebSocket URL: ${result.config.websocketUrl}")
                    Log.d(TAG, "API Key: ${result.config.apiKey}")

                    
                    // Update status text instead of showing toast
                    statusTextView.text = "Configuration updated: ${result.config.deviceGroup} - ${result.config.countrySite}"
                    
                    // Send result to calling activity but don't finish
                    val intent = Intent()
                    intent.putExtra("config_saved", true)
                    intent.putExtra("device_group", result.config.deviceGroup)
                    intent.putExtra("countrySite", result.config.countrySite)
                    setResult(Activity.RESULT_OK, intent)
                    
                    // Show brief success message
                    Toast.makeText(this, "Configuration updated successfully!", Toast.LENGTH_SHORT).show()
                    
                    // QR başarıyla okunduğunda activity'yi kapat
                    finish()
                }
                is QrConfigResult.Error -> {
                    Log.e(TAG, "QR configuration error: ${result.message}")
                    statusTextView.text = "Error: ${result.message}"
                    Toast.makeText(this, "Error: ${result.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun allPermissionsGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
    
    companion object {
        private const val TAG = "QrScanActivity"
    }
}

/**
 * QR Code Analyzer using ML Kit
 */
class QrCodeAnalyzer(private val onQrCodeDetected: (String) -> Unit) : ImageAnalysis.Analyzer {
    
    private val scanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE) // Sadece QR kod formatını destekle
            .build()
    )
    private var isProcessing = false
    private var lastProcessedQrCode = ""
    private var lastProcessTime = 0L
    
    @ExperimentalGetImage
    override fun analyze(imageProxy: androidx.camera.core.ImageProxy) {
        if (isProcessing) {
            imageProxy.close()
            return
        }
        
        // Aynı QR kodu tekrar işleme (debouncing)
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastProcessTime < 2000) { // 2 saniye bekle
            imageProxy.close()
            return
        }
        
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            isProcessing = true
            
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            
            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    barcodes.forEach { barcode ->
                        if (barcode.format == Barcode.FORMAT_QR_CODE) {
                            barcode.rawValue?.let { qrCode ->
                                // Aynı QR kodu tekrar işleme
                                if (qrCode != lastProcessedQrCode) {
                                    lastProcessedQrCode = qrCode
                                    lastProcessTime = currentTime
                                    onQrCodeDetected(qrCode)
                                }
                            }
                        }
                    }
                    isProcessing = false
                }
                .addOnFailureListener {
                    isProcessing = false
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }
} 