package com.tsimcloud.tsimcloudclient

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import com.tsimcloud.tsimcloudclient.utils.DeviceInfo
import com.tsimcloud.tsimcloudclient.utils.PreferencesManager
import com.tsimcloud.tsimcloudclient.utils.WebSocketClient
import org.json.JSONArray
import org.json.JSONObject

class SimCardChangeReceiver : BroadcastReceiver() {
    
    companion object {
        private const val TAG = "SimCardChangeReceiver"
        private var webSocketClient: WebSocketClient? = null
        private var deviceInfo: DeviceInfo? = null
        
        fun setWebSocketClient(client: WebSocketClient) {
            webSocketClient = client
        }
        
        fun setDeviceInfo(info: DeviceInfo) {
            deviceInfo = info
        }
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            TelephonyManager.ACTION_PHONE_STATE_CHANGED -> {
                Log.d(TAG, "Phone state changed")
                checkSimCardChanges(context)
            }
            "android.intent.action.SIM_STATE_CHANGED" -> {
                Log.d(TAG, "SIM state changed")
                checkSimCardChanges(context)
            }
        }
    }
    
    private fun checkSimCardChanges(context: Context) {
        try {
            val currentDeviceInfo = deviceInfo ?: DeviceInfo(context)
            val currentSimCards = currentDeviceInfo.getSimCardsForHeartbeat()
            val preferencesManager = PreferencesManager(context)
            
            // SIM tepsi durumu kontrolü
            val simTrayStatus = checkSimTrayStatus(currentSimCards, preferencesManager)
            
            // Dual SIM kontrolü yap
            if (currentDeviceInfo.isDualSimSupported()) {
                checkDualSimCardChanges(context, currentSimCards, preferencesManager, simTrayStatus)
            } else {
                // Single SIM için eski mantık
                checkSingleSimCardChanges(context, currentSimCards, preferencesManager, simTrayStatus)
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking SIM card changes", e)
        }
    }
    
    private fun checkSimTrayStatus(currentSimCards: List<Map<String, Any>>, preferencesManager: PreferencesManager): SimTrayStatus {
        val lastSimCards = preferencesManager.getLastSimCards()
        
        if (lastSimCards.isEmpty()) {
            return SimTrayStatus.INITIAL
        }
        
        val previousSimCards = parseSimCardsFromJson(lastSimCards)
        
        return when {
            currentSimCards.isEmpty() && previousSimCards.isNotEmpty() -> {
                Log.w(TAG, "SIM tray opened - all SIM cards removed")
                SimTrayStatus.OPENED
            }
            currentSimCards.isNotEmpty() && previousSimCards.isEmpty() -> {
                Log.i(TAG, "SIM tray closed - SIM cards reinserted")
                SimTrayStatus.CLOSED
            }
            currentSimCards.size < previousSimCards.size -> {
                Log.w(TAG, "SIM tray partially opened - some SIM cards removed")
                SimTrayStatus.PARTIALLY_OPENED
            }
            currentSimCards.size > previousSimCards.size -> {
                Log.i(TAG, "SIM tray closed - additional SIM cards inserted")
                SimTrayStatus.CLOSED_WITH_MORE
            }
            else -> SimTrayStatus.NO_CHANGE
        }
    }
    
    private fun checkDualSimCardChanges(context: Context, currentSimCards: List<Map<String, Any>>, preferencesManager: PreferencesManager, simTrayStatus: SimTrayStatus) {
        try {
            // Mevcut SIM kart bilgilerini JSON string'e çevir
            val currentSimCardsJson = convertSimCardsToJson(currentSimCards)
            
            // Mevcut IMSI listesini al
            val currentImsis = currentSimCards.mapNotNull { it["imsi"] as? String }.filter { it.isNotEmpty() }
            
            // PreferencesManager'dan önceki SIM kart bilgilerini al
            val lastSimCards = preferencesManager.getLastSimCards()
            val lastImsis = preferencesManager.getLastImsiList()
            
            Log.d(TAG, "Current SIM cards: $currentSimCardsJson")
            Log.d(TAG, "Last SIM cards: $lastSimCards")
            Log.d(TAG, "Current IMSIs: $currentImsis")
            Log.d(TAG, "Last IMSIs: $lastImsis")
            Log.d(TAG, "SIM Tray Status: $simTrayStatus")
            
            // SIM tepsi durumuna göre işlem yap
            when (simTrayStatus) {
                SimTrayStatus.OPENED -> {
                    // SIM tepsi açıldı - alarm gönder
                    if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                        sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "SIM tray opened - all SIM cards removed")
                        preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                    }
                }
                SimTrayStatus.CLOSED -> {
                    // SIM tepsi kapandı - IMSI kontrolü yap
                    if (lastSimCards.isNotEmpty() && lastImsis.isNotEmpty()) {
                        val previousSimCards = parseSimCardsFromJson(lastSimCards)
                        val imsiComparison = compareSimCardsByIMSI(currentSimCards, previousSimCards)
                        
                        when (imsiComparison) {
                            SimCardComparisonResult.NO_CHANGE -> {
                                // Aynı IMSI'ler - alarm çöz
                                Log.d(TAG, "SIM tray closed with same IMSIs - resolving alarm")
                                sendSimCardChangeAlarmResolved(context, currentSimCards, lastSimCards)
                            }
                            SimCardComparisonResult.IMSI_CHANGED -> {
                                // Farklı IMSI'ler - yeni alarm gönder
                                Log.w(TAG, "SIM tray closed with different IMSIs - sending new alarm")
                                if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                                    sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "SIM tray closed with different IMSIs")
                                    preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                                }
                            }
                            else -> {
                                // Diğer durumlar
                                sendSimCardChangeAlarmResolved(context, currentSimCards, lastSimCards)
                            }
                        }
                    } else {
                        // İlk kez kart takıldı
                        sendSimCardChangeAlarmResolved(context, currentSimCards, lastSimCards)
                    }
                }
                SimTrayStatus.PARTIALLY_OPENED -> {
                    // Kısmen açıldı - alarm gönder
                    if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                        sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "SIM tray partially opened - some SIM cards removed")
                        preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                    }
                }
                SimTrayStatus.CLOSED_WITH_MORE -> {
                    // Daha fazla kart eklendi - alarm çöz
                    sendSimCardChangeAlarmResolved(context, currentSimCards, lastSimCards)
                }
                SimTrayStatus.NO_CHANGE -> {
                    // Normal IMSI karşılaştırması yap
                    if (lastSimCards.isNotEmpty() && lastImsis.isNotEmpty()) {
                        val previousSimCards = parseSimCardsFromJson(lastSimCards)
                        val imsiComparison = compareSimCardsByIMSI(currentSimCards, previousSimCards)
                        
                        val useImsiBasedDetection = preferencesManager.isImsiBasedDetectionEnabled()
                        
                        when (imsiComparison) {
                            SimCardComparisonResult.NO_CHANGE -> {
                                Log.d(TAG, "No significant SIM card change detected (same IMSIs)")
                                preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                            }
                            SimCardComparisonResult.IMSI_CHANGED -> {
                                Log.w(TAG, "IMSI change detected in dual SIM configuration")
                                if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                                    sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "IMSI changed in dual SIM configuration")
                                    preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                                } else {
                                    Log.d(TAG, "Alarm delay active, skipping SIM card change alarm")
                                }
                            }
                            SimCardComparisonResult.CARD_COUNT_CHANGED -> {
                                Log.w(TAG, "SIM card count change detected")
                                if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                                    sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "SIM card count changed")
                                    preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                                } else {
                                    Log.d(TAG, "Alarm delay active, skipping SIM card change alarm")
                                }
                            }
                            SimCardComparisonResult.CONFIGURATION_CHANGED -> {
                                Log.w(TAG, "SIM card configuration change detected")
                                if (useImsiBasedDetection && currentImsis.toSet() == lastImsis.toSet()) {
                                    Log.d(TAG, "IMSI-based detection enabled and IMSIs are same, skipping alarm")
                                } else {
                                    if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                                        sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "SIM card configuration changed")
                                        preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                                    } else {
                                        Log.d(TAG, "Alarm delay active, skipping SIM card change alarm")
                                    }
                                }
                            }
                        }
                    } else {
                        // İlk kez çalışıyor, sadece kaydet, alarm gönderme
                        Log.d(TAG, "First run, saving initial SIM card configuration")
                    }
                }
                SimTrayStatus.INITIAL -> {
                    // İlk çalıştırma, sadece kaydet
                    Log.d(TAG, "Initial run, saving SIM card configuration")
                }
            }
            
            // Mevcut SIM kart bilgilerini PreferencesManager'a kaydet
            preferencesManager.saveLastSimCards(currentSimCardsJson)
            preferencesManager.saveLastImsiList(currentImsis)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking dual SIM card changes", e)
        }
    }
    
    private fun checkSingleSimCardChanges(context: Context, currentSimCards: List<Map<String, Any>>, preferencesManager: PreferencesManager, simTrayStatus: SimTrayStatus) {
        try {
            // SIM kart bilgilerini JSON string'e çevir
            val currentSimCardsJson = convertSimCardsToJson(currentSimCards)
            
            // Mevcut IMSI listesini al
            val currentImsis = currentSimCards.mapNotNull { it["imsi"] as? String }.filter { it.isNotEmpty() }
            
            // PreferencesManager'dan önceki SIM kart bilgilerini al
            val lastSimCards = preferencesManager.getLastSimCards()
            val lastImsis = preferencesManager.getLastImsiList()
            
            Log.d(TAG, "Current SIM cards: $currentSimCardsJson")
            Log.d(TAG, "Last SIM cards: $lastSimCards")
            Log.d(TAG, "Current IMSIs: $currentImsis")
            Log.d(TAG, "Last IMSIs: $lastImsis")
            
            if (lastSimCards.isNotEmpty() && lastImsis.isNotEmpty()) {
                val previousSimCards = parseSimCardsFromJson(lastSimCards)
                
                // IMSI karşılaştırması yap
                val imsiComparison = compareSimCardsByIMSI(currentSimCards, previousSimCards)
                
                // IMSI tabanlı tespit etkin mi kontrol et
                val useImsiBasedDetection = preferencesManager.isImsiBasedDetectionEnabled()
                
                when (imsiComparison) {
                    SimCardComparisonResult.NO_CHANGE -> {
                        Log.d(TAG, "No significant SIM card change detected (same IMSIs)")
                        // Aynı IMSI'ler varsa alarm gönderme
                        preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                    }
                    SimCardComparisonResult.IMSI_CHANGED -> {
                        Log.w(TAG, "IMSI change detected in single SIM configuration")
                        
                        // Alarm gecikmesi kontrolü
                        if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                            sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "IMSI changed in single SIM configuration")
                            preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                        } else {
                            Log.d(TAG, "Alarm delay active, skipping SIM card change alarm")
                        }
                    }
                    SimCardComparisonResult.CARD_COUNT_CHANGED -> {
                        Log.w(TAG, "SIM card count change detected")
                
                // Önceki SIM kart sayısını al
                val previousSimCardCount = getPreviousSimCardCount(lastSimCards)
                val currentSimCardCount = currentSimCards.size
                
                if (currentSimCardCount > previousSimCardCount) {
                    // SIM kart geri takıldı - alarm durdur
                    Log.i(TAG, "SIM card reinserted, resolving alarm")
                    sendSimCardChangeAlarmResolved(context, currentSimCards, lastSimCards)
                } else if (currentSimCardCount < previousSimCardCount) {
                    // SIM kart çıkarıldı - alarm gönder
                    Log.i(TAG, "SIM card removed, sending alarm")
                            
                            // Alarm gecikmesi kontrolü
                            if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                                sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "SIM card removed")
                                preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                            } else {
                                Log.d(TAG, "Alarm delay active, skipping SIM card change alarm")
                            }
                        }
                    }
                    SimCardComparisonResult.CONFIGURATION_CHANGED -> {
                        Log.w(TAG, "SIM card configuration change detected")
                        
                        // IMSI tabanlı tespit etkinse ve IMSI'ler aynıysa alarm gönderme
                        if (useImsiBasedDetection && currentImsis.toSet() == lastImsis.toSet()) {
                            Log.d(TAG, "IMSI-based detection enabled and IMSIs are same, skipping alarm")
                        } else {
                            // Alarm gecikmesi kontrolü
                            if (preferencesManager.shouldSendSimCardChangeAlarm()) {
                                sendSimCardChangeAlarm(context, currentSimCards, lastSimCards, "SIM card configuration changed")
                                preferencesManager.saveLastSimCardChangeTime(System.currentTimeMillis())
                } else {
                                Log.d(TAG, "Alarm delay active, skipping SIM card change alarm")
                            }
                        }
                    }
                }
            } else if (lastSimCards.isEmpty()) {
                // İlk kez çalışıyor, sadece kaydet, alarm gönderme
                Log.d(TAG, "First run, saving initial SIM card configuration")
            }
            
            // Mevcut SIM kart bilgilerini PreferencesManager'a kaydet
            preferencesManager.saveLastSimCards(currentSimCardsJson)
            preferencesManager.saveLastImsiList(currentImsis)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking single SIM card changes", e)
        }
    }
    
    private fun compareSimCardsByIMSI(currentSimCards: List<Map<String, Any>>, previousSimCards: List<Map<String, Any>>): SimCardComparisonResult {
        try {
            // SIM kart sayısı değişikliği kontrol et
            if (currentSimCards.size != previousSimCards.size) {
                return SimCardComparisonResult.CARD_COUNT_CHANGED
            }
            
            // IMSI karşılaştırması yap
            val currentImsis = currentSimCards.mapNotNull { it["imsi"] as? String }.filter { it.isNotEmpty() }.toSet()
            val previousImsis = previousSimCards.mapNotNull { it["imsi"] as? String }.filter { it.isNotEmpty() }.toSet()
            
            Log.d(TAG, "Current IMSIs: $currentImsis")
            Log.d(TAG, "Previous IMSIs: $previousImsis")
            
            // IMSI'ler aynı mı kontrol et
            if (currentImsis == previousImsis && currentImsis.isNotEmpty()) {
                return SimCardComparisonResult.NO_CHANGE
            }
            
            // IMSI değişikliği var mı kontrol et
            if (currentImsis != previousImsis) {
                return SimCardComparisonResult.IMSI_CHANGED
            }
            
            // Diğer konfigürasyon değişiklikleri (carrier, number vb.)
            return SimCardComparisonResult.CONFIGURATION_CHANGED
            
        } catch (e: Exception) {
            Log.e(TAG, "Error comparing SIM cards by IMSI", e)
            return SimCardComparisonResult.CONFIGURATION_CHANGED
        }
    }
    
    private fun convertSimCardsToJson(simCards: List<Map<String, Any>>): String {
        return try {
            val jsonArray = JSONArray()
            simCards.forEach { simCard ->
                val jsonObject = JSONObject()
                simCard.forEach { (key, value) ->
                    jsonObject.put(key, value)
                }
                jsonArray.put(jsonObject)
            }
            jsonArray.toString()
        } catch (e: Exception) {
            Log.e(TAG, "Error converting SIM cards to JSON", e)
            "[]"
        }
    }
    
    private fun parseSimCardsFromJson(jsonString: String): List<Map<String, Any>> {
        return try {
            val jsonArray = JSONArray(jsonString)
            val simCards = mutableListOf<Map<String, Any>>()
            
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val simCard = mutableMapOf<String, Any>()
                
                val keys = jsonObject.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    simCard[key] = jsonObject.get(key)
                }
                
                simCards.add(simCard)
            }
            
            simCards
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing SIM cards from JSON", e)
            emptyList()
        }
    }
    
    private fun sendSimCardChangeAlarm(context: Context, currentSimCards: List<Map<String, Any>>, previousSimCards: String, reason: String) {
        try {
            val webSocket = webSocketClient
            if (webSocket != null && webSocket.isConnected()) {
                val deviceInfo = deviceInfo ?: DeviceInfo(context)
                
                // SIM kart değişiklik detaylarını hazırla
                val changeDetails = buildSimCardChangeDetails(currentSimCards, previousSimCards)
                
                // Alarm mesajı oluştur
                val alarmMessage = "$reason. $changeDetails"
                
                // Alarm gönder
                webSocket.sendAlarm(
                    alarmType = "sim_card_change",
                    message = alarmMessage,
                    severity = "warning"
                )
                
                Log.i(TAG, "SIM card change alarm sent: $alarmMessage")
            } else {
                Log.w(TAG, "WebSocket not connected, cannot send SIM card change alarm")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending SIM card change alarm", e)
        }
    }
    
    private fun sendSimCardChangeAlarmResolved(context: Context, currentSimCards: List<Map<String, Any>>, previousSimCards: String) {
        try {
            val webSocket = webSocketClient
            if (webSocket != null && webSocket.isConnected()) {
                val deviceInfo = deviceInfo ?: DeviceInfo(context)
                
                // SIM kart değişiklik detaylarını hazırla
                val changeDetails = buildSimCardChangeDetails(currentSimCards, previousSimCards)
                
                // Alarm çözüm mesajı oluştur
                val resolvedMessage = when {
                    currentSimCards.isEmpty() -> "SIM card configuration resolved - No SIM cards detected"
                    currentSimCards.size > getPreviousSimCardCount(previousSimCards) -> "SIM card reinserted into tray"
                    else -> "SIM card configuration resolved"
                }
                
                // Alarm çözüm mesajı gönder
                webSocket.sendAlarmResolved(
                    alarmType = "sim_card_change",
                    message = "$resolvedMessage. $changeDetails",
                    severity = "info"
                )
                
                Log.i(TAG, "SIM card change alarm resolved: $resolvedMessage")
            } else {
                Log.w(TAG, "WebSocket not connected, cannot send SIM card change alarm resolved")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending SIM card change alarm resolved", e)
        }
    }
    
    private fun buildSimCardChangeDetails(currentSimCards: List<Map<String, Any>>, previousSimCards: String): String {
        val details = mutableListOf<String>()
        
        if (currentSimCards.isEmpty()) {
            details.add("All SIM cards removed")
        } else {
            details.add("Current SIM cards: ${currentSimCards.size}")
            currentSimCards.forEachIndexed { index, simCard ->
                val carrierName = simCard["carrier_name"] as? String ?: "Unknown"
                val phoneNumber = simCard["phone_number"] as? String ?: "No number"
                val imsi = simCard["imsi"] as? String ?: "No IMSI"
                details.add("Slot ${index + 1}: $carrierName ($phoneNumber) - IMSI: $imsi")
            }
        }
        
        return details.joinToString("; ")
    }
    
    private fun getPreviousSimCardCount(previousSimCards: String): Int {
        return try {
            // JSON array'den SIM kart sayısını al
            val jsonArray = JSONArray(previousSimCards)
            jsonArray.length()
        } catch (e: Exception) {
            // Fallback: basit string analizi
            previousSimCards.count { it == '0' } + previousSimCards.count { it == '1' }
        }
    }
    
    enum class SimCardComparisonResult {
        NO_CHANGE,           // Aynı IMSI'ler, değişiklik yok
        IMSI_CHANGED,        // IMSI değişikliği tespit edildi
        CARD_COUNT_CHANGED,  // SIM kart sayısı değişti
        CONFIGURATION_CHANGED // Diğer konfigürasyon değişiklikleri
    }

    enum class SimTrayStatus {
        INITIAL,           // İlk çalıştırma
        OPENED,           // SIM tepsi açıldı
        CLOSED,           // SIM tepsi kapandı
        PARTIALLY_OPENED, // Kısmen açıldı
        CLOSED_WITH_MORE, // Daha fazla kart eklendi
        NO_CHANGE         // Değişiklik yok
    }
} 