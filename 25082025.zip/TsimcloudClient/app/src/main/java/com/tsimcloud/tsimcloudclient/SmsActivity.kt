package com.tsimcloud.tsimcloudclient

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.util.Log
import android.widget.Toast
import com.tsimcloud.tsimcloudclient.utils.PreferencesManager
import com.tsimcloud.tsimcloudclient.utils.QrConfigManager
import com.tsimcloud.tsimcloudclient.utils.SmsMessageHandler
import com.tsimcloud.tsimcloudclient.utils.WebSocketClient

class SmsActivity : Activity() {
    
    companion object {
        private const val TAG = "SmsActivity"
    }
    
    private lateinit var qrConfigManager: QrConfigManager
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var deviceInfo: com.tsimcloud.tsimcloudclient.utils.DeviceInfo
    private lateinit var webSocketClient: WebSocketClient
    private lateinit var smsHandler: SmsMessageHandler
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "SmsActivity created")
        
        qrConfigManager = QrConfigManager(this)
        preferencesManager = PreferencesManager(this)
        deviceInfo = com.tsimcloud.tsimcloudclient.utils.DeviceInfo(this)
        
        // Initialize WebSocket client if configured
        val config = qrConfigManager.getCurrentConfig()
        if (config != null) {
            webSocketClient = WebSocketClient(
                this,
                config.websocketUrl,
                config.apiKey,
                deviceInfo
            )
            
            smsHandler = SmsMessageHandler(
                this,
                webSocketClient,
                deviceInfo,
                preferencesManager
            )
            
            // Connect to WebSocket
            webSocketClient.connect()
        }
        
        // Handle incoming intent
        handleIntent(intent)
    }
    
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }
    
    private fun handleIntent(intent: Intent?) {
        if (intent == null) {
            finish()
            return
        }
        
        when (intent.action) {
            Intent.ACTION_SEND -> {
                handleSendIntent(intent)
            }
            Intent.ACTION_SENDTO -> {
                handleSendToIntent(intent)
            }
            Intent.ACTION_VIEW -> {
                handleViewIntent(intent)
            }
            else -> {
                Log.w(TAG, "Unknown intent action: ${intent.action}")
                finish()
            }
        }
    }
    
    private fun handleSendIntent(intent: Intent) {
        val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
        val phoneNumber = intent.getStringExtra("phone_number")
        
        if (sharedText != null && phoneNumber != null) {
            sendSms(phoneNumber, sharedText)
        } else {
            Log.w(TAG, "Missing phone number or text in SEND intent")
            finish()
        }
    }
    
    private fun handleSendToIntent(intent: Intent) {
        val data = intent.data
        if (data != null) {
            val phoneNumber = when (data.scheme) {
                "sms", "smsto" -> data.schemeSpecificPart
                else -> null
            }
            
            val sharedText = intent.getStringExtra("sms_body")
            
            if (phoneNumber != null) {
                if (sharedText != null) {
                    sendSms(phoneNumber, sharedText)
                } else {
                    // Open SMS compose UI or handle differently
                    openSmsCompose(phoneNumber)
                }
            } else {
                Log.w(TAG, "Invalid phone number in SENDTO intent")
                finish()
            }
        } else {
            Log.w(TAG, "No data in SENDTO intent")
            finish()
        }
    }
    
    private fun handleViewIntent(intent: Intent) {
        val data = intent.data
        if (data != null) {
            val phoneNumber = when (data.scheme) {
                "sms", "smsto" -> data.schemeSpecificPart
                else -> null
            }
            
            if (phoneNumber != null) {
                openSmsCompose(phoneNumber)
            } else {
                Log.w(TAG, "Invalid phone number in VIEW intent")
                finish()
            }
        } else {
            Log.w(TAG, "No data in VIEW intent")
            finish()
        }
    }
    
    private fun sendSms(phoneNumber: String, message: String) {
        try {
            Log.d(TAG, "Sending SMS to $phoneNumber: $message")
            
            // Check if device is configured
            if (!qrConfigManager.isDeviceConfigured()) {
                Toast.makeText(this, "Device not configured", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
            
            // Check SMS limits if enabled
            if (preferencesManager.isSmsLimitsEnabled()) {
                if (!checkSmsLimits(1)) { // Default to SIM1
                    Toast.makeText(this, "SMS limit exceeded", Toast.LENGTH_SHORT).show()
                    webSocketClient.sendAlarm("sms_limit_exceeded", "SMS limit exceeded for SIM1", "warning")
                    finish()
                    return
                }
            }
            
            // Get SMS manager
            val smsManager = SmsManager.getDefault()
            
            // Split message if needed
            val parts = smsManager.divideMessage(message)
            
            // Send SMS parts
            if (parts.size == 1) {
                smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    parts[0],
                    null,
                    null
                )
            } else {
                smsManager.sendMultipartTextMessage(
                    phoneNumber,
                    null,
                    parts,
                    null,
                    null
                )
            }
            
            // Send to WebSocket
            smsHandler.handleOutgoingSms(phoneNumber, message, 1) // Default to SIM1
            
            // Update SMS count
            updateSmsCount(1)
            
            // Show success message
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show()
            
            // Send success notification to WebSocket
            webSocketClient.sendDeviceStatus("sms_sent_activity", mapOf(
                "phone_number" to phoneNumber,
                "sim_slot" to 1,
                "message_length" to message.length
            ))
            
        } catch (e: Exception) {
            Log.e(TAG, "Error sending SMS", e)
            Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_SHORT).show()
            webSocketClient.sendAlarm("sms_send_error", "Failed to send SMS: ${e.message}", "error")
        }
        
        finish()
    }
    
    private fun openSmsCompose(phoneNumber: String) {
        try {
            // Open default SMS app or show compose UI
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phoneNumber")
            }
            startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Error opening SMS compose", e)
            Toast.makeText(this, "No SMS app available", Toast.LENGTH_SHORT).show()
        }
        
        finish()
    }
    
    /**
     * Check SMS limits
     */
    private fun checkSmsLimits(simSlot: Int): Boolean {
        // This is a simplified implementation
        // In a real app, you would track SMS counts in SharedPreferences
        // and check against daily/monthly limits
        
        val dailyLimit = if (simSlot == 1) {
            preferencesManager.getSim1DailySmsLimit()
        } else {
            preferencesManager.getSim2DailySmsLimit()
        }
        
        val monthlyLimit = if (simSlot == 1) {
            preferencesManager.getSim1MonthlySmsLimit()
        } else {
            preferencesManager.getSim2MonthlySmsLimit()
        }
        
        // For now, always return true (no limit checking)
        // TODO: Implement actual SMS counting and limit checking
        return true
    }
    
    /**
     * Update SMS count
     */
    private fun updateSmsCount(simSlot: Int) {
        // TODO: Implement SMS counting logic
        // This would update daily and monthly SMS counts in SharedPreferences
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "SmsActivity destroyed")
        
        // Send activity status to WebSocket
        webSocketClient.sendDeviceStatus("sms_activity_closed", mapOf("activity" to "SmsActivity"))
        
        // Cleanup
        webSocketClient.cleanup()
    }
}
