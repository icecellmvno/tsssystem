package com.tsimcloud.tsimcloudclient

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsMessage
import android.util.Log
import com.tsimcloud.tsimcloudclient.utils.PreferencesManager
import com.tsimcloud.tsimcloudclient.utils.QrConfigManager
import com.tsimcloud.tsimcloudclient.utils.SmsMessageHandler
import com.tsimcloud.tsimcloudclient.utils.WebSocketClient

class SmsReceivedReceiver : BroadcastReceiver() {
    
    companion object {
        private const val TAG = "SmsReceivedReceiver"
        private var webSocketClient: WebSocketClient? = null
        private var smsHandler: SmsMessageHandler? = null
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Telephony.Sms.Intents.SMS_RECEIVED_ACTION -> {
                handleSmsReceived(context, intent)
            }
            Telephony.Sms.Intents.SMS_DELIVER_ACTION -> {
                handleSmsDelivered(context, intent)
            }
        }
    }
    
    private fun handleSmsReceived(context: Context, intent: Intent) {
        try {
            val qrConfigManager = QrConfigManager(context)
            
            // Check if device is configured
            if (!qrConfigManager.isDeviceConfigured()) {
                Log.w(TAG, "Device not configured, ignoring SMS")
                return
            }
            
            val extras = intent.extras
            if (extras != null) {
                val pdus = extras["pdus"] as? Array<*>
                val format = extras.getString("format")
                
                if (pdus != null && format != null) {
                    // Get subscription ID to determine SIM slot
                    val subscriptionId = extras.getInt("subscription", -1)
                    
                    // Initialize WebSocket client and SMS handler if needed
                    initializeWebSocketClient(context, qrConfigManager)
                    
                    // Handle SMS
                    smsHandler?.handleIncomingSms(pdus as Array<Any>, format, subscriptionId)
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling SMS received", e)
        }
    }
    
    private fun handleSmsDelivered(context: Context, intent: Intent) {
        try {
            val qrConfigManager = QrConfigManager(context)
            
            // Check if device is configured
            if (!qrConfigManager.isDeviceConfigured()) {
                Log.w(TAG, "Device not configured, ignoring SMS delivery")
                return
            }
            
            val extras = intent.extras
            if (extras != null) {
                val pdus = extras["pdus"] as? Array<*>
                val format = extras.getString("format")
                
                if (pdus != null && format != null) {
                    val subscriptionId = extras.getInt("subscription", -1)
                    
                    // Initialize WebSocket client and SMS handler if needed
                    initializeWebSocketClient(context, qrConfigManager)
                    
                    // Handle SMS delivery
                    for (pdu in pdus) {
                        val message = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                            SmsMessage.createFromPdu(pdu as ByteArray, format)
                        } else {
                            @Suppress("DEPRECATION")
                            SmsMessage.createFromPdu(pdu as ByteArray)
                        }
                        
                        val sender = message.originatingAddress ?: "Unknown"
                        val messageId = message.indexOnIcc.toString()
                        val status = "delivered"
                        val simSlot = if (subscriptionId != -1) {
                            try {
                                val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as android.telephony.SubscriptionManager
                                val subscriptionInfo = subscriptionManager.getActiveSubscriptionInfo(subscriptionId)
                                subscriptionInfo?.simSlotIndex ?: 1
                            } catch (e: Exception) {
                                1
                            }
                        } else {
                            1
                        }
                        
                        smsHandler?.handleSmsDeliveryReport(sender, messageId, status, simSlot)
                    }
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling SMS delivered", e)
        }
    }
    
    private fun initializeWebSocketClient(context: Context, qrConfigManager: QrConfigManager) {
        if (webSocketClient == null || smsHandler == null) {
            val config = qrConfigManager.getCurrentConfig()
            if (config != null) {
                val deviceInfo = com.tsimcloud.tsimcloudclient.utils.DeviceInfo(context)
                val preferencesManager = com.tsimcloud.tsimcloudclient.utils.PreferencesManager(context)
                
                webSocketClient = WebSocketClient(
                    context,
                    config.websocketUrl,
                    config.apiKey,
                    deviceInfo
                )
                
                smsHandler = SmsMessageHandler(
                    context,
                    webSocketClient!!,
                    deviceInfo,
                    preferencesManager
                )
                
                // Connect to WebSocket
                webSocketClient?.connect()
            }
        }
    }
}
