package com.tsimcloud.tsimcloudclient

import android.content.Context
import android.util.Log
import com.tsimcloud.tsimcloudclient.utils.WebSocketClient
import com.tsimcloud.tsimcloudclient.utils.UssdUtils
import com.tsimcloud.tsimcloudclient.utils.UssdManager

class UssdResponseReceiver {
    
    companion object {
        private const val TAG = "UssdResponseReceiver"
        var webSocketClient: WebSocketClient? = null
        var ussdManager: UssdManager? = null
        var currentSessionId: String? = null
        var currentMessageId: String? = null
        var autoCancelUssd = true // USSD menülerini otomatik cancel et
        var cancelDelay = 2000L // Cancel için bekleme süresi (ms)
    }
    
    /**
     * Handle USSD response from TelephonyManager callback
     * This is called by SmsGatewayService when USSD response is received
     */
    fun handleUssdResponse(context: Context?, response: String, sessionId: String? = null, messageId: String? = null) {
        try {
            Log.d(TAG, "=== USSD DEBUG: handleUssdResponse START ===")
            Log.d(TAG, "USSD DEBUG: Raw response: '$response'")
            Log.d(TAG, "USSD DEBUG: Response length: ${response.length}")
            Log.d(TAG, "USSD DEBUG: SessionId from param: $sessionId")
            Log.d(TAG, "USSD DEBUG: MessageId from param: $messageId")
            Log.d(TAG, "USSD DEBUG: CurrentSessionId: $currentSessionId")
            Log.d(TAG, "USSD DEBUG: CurrentMessageId: $currentMessageId")
            Log.d(TAG, "USSD DEBUG: WebSocketClient null: ${webSocketClient == null}")
            
            val session = sessionId ?: currentSessionId
            val message = messageId ?: currentMessageId
            
            Log.d(TAG, "USSD DEBUG: Final session: $session")
            Log.d(TAG, "USSD DEBUG: Final message: $message")
            
            if (session != null && webSocketClient != null) {
                Log.d(TAG, "USSD DEBUG: Processing USSD response...")
                
                // USSD menü kontrolü
                val isMenuResponse = UssdUtils.isUssdMenu(response)
                val shouldCancel = autoCancelUssd && isMenuResponse
                
                Log.d(TAG, "USSD DEBUG: Is menu response: $isMenuResponse")
                Log.d(TAG, "USSD DEBUG: Auto cancel enabled: $autoCancelUssd")
                Log.d(TAG, "USSD DEBUG: Should cancel: $shouldCancel")
                
                // USSD text'ini temizle ve formatla
                val cleanedResponse = UssdUtils.cleanUssdResponse(response)
                Log.d(TAG, "USSD DEBUG: Cleaned response: '$cleanedResponse'")
                
                // USSD Manager kullanarak WebSocket'e gönder
                if (ussdManager != null) {
                    Log.d(TAG, "USSD DEBUG: Using USSD Manager to send response")
                    ussdManager?.handleUssdResponse(session, response, "success")
                    Log.d(TAG, "USSD DEBUG: USSD Manager response sent successfully")
                } else {
                    // Fallback: Direct WebSocket send
                    Log.d(TAG, "USSD DEBUG: USSD Manager not available, using direct WebSocket send")
                    val webSocketData = mapOf(
                        "session_id" to (session as Any),
                        "message_id" to (message as Any),
                        "response" to response,
                        "cleaned_response" to cleanedResponse,
                        "status" to "RESPONSE_RECEIVED",
                        "is_menu" to isMenuResponse,
                        "auto_cancel" to shouldCancel,
                        "timestamp" to System.currentTimeMillis() as Any
                    )
                    
                    Log.d(TAG, "USSD DEBUG: Sending to WebSocket: $webSocketData")
                    webSocketClient?.sendDeviceStatus("ussd_response", webSocketData)
                    Log.d(TAG, "USSD DEBUG: WebSocket message sent successfully")
                }
                
                // Menü ise cancel et
                if (shouldCancel) {
                    Log.d(TAG, "USSD DEBUG: Menu detected, scheduling auto-cancel after $cancelDelay ms")
                    UssdUtils.cancelUssdMenu(context, cancelDelay)
                } else {
                    Log.d(TAG, "USSD DEBUG: No auto-cancel needed")
                }
                
                // Clear session after successful processing
                if (session == currentSessionId) {
                    currentSessionId = null
                    currentMessageId = null
                    Log.d(TAG, "USSD DEBUG: Session cleared after successful processing")
                }
            } else {
                Log.w(TAG, "USSD DEBUG: Cannot process - session: $session, webSocket: ${webSocketClient != null}")
            }
            
            Log.d(TAG, "=== USSD DEBUG: handleUssdResponse END ===")
        } catch (e: Exception) {
            Log.e(TAG, "USSD DEBUG: Error in handleUssdResponse", e)
        }
    }
    

} 