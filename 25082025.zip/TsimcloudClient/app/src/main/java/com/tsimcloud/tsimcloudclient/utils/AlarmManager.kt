package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import android.os.BatteryManager
import android.telephony.TelephonyManager
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger

class AlarmManager(
    private val context: Context,
    private val preferencesManager: PreferencesManager,
    private val webSocketClient: WebSocketClient,
    private val deviceInfo: DeviceInfo
) {
    
    companion object {
        private const val TAG = "AlarmManager"
        private const val CHECK_INTERVAL_MS = 60000L // 1 minute
    }
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var monitoringJob: Job? = null
    
    // Error tracking
    private val errorCount = AtomicInteger(0)
    private var lastOnlineTime = System.currentTimeMillis()
    
    // Alarm states
    private var batteryAlarmSent = false
    private var signalAlarmSent = false
    private var offlineAlarmSent = false
    private var simBalanceAlarmSent = false
    
    /**
     * Start alarm monitoring
     */
    fun startMonitoring() {
        if (monitoringJob?.isActive == true) {
            return
        }
        
        monitoringJob = scope.launch {
            while (isActive) {
                checkAlarms()
                delay(CHECK_INTERVAL_MS)
            }
        }
    }
    
    /**
     * Stop alarm monitoring
     */
    fun stopMonitoring() {
        monitoringJob?.cancel()
        monitoringJob = null
    }
    
    /**
     * Check all alarms
     */
    private suspend fun checkAlarms() {
        try {
            // Check battery level
            if (preferencesManager.isEnableBatteryAlarms()) {
                checkBatteryLevel()
            }
            
            // Signal alarm kontrolü devre dışı bırakıldı
            // if (preferencesManager.isEnableSignalAlarms()) {
            //     checkSignalStrength()
            // }
            
            if (preferencesManager.isEnableOfflineAlarms()) {
                checkOfflineStatus()
            }
            
            if (preferencesManager.isEnableSimBalanceAlarms()) {
                checkSimBalance()
            }
            
            // Update online status
            updateOnlineStatus()
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking alarms", e)
            incrementErrorCount()
        }
    }
    
    /**
     * Check battery level
     */
    private suspend fun checkBatteryLevel() {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        
        val threshold = preferencesManager.getBatteryLowThreshold()
        
        if (batteryLevel <= threshold && !batteryAlarmSent) {
            sendBatteryAlarm(batteryLevel)
            batteryAlarmSent = true
        } else if (batteryLevel > threshold) {
            batteryAlarmSent = false
        }
    }
    
    /**
     * Check signal strength
     */
    private suspend fun checkSignalStrength() {
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        
        // Get signal strength for both SIMs if dual SIM
        val signalLevels = mutableListOf<Int>()
        
        if (deviceInfo.isDualSimSupported()) {
            // Check SIM1
            try {
                val sim1Info = deviceInfo.getSimInfoForSlot(0)
                if (sim1Info.isNotEmpty() && sim1Info["error"] == null) {
                    // Get signal strength for SIM1
                    val signalStrength = getSignalStrength(telephonyManager, 0)
                    signalLevels.add(signalStrength)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error getting SIM1 signal strength", e)
            }
            
            // Check SIM2
            try {
                val sim2Info = deviceInfo.getSimInfoForSlot(1)
                if (sim2Info.isNotEmpty() && sim2Info["error"] == null) {
                    // Get signal strength for SIM2
                    val signalStrength = getSignalStrength(telephonyManager, 1)
                    signalLevels.add(signalStrength)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error getting SIM2 signal strength", e)
            }
        } else {
            // Single SIM
            val signalStrength = getSignalStrength(telephonyManager, 0)
            signalLevels.add(signalStrength)
        }
        
        val threshold = preferencesManager.getSignalLowThreshold()
        val lowestSignal = signalLevels.minOrNull() ?: 0
        
        if (lowestSignal <= threshold && !signalAlarmSent) {
            sendSignalAlarm(lowestSignal, signalLevels)
            signalAlarmSent = true
        } else if (lowestSignal > threshold) {
            signalAlarmSent = false
        }
    }
    
    /**
     * Get signal strength for specific SIM slot
     */
    private fun getSignalStrength(telephonyManager: TelephonyManager, slotIndex: Int): Int {
        return try {
            // This is a simplified implementation
            // In a real app, you would use SignalStrength API
            val signalStrength = telephonyManager.signalStrength
            when {
                signalStrength?.level == null -> 50 // Default
                signalStrength.level >= 4 -> 100
                signalStrength.level >= 3 -> 75
                signalStrength.level >= 2 -> 50
                signalStrength.level >= 1 -> 25
                else -> 0
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error getting signal strength for slot $slotIndex", e)
            50 // Default value
        }
    }
    
    /**
     * Check offline status
     */
    private suspend fun checkOfflineStatus() {
        val thresholdMinutes = preferencesManager.getOfflineThresholdMinutes()
        val currentTime = System.currentTimeMillis()
        val offlineThresholdMs = thresholdMinutes * 60 * 1000L
        
        if (currentTime - lastOnlineTime > offlineThresholdMs && !offlineAlarmSent) {
            sendOfflineAlarm(thresholdMinutes)
            offlineAlarmSent = true
        }
    }
    
    /**
     * Check SIM balance
     */
    private suspend fun checkSimBalance() {
        // This would typically involve checking SIM balance via USSD or API
        // For now, we'll implement a placeholder
        val threshold = preferencesManager.getLowBalanceThreshold()
        
        // Placeholder implementation - in real app, you would check actual balance
        val sim1Balance = getSimBalance(0)
        val sim2Balance = if (deviceInfo.isDualSimSupported()) getSimBalance(1) else null
        
        if (sim1Balance != null && sim1Balance <= threshold && !simBalanceAlarmSent) {
            sendSimBalanceAlarm(1, sim1Balance)
            simBalanceAlarmSent = true
        }
        
        if (sim2Balance != null && sim2Balance <= threshold && !simBalanceAlarmSent) {
            sendSimBalanceAlarm(2, sim2Balance)
            simBalanceAlarmSent = true
        }
    }
    
    /**
     * Get SIM balance (placeholder implementation)
     */
    private fun getSimBalance(slotIndex: Int): Double? {
        // This is a placeholder - in real implementation, you would:
        // 1. Send USSD code to check balance
        // 2. Parse the response
        // 3. Return the balance amount
        return null
    }
    
    /**
     * Update online status
     */
    private fun updateOnlineStatus() {
        lastOnlineTime = System.currentTimeMillis()
        if (offlineAlarmSent) {
            offlineAlarmSent = false
            sendOnlineNotification()
        }
    }
    
    /**
     * Increment error count
     */
    private fun incrementErrorCount() {
        val currentCount = errorCount.incrementAndGet()
        val threshold = preferencesManager.getErrorCountThreshold()
        
        if (currentCount >= threshold && preferencesManager.isEnableErrorAlarms()) {
            sendErrorAlarm(currentCount)
        }
    }
    
    /**
     * Reset error count
     */
    fun resetErrorCount() {
        errorCount.set(0)
    }
    
    /**
     * Send battery alarm
     */
    private fun sendBatteryAlarm(batteryLevel: Int) {
        val message = "Battery level is low: ${batteryLevel}%"
        webSocketClient.sendAlarm("battery_low", message, "warning")
    }
    
    /**
     * Send signal alarm
     */
    private fun sendSignalAlarm(signalLevel: Int, allSignals: List<Int>) {
        // Signal alarm gönderimi devre dışı bırakıldı
        val message = "Signal strength is low: ${signalLevel}% (All signals: ${allSignals.joinToString(", ")})"
        Log.w(TAG, "Signal alarm would be sent: $message (but signal alarms are disabled)")
        // webSocketClient.sendAlarm("signal_low", message, "warning")
    }
    
    /**
     * Send offline alarm
     */
    private fun sendOfflineAlarm(thresholdMinutes: Int) {
        val message = "Device has been offline for more than ${thresholdMinutes} minutes"
        webSocketClient.sendAlarm("device_offline", message, "critical")
    }
    
    /**
     * Send SIM balance alarm
     */
    private fun sendSimBalanceAlarm(simSlot: Int, balance: Double) {
        val message = "SIM${simSlot} balance is low: $${balance}"
        webSocketClient.sendAlarm("sim_balance_low", message, "warning")
    }
    
    /**
     * Send error alarm
     */
    private fun sendErrorAlarm(errorCount: Int) {
        val message = "High error count detected: $errorCount errors"
        webSocketClient.sendAlarm("high_error_count", message, "error")
    }
    
    /**
     * Send online notification
     */
    private fun sendOnlineNotification() {
        webSocketClient.sendDeviceStatus("online", mapOf("message" to "Device is back online"))
    }
    
    /**
     * Cleanup resources
     */
    fun cleanup() {
        stopMonitoring()
        scope.cancel()
    }
} 