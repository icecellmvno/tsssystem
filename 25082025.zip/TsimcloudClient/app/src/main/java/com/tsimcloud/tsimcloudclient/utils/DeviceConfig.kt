package com.tsimcloud.tsimcloudclient.utils

import com.google.gson.annotations.SerializedName

data class DeviceConfig(
    @SerializedName("device_group")
    val deviceGroup: String,
    
    @SerializedName("country_site")
    val countrySite: String,
    
    @SerializedName("websocket_url")
    val websocketUrl: String,
    
    @SerializedName("api_key")
    val apiKey: String,
    
    @SerializedName("battery_low_threshold")
    val batteryLowThreshold: Int = 20, // Varsayılan değer
    
    @SerializedName("error_count_threshold")
    val errorCountThreshold: Int = 5, // Varsayılan değer
    
    @SerializedName("offline_threshold_minutes")
    val offlineThresholdMinutes: Int = 5, // Varsayılan değer
    
    @SerializedName("signal_low_threshold")
    val signalLowThreshold: Int = 2, // Varsayılan değer
    
    @SerializedName("low_balance_threshold")
    val lowBalanceThreshold: String? = "10.00", // Varsayılan değer
    
    @SerializedName("enable_battery_alarms")
    val enableBatteryAlarms: Boolean = true, // Varsayılan değer
    
    @SerializedName("enable_error_alarms")
    val enableErrorAlarms: Boolean = true, // Varsayılan değer
    
    @SerializedName("enable_offline_alarms")
    val enableOfflineAlarms: Boolean = true, // Varsayılan değer
    
    @SerializedName("enable_signal_alarms")
    val enableSignalAlarms: Boolean = true, // Varsayılan değer
    
    @SerializedName("enable_sim_balance_alarms")
    val enableSimBalanceAlarms: Boolean = true, // Varsayılan değer
    
    @SerializedName("auto_disable_sim_on_alarm")
    val autoDisableSimOnAlarm: Boolean = false, // Varsayılan değer
    
    @SerializedName("sim1_daily_sms_limit")
    val sim1DailySmsLimit: Int = 100, // Varsayılan değer
    
    @SerializedName("sim1_monthly_sms_limit")
    val sim1MonthlySmsLimit: Int = 1000, // Varsayılan değer
    
    @SerializedName("sim2_daily_sms_limit")
    val sim2DailySmsLimit: Int = 100, // Varsayılan değer
    
    @SerializedName("sim2_monthly_sms_limit")
    val sim2MonthlySmsLimit: Int = 1000, // Varsayılan değer
    
    @SerializedName("enable_sms_limits")
    val enableSmsLimits: Boolean = false, // Varsayılan değer
    
    @SerializedName("sms_limit_reset_hour")
    val smsLimitResetHour: Int = 0, // Varsayılan değer
    
    @SerializedName("sim1_guard_interval")
    val sim1GuardInterval: Int = 1, // Varsayılan değer
    
    @SerializedName("sim2_guard_interval")
    val sim2GuardInterval: Int = 1, // Varsayılan değer
    
    @SerializedName("timestamp")
    val timestamp: String? = null // Nullable yapıldı
) {
    /**
     * Get formatted timestamp or current time if null
     */
    fun getFormattedTimestamp(): String {
        return timestamp ?: java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
    }
}