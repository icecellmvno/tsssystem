package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import org.json.JSONObject

class PreferencesManager(context: Context) {
    
    companion object {
        private const val PREF_NAME = "tsimcloud_preferences"
        
        // Device Configuration Keys
        private const val KEY_DEVICE_GROUP = "device_group"
        private const val KEY_countrySite = "countrySite"
        private const val KEY_WEBSOCKET_URL = "websocket_url"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_QUEUE_NAME = "queue_name"
        
        // Alarm Threshold Keys
        private const val KEY_BATTERY_LOW_THRESHOLD = "battery_low_threshold"
        private const val KEY_ERROR_COUNT_THRESHOLD = "error_count_threshold"
        private const val KEY_OFFLINE_THRESHOLD_MINUTES = "offline_threshold_minutes"
        private const val KEY_SIGNAL_LOW_THRESHOLD = "signal_low_threshold"
        private const val KEY_LOW_BALANCE_THRESHOLD = "low_balance_threshold"
        
        // Alarm Enable Keys
        private const val KEY_ENABLE_BATTERY_ALARMS = "enable_battery_alarms"
        private const val KEY_ENABLE_ERROR_ALARMS = "enable_error_alarms"
        private const val KEY_ENABLE_OFFLINE_ALARMS = "enable_offline_alarms"
        private const val KEY_ENABLE_SIGNAL_ALARMS = "enable_signal_alarms"
        private const val KEY_ENABLE_SIM_BALANCE_ALARMS = "enable_sim_balance_alarms"
        private const val KEY_AUTO_DISABLE_SIM_ON_ALARM = "auto_disable_sim_on_alarm"
        
        // SMS Limit Keys
        private const val KEY_SIM1_DAILY_SMS_LIMIT = "sim1_daily_sms_limit"
        private const val KEY_SIM1_MONTHLY_SMS_LIMIT = "sim1_monthly_sms_limit"
        private const val KEY_SIM2_DAILY_SMS_LIMIT = "sim2_daily_sms_limit"
        private const val KEY_SIM2_MONTHLY_SMS_LIMIT = "sim2_monthly_sms_limit"
        private const val KEY_ENABLE_SMS_LIMITS = "enable_sms_limits"
        private const val KEY_SMS_LIMIT_RESET_HOUR = "sms_limit_reset_hour"
        
        // Guard Interval Keys
        private const val KEY_SIM1_GUARD_INTERVAL = "sim1_guard_interval"
        private const val KEY_SIM2_GUARD_INTERVAL = "sim2_guard_interval"
        
        // Timestamp Key
        private const val KEY_TIMESTAMP = "timestamp"
        
        // Configuration Status
        private const val KEY_IS_CONFIGURED = "is_configured"
        
        // SIM Card Change Tracking
        private const val KEY_LAST_SIM_CARDS = "last_sim_cards"
        
        // Auto Reconnect Settings
        private const val KEY_AUTO_RECONNECT = "auto_reconnect"
    }
    
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()
    
    /**
     * Save device configuration from QR scan
     */
    fun saveDeviceConfig(config: DeviceConfig) {
        android.util.Log.d("PreferencesManager", "Saving device configuration...")
        android.util.Log.d("PreferencesManager", "Device Group: ${config.deviceGroup}")
        android.util.Log.d("PreferencesManager", "Site Name: ${config.countrySite}")
        android.util.Log.d("PreferencesManager", "WebSocket URL: ${config.websocketUrl}")
        android.util.Log.d("PreferencesManager", "API Key: ${config.apiKey}")

        
        val editor = sharedPreferences.edit()
        
        // Device Configuration
        editor.putString(KEY_DEVICE_GROUP, config.deviceGroup)
        editor.putString(KEY_countrySite, config.countrySite)
        editor.putString(KEY_WEBSOCKET_URL, config.websocketUrl)
        editor.putString(KEY_API_KEY, config.apiKey)

        
        // Alarm Thresholds
        editor.putInt(KEY_BATTERY_LOW_THRESHOLD, config.batteryLowThreshold)
        editor.putInt(KEY_ERROR_COUNT_THRESHOLD, config.errorCountThreshold)
        editor.putInt(KEY_OFFLINE_THRESHOLD_MINUTES, config.offlineThresholdMinutes)
        editor.putInt(KEY_SIGNAL_LOW_THRESHOLD, config.signalLowThreshold)
        editor.putFloat(KEY_LOW_BALANCE_THRESHOLD, config.lowBalanceThreshold?.toFloatOrNull() ?: 10.0f)
        
        // Alarm Settings
        editor.putBoolean(KEY_ENABLE_BATTERY_ALARMS, config.enableBatteryAlarms)
        editor.putBoolean(KEY_ENABLE_ERROR_ALARMS, config.enableErrorAlarms)
        editor.putBoolean(KEY_ENABLE_OFFLINE_ALARMS, config.enableOfflineAlarms)
        editor.putBoolean(KEY_ENABLE_SIGNAL_ALARMS, config.enableSignalAlarms)
        editor.putBoolean(KEY_ENABLE_SIM_BALANCE_ALARMS, config.enableSimBalanceAlarms)
        editor.putBoolean(KEY_AUTO_DISABLE_SIM_ON_ALARM, config.autoDisableSimOnAlarm)
        
        // SMS Limits
        editor.putInt(KEY_SIM1_DAILY_SMS_LIMIT, config.sim1DailySmsLimit)
        editor.putInt(KEY_SIM1_MONTHLY_SMS_LIMIT, config.sim1MonthlySmsLimit)
        editor.putInt(KEY_SIM2_DAILY_SMS_LIMIT, config.sim2DailySmsLimit)
        editor.putInt(KEY_SIM2_MONTHLY_SMS_LIMIT, config.sim2MonthlySmsLimit)
        editor.putBoolean(KEY_ENABLE_SMS_LIMITS, config.enableSmsLimits)
        editor.putInt(KEY_SMS_LIMIT_RESET_HOUR, config.smsLimitResetHour)
        
        // Guard Intervals
        editor.putInt(KEY_SIM1_GUARD_INTERVAL, config.sim1GuardInterval)
        editor.putInt(KEY_SIM2_GUARD_INTERVAL, config.sim2GuardInterval)
        
        // Timestamp
        editor.putString(KEY_TIMESTAMP, config.timestamp)
        
        // Mark as configured
        editor.putBoolean(KEY_IS_CONFIGURED, true)
        
        editor.apply()
        
        android.util.Log.d("PreferencesManager", "Device configuration saved successfully")
        
        // Verify saved configuration
        val savedConfig = getDeviceConfig()
        if (savedConfig != null) {
            android.util.Log.d("PreferencesManager", "Verification - Saved WebSocket URL: ${savedConfig.websocketUrl}")
            android.util.Log.d("PreferencesManager", "Verification - Saved API Key: ${savedConfig.apiKey}")

        } else {
            android.util.Log.e("PreferencesManager", "Verification failed - Could not retrieve saved configuration")
        }
    }
    
    /**
     * Get device configuration
     */
    fun getDeviceConfig(): DeviceConfig? {
        if (!isConfigured()) return null
        
        return try {
            android.util.Log.d("PreferencesManager", "Getting device config...")
            
            val deviceGroup = getString(KEY_DEVICE_GROUP, "")
            val countrySite = getString(KEY_countrySite, "")
            val websocketUrl = getString(KEY_WEBSOCKET_URL, "")
            val apiKey = getString(KEY_API_KEY, "")
            val queueName = getString(KEY_QUEUE_NAME, "")
            
            android.util.Log.d("PreferencesManager", "Device Group: $deviceGroup")
            android.util.Log.d("PreferencesManager", "Site Name: $countrySite")
            android.util.Log.d("PreferencesManager", "WebSocket URL: $websocketUrl")
            android.util.Log.d("PreferencesManager", "API Key: $apiKey")
            android.util.Log.d("PreferencesManager", "Queue Name: $queueName")
            
            DeviceConfig(
                deviceGroup = deviceGroup,
                countrySite = countrySite,
                websocketUrl = websocketUrl,
                apiKey = apiKey,

                batteryLowThreshold = getInt(KEY_BATTERY_LOW_THRESHOLD, 10),
                errorCountThreshold = getInt(KEY_ERROR_COUNT_THRESHOLD, 3),
                offlineThresholdMinutes = getInt(KEY_OFFLINE_THRESHOLD_MINUTES, 30),
                signalLowThreshold = getInt(KEY_SIGNAL_LOW_THRESHOLD, 20),
                lowBalanceThreshold = getFloat(KEY_LOW_BALANCE_THRESHOLD, 5.0f).toString(),
                enableBatteryAlarms = getBoolean(KEY_ENABLE_BATTERY_ALARMS, true),
                enableErrorAlarms = getBoolean(KEY_ENABLE_ERROR_ALARMS, true),
                enableOfflineAlarms = getBoolean(KEY_ENABLE_OFFLINE_ALARMS, true),
                enableSignalAlarms = getBoolean(KEY_ENABLE_SIGNAL_ALARMS, true),
                enableSimBalanceAlarms = getBoolean(KEY_ENABLE_SIM_BALANCE_ALARMS, true),
                autoDisableSimOnAlarm = getBoolean(KEY_AUTO_DISABLE_SIM_ON_ALARM, true),
                sim1DailySmsLimit = getInt(KEY_SIM1_DAILY_SMS_LIMIT, 100),
                sim1MonthlySmsLimit = getInt(KEY_SIM1_MONTHLY_SMS_LIMIT, 3000),
                sim2DailySmsLimit = getInt(KEY_SIM2_DAILY_SMS_LIMIT, 100),
                sim2MonthlySmsLimit = getInt(KEY_SIM2_MONTHLY_SMS_LIMIT, 3000),
                enableSmsLimits = getBoolean(KEY_ENABLE_SMS_LIMITS, true),
                smsLimitResetHour = getInt(KEY_SMS_LIMIT_RESET_HOUR, 0),
                        sim1GuardInterval = getInt(KEY_SIM1_GUARD_INTERVAL, 240), // 4 dakika = 240 saniye
        sim2GuardInterval = getInt(KEY_SIM2_GUARD_INTERVAL, 300), // 5 dakika = 300 saniye
                timestamp = getString(KEY_TIMESTAMP, "")
            ).also {
                android.util.Log.d("PreferencesManager", "DeviceConfig created successfully")
            }
        } catch (e: Exception) {
            android.util.Log.e("PreferencesManager", "Error creating DeviceConfig", e)
            null
        }
    }
    
    /**
     * Check if device is configured
     */
    fun isConfigured(): Boolean {
        return getBoolean(KEY_IS_CONFIGURED, false)
    }
    
    /**
     * Clear all configuration
     */
    fun clearConfiguration() {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }
    
    fun saveSettingsFromJson(settings: JSONObject) {
        val editor = sharedPreferences.edit()
        editor.putInt("battery_low_threshold", settings.optInt("battery_low_threshold", 20))
        editor.putInt("error_count_threshold", settings.optInt("error_count_threshold", 5))
        editor.putInt("offline_threshold_minutes", settings.optInt("offline_threshold_minutes", 5))
        editor.putInt("signal_low_threshold", settings.optInt("signal_low_threshold", 2))
        editor.putFloat("low_balance_threshold", settings.optString("low_balance_threshold", "10.00").toFloatOrNull() ?: 10.0f)
        editor.putBoolean("enable_battery_alarms", settings.optBoolean("enable_battery_alarms", true))
        editor.putBoolean("enable_error_alarms", settings.optBoolean("enable_error_alarms", true))
        editor.putBoolean("enable_offline_alarms", settings.optBoolean("enable_offline_alarms", true))
        editor.putBoolean("enable_signal_alarms", settings.optBoolean("enable_signal_alarms", true))
        editor.putBoolean("enable_sim_balance_alarms", settings.optBoolean("enable_sim_balance_alarms", true))
        editor.putBoolean("auto_disable_sim_on_alarm", settings.optBoolean("auto_disable_sim_on_alarm", false))
        editor.putInt("sim1_daily_sms_limit", settings.optInt("sim1_daily_sms_limit", 100))
        editor.putInt("sim1_monthly_sms_limit", settings.optInt("sim1_monthly_sms_limit", 1000))
        editor.putInt("sim2_daily_sms_limit", settings.optInt("sim2_daily_sms_limit", 100))
        editor.putInt("sim2_monthly_sms_limit", settings.optInt("sim2_monthly_sms_limit", 1000))
        editor.putBoolean("enable_sms_limits", settings.optBoolean("enable_sms_limits", false))
        editor.putInt("sms_limit_reset_hour", settings.optInt("sms_limit_reset_hour", 0))
        editor.putInt("sim1_guard_interval", settings.optInt("sim1_guard_interval", 1))
        editor.putInt("sim2_guard_interval", settings.optInt("sim2_guard_interval", 1))
        editor.apply()
    }
    
    // Helper methods for getting values with defaults
    private fun getString(key: String, defaultValue: String): String {
        return sharedPreferences.getString(key, defaultValue) ?: defaultValue
    }
    
    private fun getInt(key: String, defaultValue: Int): Int {
        return sharedPreferences.getInt(key, defaultValue)
    }
    
    private fun getBoolean(key: String, defaultValue: Boolean): Boolean {
        return sharedPreferences.getBoolean(key, defaultValue)
    }
    
    private fun getFloat(key: String, defaultValue: Float): Float {
        return try {
            sharedPreferences.getFloat(key, defaultValue)
        } catch (e: ClassCastException) {
            // If the value is stored as String, try to convert it to Float
            val stringValue = sharedPreferences.getString(key, defaultValue.toString())
            stringValue?.toFloatOrNull() ?: defaultValue
        }
    }
    
    // Individual getter methods for easy access
    fun getWebsocketUrl(): String = getString(KEY_WEBSOCKET_URL, "")
    fun getApiKey(): String = getString(KEY_API_KEY, "")
    fun getQueueName(): String = getString(KEY_QUEUE_NAME, "")
    fun getDeviceGroup(): String = getString(KEY_DEVICE_GROUP, "")
    fun getcountrySite(): String = getString(KEY_countrySite, "")

    // Device Group Settings
    fun setBatteryLowThreshold(value: Int) {
        sharedPreferences.edit().putInt("battery_low_threshold", value).apply()
    }
    
    fun getBatteryLowThreshold(): Int {
        return sharedPreferences.getInt("battery_low_threshold", 20)
    }
    
    fun setErrorCountThreshold(value: Int) {
        sharedPreferences.edit().putInt("error_count_threshold", value).apply()
    }
    
    fun getErrorCountThreshold(): Int {
        return sharedPreferences.getInt("error_count_threshold", 5)
    }
    
    fun setOfflineThresholdMinutes(value: Int) {
        sharedPreferences.edit().putInt("offline_threshold_minutes", value).apply()
    }
    
    fun getOfflineThresholdMinutes(): Int {
        return sharedPreferences.getInt("offline_threshold_minutes", 30)
    }
    
    fun setSignalLowThreshold(value: Int) {
        sharedPreferences.edit().putInt("signal_low_threshold", value).apply()
    }
    
    fun getSignalLowThreshold(): Int {
        return sharedPreferences.getInt("signal_low_threshold", 10)
    }
    
    fun setLowBalanceThreshold(value: Double) {
        sharedPreferences.edit().putFloat("low_balance_threshold", value.toFloat()).apply()
    }
    
    fun getLowBalanceThreshold(): Double {
        return try {
            sharedPreferences.getFloat("low_balance_threshold", 5.0f).toDouble()
        } catch (e: ClassCastException) {
            // If the value is stored as String, try to convert it to Float
            val stringValue = sharedPreferences.getString("low_balance_threshold", "5.0")
            stringValue?.toFloatOrNull()?.toDouble() ?: 5.0
        }
    }
    
    // Alarm Settings
    fun setEnableBatteryAlarms(value: Boolean) {
        sharedPreferences.edit().putBoolean("enable_battery_alarms", value).apply()
    }
    
    fun isEnableBatteryAlarms(): Boolean {
        return sharedPreferences.getBoolean("enable_battery_alarms", true)
    }
    
    fun setEnableErrorAlarms(value: Boolean) {
        sharedPreferences.edit().putBoolean("enable_error_alarms", value).apply()
    }
    
    fun isEnableErrorAlarms(): Boolean {
        return sharedPreferences.getBoolean("enable_error_alarms", true)
    }
    
    fun setEnableOfflineAlarms(value: Boolean) {
        sharedPreferences.edit().putBoolean("enable_offline_alarms", value).apply()
    }
    
    fun isEnableOfflineAlarms(): Boolean {
        return sharedPreferences.getBoolean("enable_offline_alarms", true)
    }
    
    fun setEnableSignalAlarms(value: Boolean) {
        sharedPreferences.edit().putBoolean("enable_signal_alarms", value).apply()
    }
    
    fun isEnableSignalAlarms(): Boolean {
        return sharedPreferences.getBoolean("enable_signal_alarms", true)
    }
    
    fun setEnableSimBalanceAlarms(value: Boolean) {
        sharedPreferences.edit().putBoolean("enable_sim_balance_alarms", value).apply()
    }
    
    fun isEnableSimBalanceAlarms(): Boolean {
        return sharedPreferences.getBoolean("enable_sim_balance_alarms", true)
    }
    
    fun setAutoDisableSimOnAlarm(value: Boolean) {
        sharedPreferences.edit().putBoolean("auto_disable_sim_on_alarm", value).apply()
    }
    
    fun isAutoDisableSimOnAlarm(): Boolean {
        return sharedPreferences.getBoolean("auto_disable_sim_on_alarm", true)
    }
    
    // SMS Limit Settings
    fun setSim1DailySmsLimit(value: Int) {
        sharedPreferences.edit().putInt("sim1_daily_sms_limit", value).apply()
    }
    
    fun getSim1DailySmsLimit(): Int {
        return sharedPreferences.getInt("sim1_daily_sms_limit", 200)
    }
    
    fun setSim1MonthlySmsLimit(value: Int) {
        sharedPreferences.edit().putInt("sim1_monthly_sms_limit", value).apply()
    }
    
    fun getSim1MonthlySmsLimit(): Int {
        return sharedPreferences.getInt("sim1_monthly_sms_limit", 6000)
    }
    
    fun setSim2DailySmsLimit(value: Int) {
        sharedPreferences.edit().putInt("sim2_daily_sms_limit", value).apply()
    }
    
    fun getSim2DailySmsLimit(): Int {
        return sharedPreferences.getInt("sim2_daily_sms_limit", 200)
    }
    
    fun setSim2MonthlySmsLimit(value: Int) {
        sharedPreferences.edit().putInt("sim2_monthly_sms_limit", value).apply()
    }
    
    fun getSim2MonthlySmsLimit(): Int {
        return sharedPreferences.getInt("sim2_monthly_sms_limit", 6000)
    }
    
    fun setEnableSmsLimits(value: Boolean) {
        sharedPreferences.edit().putBoolean("enable_sms_limits", value).apply()
    }
    
    fun isSmsLimitsEnabled(): Boolean {
        return sharedPreferences.getBoolean("enable_sms_limits", true)
    }
    
    fun setSmsLimitResetHour(value: Int) {
        sharedPreferences.edit().putInt("sms_limit_reset_hour", value).apply()
    }
    
    fun getSmsLimitResetHour(): Int {
        return sharedPreferences.getInt("sms_limit_reset_hour", 0)
    }
    
    fun setSim1GuardInterval(value: Int) {
        sharedPreferences.edit().putInt("sim1_guard_interval", value).apply()
    }
    
    fun getSim1GuardInterval(): Int {
        return sharedPreferences.getInt("sim1_guard_interval", 240) // 4 dakika = 240 saniye
    }
    
    fun setSim2GuardInterval(value: Int) {
        sharedPreferences.edit().putInt("sim2_guard_interval", value).apply()
    }
    
    fun getSim2GuardInterval(): Int {
        return sharedPreferences.getInt("sim2_guard_interval", 300) // 5 dakika = 300 saniye
    }
    
    // SIM Card Change Tracking
    fun saveLastSimCards(simCardsJson: String) {
        sharedPreferences.edit().putString(KEY_LAST_SIM_CARDS, simCardsJson).apply()
    }
    
    fun getLastSimCards(): String {
        return sharedPreferences.getString(KEY_LAST_SIM_CARDS, "") ?: ""
    }
    
    fun clearLastSimCards() {
        sharedPreferences.edit().remove(KEY_LAST_SIM_CARDS).apply()
    }
    
    // IMSI-based SIM Card Tracking for Dual SIM
    fun saveLastImsiList(imsiList: List<String>) {
        val imsiJson = org.json.JSONArray(imsiList).toString()
        sharedPreferences.edit().putString("last_imsi_list", imsiJson).apply()
    }
    
    fun getLastImsiList(): List<String> {
        val imsiJson = sharedPreferences.getString("last_imsi_list", "[]") ?: "[]"
        return try {
            val jsonArray = org.json.JSONArray(imsiJson)
            val imsiList = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) {
                imsiList.add(jsonArray.getString(i))
            }
            imsiList
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    fun clearLastImsiList() {
        sharedPreferences.edit().remove("last_imsi_list").apply()
    }
    
    // SIM Card Change Detection Settings
    fun setEnableImsiBasedDetection(value: Boolean) {
        sharedPreferences.edit().putBoolean("enable_imsi_based_detection", value).apply()
    }
    
    fun isImsiBasedDetectionEnabled(): Boolean {
        return sharedPreferences.getBoolean("enable_imsi_based_detection", true)
    }
    
    fun setSimCardChangeAlarmDelay(value: Int) {
        sharedPreferences.edit().putInt("sim_card_change_alarm_delay", value).apply()
    }
    
    fun getSimCardChangeAlarmDelay(): Int {
        return sharedPreferences.getInt("sim_card_change_alarm_delay", 5000) // 5 saniye
    }
    
    // Last SIM card change timestamp
    fun saveLastSimCardChangeTime(timestamp: Long) {
        sharedPreferences.edit().putLong("last_sim_card_change_time", timestamp).apply()
    }
    
    fun getLastSimCardChangeTime(): Long {
        return sharedPreferences.getLong("last_sim_card_change_time", 0L)
    }
    
    // Check if enough time has passed since last SIM card change
    fun shouldSendSimCardChangeAlarm(): Boolean {
        val lastChangeTime = getLastSimCardChangeTime()
        val currentTime = System.currentTimeMillis()
        val delay = getSimCardChangeAlarmDelay()
        
        return (currentTime - lastChangeTime) > delay
    }
    
    // Auto Reconnect Settings
    fun saveAutoReconnect(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_AUTO_RECONNECT, enabled).apply()
    }
    
    fun getAutoReconnect(): Boolean? {
        return if (sharedPreferences.contains(KEY_AUTO_RECONNECT)) {
            sharedPreferences.getBoolean(KEY_AUTO_RECONNECT, true)
        } else {
            null // Ayar henüz kaydedilmemiş
        }
    }
    
    fun isAutoReconnectEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_AUTO_RECONNECT, true)
    }
} 