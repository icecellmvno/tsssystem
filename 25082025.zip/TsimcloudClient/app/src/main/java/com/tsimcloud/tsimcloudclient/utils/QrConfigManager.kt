package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException

class QrConfigManager(private val context: Context) {
    
    private val preferencesManager = PreferencesManager(context)
    private val gson = Gson()
    
    /**
     * Parse QR code JSON and save configuration
     */
    fun parseAndSaveQrConfig(qrJsonString: String): QrConfigResult {
        return try {
            android.util.Log.d("QrConfigManager", "Parsing QR JSON: $qrJsonString")
            // Parse JSON to DeviceConfig object
            val deviceConfig = gson.fromJson(qrJsonString, DeviceConfig::class.java)
            
            // Handle null values with defaults
            val processedConfig = deviceConfig.copy(
                lowBalanceThreshold = deviceConfig.lowBalanceThreshold ?: "10.00",
                timestamp = deviceConfig.timestamp ?: java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            )
            
            android.util.Log.d("QrConfigManager", "Processed config timestamp: ${processedConfig.timestamp}")
            
            // Validate required fields
            val validationResult = validateDeviceConfig(processedConfig)
            if (!validationResult.isValid) {
                return QrConfigResult.Error(validationResult.errorMessage)
            }
            
            // Save configuration to SharedPreferences
            preferencesManager.saveDeviceConfig(processedConfig)
            
            QrConfigResult.Success(processedConfig)
            
        } catch (e: JsonSyntaxException) {
            QrConfigResult.Error("Invalid JSON format: ${e.message}")
        } catch (e: Exception) {
            QrConfigResult.Error("Failed to parse QR configuration: ${e.message}")
        }
    }
    
    /**
     * Validate device configuration
     */
    private fun validateDeviceConfig(config: DeviceConfig): ValidationResult {
        if (config.deviceGroup.isBlank()) {
            return ValidationResult(false, "Device group is required")
        }
        
        if (config.countrySite.isBlank()) {
            return ValidationResult(false, "Country site is required")
        }
        
        if (config.websocketUrl.isBlank()) {
            return ValidationResult(false, "WebSocket URL is required")
        }
        
        if (!config.websocketUrl.startsWith("ws://") && !config.websocketUrl.startsWith("wss://")) {
            return ValidationResult(false, "Invalid WebSocket URL format")
        }
        
        if (config.apiKey.isBlank()) {
            return ValidationResult(false, "API key is required")
        }
        

        
        // Validate low balance threshold if provided
        if (config.lowBalanceThreshold != null && config.lowBalanceThreshold.isNotBlank()) {
            if (config.lowBalanceThreshold.toFloatOrNull() == null) {
                return ValidationResult(false, "Invalid low balance threshold format")
            }
        }
        
        // Diğer alanlar için varsayılan değerler kullanıldığından validasyon yapmaya gerek yok
        
        return ValidationResult(true, "")
    }
    
    /**
     * Get current device configuration
     */
    fun getCurrentConfig(): DeviceConfig? {
        return preferencesManager.getDeviceConfig()
    }
    
    /**
     * Check if device is configured
     */
    fun isDeviceConfigured(): Boolean {
        return preferencesManager.isConfigured()
    }
    
    /**
     * Clear device configuration
     */
    fun clearConfiguration() {
        preferencesManager.clearConfiguration()
    }
    
    /**
     * Get configuration summary for display
     */
    fun getConfigurationSummary(): String {
        val config = getCurrentConfig() ?: return "No configuration found"
        
        return buildString {
            appendLine("Device Group: ${config.deviceGroup}")
            appendLine("Country Site: ${config.countrySite}")
            appendLine("WebSocket URL: ${config.websocketUrl}")
            appendLine("Battery Threshold: ${config.batteryLowThreshold}%")
            appendLine("Signal Threshold: ${config.signalLowThreshold}%")
            appendLine("Offline Threshold: ${config.offlineThresholdMinutes} minutes")
            appendLine("SMS Limits: ${if (config.enableSmsLimits) "Enabled" else "Disabled"}")
            appendLine("SIM1 Daily Limit: ${config.sim1DailySmsLimit}")
            appendLine("SIM2 Daily Limit: ${config.sim2DailySmsLimit}")
            appendLine("Configured at: ${config.getFormattedTimestamp()}")
        }
    }
    
    /**
     * Get alarm settings summary
     */
    fun getAlarmSettingsSummary(): String {
        val config = getCurrentConfig() ?: return "No configuration found"
        
        return buildString {
            appendLine("Battery Alarms: ${if (config.enableBatteryAlarms) "Enabled" else "Disabled"}")
            appendLine("Error Alarms: ${if (config.enableErrorAlarms) "Enabled" else "Disabled"}")
            appendLine("Offline Alarms: ${if (config.enableOfflineAlarms) "Enabled" else "Disabled"}")
            appendLine("Signal Alarms: ${if (config.enableSignalAlarms) "Enabled" else "Disabled"}")
            appendLine("SIM Balance Alarms: ${if (config.enableSimBalanceAlarms) "Enabled" else "Disabled"}")
            appendLine("Auto Disable SIM: ${if (config.autoDisableSimOnAlarm) "Enabled" else "Disabled"}")
        }
    }
    
    /**
     * Get SMS limits summary
     */
    fun getSmsLimitsSummary(): String {
        val config = getCurrentConfig() ?: return "No configuration found"
        
        return buildString {
            appendLine("SMS Limits: ${if (config.enableSmsLimits) "Enabled" else "Disabled"}")
            appendLine("Reset Hour: ${config.smsLimitResetHour}:00")
            appendLine("SIM1 Daily: ${config.sim1DailySmsLimit}")
            appendLine("SIM1 Monthly: ${config.sim1MonthlySmsLimit}")
            appendLine("SIM2 Daily: ${config.sim2DailySmsLimit}")
            appendLine("SIM2 Monthly: ${config.sim2MonthlySmsLimit}")
        }
    }
    
    /**
     * Get individual configuration values
     */
    fun getWebsocketUrl(): String? {
        return getCurrentConfig()?.websocketUrl
    }
    
    fun getApiKey(): String? {
        return getCurrentConfig()?.apiKey
    }
    
    fun getDeviceGroup(): String? {
        return getCurrentConfig()?.deviceGroup
    }
    
    fun getCountrySite(): String? {
        return getCurrentConfig()?.countrySite
    }
    
    /**
     * Update individual configuration values
     */
    fun setWebsocketUrl(url: String) {
        val currentConfig = getCurrentConfig() ?: return
        val updatedConfig = currentConfig.copy(websocketUrl = url)
        preferencesManager.saveDeviceConfig(updatedConfig)
    }
    
    fun setApiKey(apiKey: String) {
        val currentConfig = getCurrentConfig() ?: return
        val updatedConfig = currentConfig.copy(apiKey = apiKey)
        preferencesManager.saveDeviceConfig(updatedConfig)
    }
    
    fun setDeviceGroup(deviceGroup: String) {
        val currentConfig = getCurrentConfig() ?: return
        val updatedConfig = currentConfig.copy(deviceGroup = deviceGroup)
        preferencesManager.saveDeviceConfig(updatedConfig)
    }
    
    fun setCountrySite(countrySite: String) {
        val currentConfig = getCurrentConfig() ?: return
        val updatedConfig = currentConfig.copy(countrySite = countrySite)
        preferencesManager.saveDeviceConfig(updatedConfig)
    }
}

/**
 * Result class for QR configuration operations
 */
sealed class QrConfigResult {
    data class Success(val config: DeviceConfig) : QrConfigResult()
    data class Error(val message: String) : QrConfigResult()
}

/**
 * Validation result class
 */
data class ValidationResult(
    val isValid: Boolean,
    val errorMessage: String
) 