package com.tsimcloud.tsimcloudclient.utils

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import org.json.JSONObject
import java.util.*

class SmsDatabase(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val TAG = "SmsDatabase"
        private const val DATABASE_NAME = "sms_queue.db"
        private const val DATABASE_VERSION = 1

        // Delivery Reports Queue Table
        private const val TABLE_DELIVERY_REPORTS = "delivery_reports_queue"
        private const val COLUMN_REPORT_ID = "report_id"
        private const val COLUMN_SMS_ID = "sms_id"
        private const val COLUMN_PHONE_NUMBER = "phone_number"
        private const val COLUMN_SIM_SLOT = "sim_slot"
        private const val COLUMN_DELIVERY_STATUS = "delivery_status"
        private const val COLUMN_DELIVERY_TIME = "delivery_time"
        private const val COLUMN_FAILURE_REASON = "failure_reason"
        private const val COLUMN_SENT_TIME = "sent_time"
        private const val COLUMN_IS_SENT_TO_SERVER = "is_sent_to_server"
        private const val COLUMN_SERVER_SENT_TIME = "server_sent_time"

        // USSD Logs Queue Table
        private const val TABLE_USSD_LOGS = "ussd_logs_queue"
        private const val COLUMN_LOG_ID = "log_id"
        private const val COLUMN_USSD_CODE = "ussd_code"
        private const val COLUMN_RESPONSE = "response"
        private const val COLUMN_SESSION_ID = "session_id"
        private const val COLUMN_MESSAGE_ID = "message_id"
        private const val COLUMN_LOG_TYPE = "log_type"
        private const val COLUMN_LOG_TIME = "log_time"

        // Alarm Logs Queue Table
        private const val TABLE_ALARM_LOGS = "alarm_logs_queue"
        private const val COLUMN_ALARM_ID = "alarm_id"
        private const val COLUMN_ALARM_TYPE = "alarm_type"
        private const val COLUMN_ALARM_MESSAGE = "alarm_message"
        private const val COLUMN_ALARM_SEVERITY = "alarm_severity"
        private const val COLUMN_ALARM_TIME = "alarm_time"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create Delivery Reports Queue Table
        val createDeliveryReportsTable = """
            CREATE TABLE $TABLE_DELIVERY_REPORTS (
                $COLUMN_REPORT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_SMS_ID TEXT NOT NULL,
                $COLUMN_PHONE_NUMBER TEXT NOT NULL,
                $COLUMN_SIM_SLOT INTEGER NOT NULL,
                $COLUMN_DELIVERY_STATUS TEXT NOT NULL,
                $COLUMN_DELIVERY_TIME INTEGER,
                $COLUMN_FAILURE_REASON TEXT,
                $COLUMN_SENT_TIME INTEGER NOT NULL,
                $COLUMN_IS_SENT_TO_SERVER INTEGER DEFAULT 0,
                $COLUMN_SERVER_SENT_TIME INTEGER
            )
        """.trimIndent()

        // Create USSD Logs Queue Table
        val createUssdLogsTable = """
            CREATE TABLE $TABLE_USSD_LOGS (
                $COLUMN_LOG_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USSD_CODE TEXT NOT NULL,
                $COLUMN_RESPONSE TEXT,
                $COLUMN_SESSION_ID TEXT NOT NULL,
                $COLUMN_MESSAGE_ID TEXT NOT NULL,
                $COLUMN_SIM_SLOT INTEGER NOT NULL,
                $COLUMN_LOG_TYPE TEXT NOT NULL,
                $COLUMN_LOG_TIME INTEGER NOT NULL,
                $COLUMN_IS_SENT_TO_SERVER INTEGER DEFAULT 0,
                $COLUMN_SERVER_SENT_TIME INTEGER
            )
        """.trimIndent()

        // Create Alarm Logs Queue Table
        val createAlarmLogsTable = """
            CREATE TABLE $TABLE_ALARM_LOGS (
                $COLUMN_ALARM_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_ALARM_TYPE TEXT NOT NULL,
                $COLUMN_ALARM_MESSAGE TEXT NOT NULL,
                $COLUMN_ALARM_SEVERITY TEXT NOT NULL,
                $COLUMN_ALARM_TIME INTEGER NOT NULL,
                $COLUMN_IS_SENT_TO_SERVER INTEGER DEFAULT 0,
                $COLUMN_SERVER_SENT_TIME INTEGER
            )
        """.trimIndent()

        db.execSQL(createDeliveryReportsTable)
        db.execSQL(createUssdLogsTable)
        db.execSQL(createAlarmLogsTable)
        
        Log.d(TAG, "SMS Database created successfully")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Drop and recreate tables for now
        db.execSQL("DROP TABLE IF EXISTS $TABLE_DELIVERY_REPORTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USSD_LOGS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ALARM_LOGS")
        onCreate(db)
    }

    // Delivery Reports Queue Methods
    fun addDeliveryReport(
        smsId: String,
        phoneNumber: String,
        simSlot: Int,
        deliveryStatus: String,
        failureReason: String? = null
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_SMS_ID, smsId)
            put(COLUMN_PHONE_NUMBER, phoneNumber)
            put(COLUMN_SIM_SLOT, simSlot)
            put(COLUMN_DELIVERY_STATUS, deliveryStatus)
            put(COLUMN_DELIVERY_TIME, System.currentTimeMillis())
            put(COLUMN_FAILURE_REASON, failureReason)
            put(COLUMN_SENT_TIME, System.currentTimeMillis())
            put(COLUMN_IS_SENT_TO_SERVER, 0)
        }

        val id = db.insert(TABLE_DELIVERY_REPORTS, null, values)
        Log.d(TAG, "Added delivery report: ID=$id, SMSID=$smsId, Status=$deliveryStatus")
        return id
    }

    fun getPendingDeliveryReports(): List<DeliveryReportItem> {
        val db = this.readableDatabase
        
        val cursor = db.query(
            TABLE_DELIVERY_REPORTS,
            null,
            "$COLUMN_IS_SENT_TO_SERVER = 0",
            null,
            null,
            null,
            "$COLUMN_SENT_TIME ASC"
        )

        val items = mutableListOf<DeliveryReportItem>()
        cursor.use {
            while (it.moveToNext()) {
                items.add(DeliveryReportItem(
                    reportId = it.getLong(it.getColumnIndexOrThrow(COLUMN_REPORT_ID)),
                    smsId = it.getString(it.getColumnIndexOrThrow(COLUMN_SMS_ID)),
                    phoneNumber = it.getString(it.getColumnIndexOrThrow(COLUMN_PHONE_NUMBER)),
                    simSlot = it.getInt(it.getColumnIndexOrThrow(COLUMN_SIM_SLOT)),
                    deliveryStatus = it.getString(it.getColumnIndexOrThrow(COLUMN_DELIVERY_STATUS)),
                    deliveryTime = it.getLong(it.getColumnIndexOrThrow(COLUMN_DELIVERY_TIME)),
                    failureReason = it.getString(it.getColumnIndexOrThrow(COLUMN_FAILURE_REASON)),
                    sentTime = it.getLong(it.getColumnIndexOrThrow(COLUMN_SENT_TIME)),
                    isSentToServer = it.getInt(it.getColumnIndexOrThrow(COLUMN_IS_SENT_TO_SERVER)) == 1,
                    serverSentTime = it.getLong(it.getColumnIndexOrThrow(COLUMN_SERVER_SENT_TIME))
                ))
            }
        }
        
        return items
    }

    fun markDeliveryReportAsSent(reportId: Long) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_IS_SENT_TO_SERVER, 1)
            put(COLUMN_SERVER_SENT_TIME, System.currentTimeMillis())
        }

        val rowsAffected = db.update(TABLE_DELIVERY_REPORTS, values, "$COLUMN_REPORT_ID = ?", arrayOf(reportId.toString()))
        Log.d(TAG, "Marked delivery report as sent: ReportID=$reportId, Rows affected=$rowsAffected")
    }

    // USSD Logs Queue Methods
    fun addUssdLog(
        ussdCode: String,
        response: String?,
        sessionId: String,
        messageId: String,
        simSlot: Int,
        logType: String
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USSD_CODE, ussdCode)
            put(COLUMN_RESPONSE, response)
            put(COLUMN_SESSION_ID, sessionId)
            put(COLUMN_MESSAGE_ID, messageId)
            put(COLUMN_SIM_SLOT, simSlot)
            put(COLUMN_LOG_TYPE, logType)
            put(COLUMN_LOG_TIME, System.currentTimeMillis())
            put(COLUMN_IS_SENT_TO_SERVER, 0)
        }

        val id = db.insert(TABLE_USSD_LOGS, null, values)
        Log.d(TAG, "Added USSD log: ID=$id, Code=$ussdCode, Type=$logType")
        return id
    }

    fun getPendingUssdLogs(): List<UssdLogItem> {
        val db = this.readableDatabase
        
        val cursor = db.query(
            TABLE_USSD_LOGS,
            null,
            "$COLUMN_IS_SENT_TO_SERVER = 0",
            null,
            null,
            null,
            "$COLUMN_LOG_TIME ASC"
        )

        val items = mutableListOf<UssdLogItem>()
        cursor.use {
            while (it.moveToNext()) {
                items.add(UssdLogItem(
                    logId = it.getLong(it.getColumnIndexOrThrow(COLUMN_LOG_ID)),
                    ussdCode = it.getString(it.getColumnIndexOrThrow(COLUMN_USSD_CODE)),
                    response = it.getString(it.getColumnIndexOrThrow(COLUMN_RESPONSE)),
                    sessionId = it.getString(it.getColumnIndexOrThrow(COLUMN_SESSION_ID)),
                    messageId = it.getString(it.getColumnIndexOrThrow(COLUMN_MESSAGE_ID)),
                    simSlot = it.getInt(it.getColumnIndexOrThrow(COLUMN_SIM_SLOT)),
                    logType = it.getString(it.getColumnIndexOrThrow(COLUMN_LOG_TYPE)),
                    logTime = it.getLong(it.getColumnIndexOrThrow(COLUMN_LOG_TIME)),
                    isSentToServer = it.getInt(it.getColumnIndexOrThrow(COLUMN_IS_SENT_TO_SERVER)) == 1,
                    serverSentTime = it.getLong(it.getColumnIndexOrThrow(COLUMN_SERVER_SENT_TIME))
                ))
            }
        }
        
        return items
    }

    fun markUssdLogAsSent(logId: Long) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_IS_SENT_TO_SERVER, 1)
            put(COLUMN_SERVER_SENT_TIME, System.currentTimeMillis())
        }

        val rowsAffected = db.update(TABLE_USSD_LOGS, values, "$COLUMN_LOG_ID = ?", arrayOf(logId.toString()))
        Log.d(TAG, "Marked USSD log as sent: LogID=$logId, Rows affected=$rowsAffected")
    }

    // Alarm Logs Queue Methods
    fun addAlarmLog(
        alarmType: String,
        alarmMessage: String,
        alarmSeverity: String
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_ALARM_TYPE, alarmType)
            put(COLUMN_ALARM_MESSAGE, alarmMessage)
            put(COLUMN_ALARM_SEVERITY, alarmSeverity)
            put(COLUMN_ALARM_TIME, System.currentTimeMillis())
            put(COLUMN_IS_SENT_TO_SERVER, 0)
        }

        val id = db.insert(TABLE_ALARM_LOGS, null, values)
        Log.d(TAG, "Added alarm log: ID=$id, Type=$alarmType, Severity=$alarmSeverity")
        return id
    }

    fun getPendingAlarmLogs(): List<AlarmLogItem> {
        val db = this.readableDatabase
        
        val cursor = db.query(
            TABLE_ALARM_LOGS,
            null,
            "$COLUMN_IS_SENT_TO_SERVER = 0",
            null,
            null,
            null,
            "$COLUMN_ALARM_TIME ASC"
        )

        val items = mutableListOf<AlarmLogItem>()
        cursor.use {
            while (it.moveToNext()) {
                items.add(AlarmLogItem(
                    alarmId = it.getLong(it.getColumnIndexOrThrow(COLUMN_ALARM_ID)),
                    alarmType = it.getString(it.getColumnIndexOrThrow(COLUMN_ALARM_TYPE)),
                    alarmMessage = it.getString(it.getColumnIndexOrThrow(COLUMN_ALARM_MESSAGE)),
                    alarmSeverity = it.getString(it.getColumnIndexOrThrow(COLUMN_ALARM_SEVERITY)),
                    alarmTime = it.getLong(it.getColumnIndexOrThrow(COLUMN_ALARM_TIME)),
                    isSentToServer = it.getInt(it.getColumnIndexOrThrow(COLUMN_IS_SENT_TO_SERVER)) == 1,
                    serverSentTime = it.getLong(it.getColumnIndexOrThrow(COLUMN_SERVER_SENT_TIME))
                ))
            }
        }
        
        return items
    }

    fun markAlarmLogAsSent(alarmId: Long) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_IS_SENT_TO_SERVER, 1)
            put(COLUMN_SERVER_SENT_TIME, System.currentTimeMillis())
        }

        val rowsAffected = db.update(TABLE_ALARM_LOGS, values, "$COLUMN_ALARM_ID = ?", arrayOf(alarmId.toString()))
        Log.d(TAG, "Marked alarm log as sent: AlarmID=$alarmId, Rows affected=$rowsAffected")
    }

    // Statistics Methods
    fun getDeliveryReportStats(): DeliveryReportStats {
        val db = this.readableDatabase
        
        // Get pending count
        val pendingCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_DELIVERY_REPORTS WHERE $COLUMN_IS_SENT_TO_SERVER = 0",
            null
        )
        val pendingCount = pendingCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        // Get sent count
        val sentCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_DELIVERY_REPORTS WHERE $COLUMN_IS_SENT_TO_SERVER = 1",
            null
        )
        val sentCount = sentCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        // Get delivered count
        val deliveredCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_DELIVERY_REPORTS WHERE $COLUMN_DELIVERY_STATUS = 'delivered'",
            null
        )
        val deliveredCount = deliveredCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        // Get failed count
        val failedCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_DELIVERY_REPORTS WHERE $COLUMN_DELIVERY_STATUS = 'failed'",
            null
        )
        val failedCount = failedCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        return DeliveryReportStats(pendingCount, sentCount, deliveredCount, failedCount)
    }

    fun getUssdLogStats(): UssdLogStats {
        val db = this.readableDatabase
        
        // Get pending count
        val pendingCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_USSD_LOGS WHERE $COLUMN_IS_SENT_TO_SERVER = 0",
            null
        )
        val pendingCount = pendingCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        // Get sent count
        val sentCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_USSD_LOGS WHERE $COLUMN_IS_SENT_TO_SERVER = 1",
            null
        )
        val sentCount = sentCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        return UssdLogStats(pendingCount, sentCount)
    }

    fun getAlarmLogStats(): AlarmLogStats {
        val db = this.readableDatabase
        
        // Get pending count
        val pendingCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_ALARM_LOGS WHERE $COLUMN_IS_SENT_TO_SERVER = 0",
            null
        )
        val pendingCount = pendingCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        // Get sent count
        val sentCursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_ALARM_LOGS WHERE $COLUMN_IS_SENT_TO_SERVER = 1",
            null
        )
        val sentCount = sentCursor.use { 
            if (it.moveToFirst()) it.getInt(0) else 0 
        }

        return AlarmLogStats(pendingCount, sentCount)
    }

    fun cleanupOldRecords(maxAgeDays: Int = 30) {
        val db = this.writableDatabase
        val cutoffTime = System.currentTimeMillis() - (maxAgeDays * 24 * 60 * 60 * 1000L)
        
        // Clean up old delivery reports
        val reportRowsDeleted = db.delete(
            TABLE_DELIVERY_REPORTS,
            "$COLUMN_SENT_TIME < ?",
            arrayOf(cutoffTime.toString())
        )
        
        // Clean up old USSD logs
        val ussdRowsDeleted = db.delete(
            TABLE_USSD_LOGS,
            "$COLUMN_LOG_TIME < ?",
            arrayOf(cutoffTime.toString())
        )
        
        // Clean up old alarm logs
        val alarmRowsDeleted = db.delete(
            TABLE_ALARM_LOGS,
            "$COLUMN_ALARM_TIME < ?",
            arrayOf(cutoffTime.toString())
        )
        
        Log.d(TAG, "Cleaned up old records: Delivery Reports=$reportRowsDeleted, USSD Logs=$ussdRowsDeleted, Alarm Logs=$alarmRowsDeleted")
    }
}

// Data Classes
data class DeliveryReportItem(
    val reportId: Long,
    val smsId: String,
    val phoneNumber: String,
    val simSlot: Int,
    val deliveryStatus: String,
    val deliveryTime: Long,
    val failureReason: String?,
    val sentTime: Long,
    val isSentToServer: Boolean,
    val serverSentTime: Long
)

data class UssdLogItem(
    val logId: Long,
    val ussdCode: String,
    val response: String?,
    val sessionId: String,
    val messageId: String,
    val simSlot: Int,
    val logType: String,
    val logTime: Long,
    val isSentToServer: Boolean,
    val serverSentTime: Long
)

data class AlarmLogItem(
    val alarmId: Long,
    val alarmType: String,
    val alarmMessage: String,
    val alarmSeverity: String,
    val alarmTime: Long,
    val isSentToServer: Boolean,
    val serverSentTime: Long
)

data class DeliveryReportStats(
    val pendingCount: Int,
    val sentCount: Int,
    val deliveredCount: Int,
    val failedCount: Int
)

data class UssdLogStats(
    val pendingCount: Int,
    val sentCount: Int
)

data class AlarmLogStats(
    val pendingCount: Int,
    val sentCount: Int
) 