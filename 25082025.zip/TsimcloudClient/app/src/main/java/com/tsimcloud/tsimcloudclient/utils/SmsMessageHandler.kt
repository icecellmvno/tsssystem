package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import android.telephony.SmsMessage
import android.telephony.SubscriptionManager
import android.util.Log
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class SmsMessageHandler(
    private val context: Context,
    private val webSocketClient: WebSocketClient,
    private val deviceInfo: DeviceInfo,
    private val preferencesManager: PreferencesManager
) {
    
    companion object {
        private const val TAG = "SmsMessageHandler"
        private const val DATE_FORMAT = "yyyy-MM-dd HH:mm:ss"
    }
    
    private val dateFormat = SimpleDateFormat(DATE_FORMAT, Locale.getDefault())
    
    /**
     * Handle incoming SMS message
     */
    fun handleIncomingSms(pdus: Array<Any>, format: String, subscriptionId: Int = -1) {
        try {
            val messages = mutableListOf<SmsMessage>()
            
            for (pdu in pdus) {
                val message = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    SmsMessage.createFromPdu(pdu as ByteArray, format)
                } else {
                    @Suppress("DEPRECATION")
                    SmsMessage.createFromPdu(pdu as ByteArray)
                }
                messages.add(message)
            }
            
            if (messages.isNotEmpty()) {
                val firstMessage = messages[0]
                val sender = firstMessage.originatingAddress ?: "Unknown"
                val messageBody = messages.joinToString("") { it.messageBody }
                val timestamp = firstMessage.timestampMillis
                val simSlot = if (subscriptionId != -1 && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP_MR1) {
                    getSimSlotFromSubscriptionId(subscriptionId)
                } else {
                    1 // Default to SIM1 for older versions or when subscription ID is not available
                }
                
                Log.d(TAG, "Received SMS from $sender on SIM$simSlot: $messageBody")
                
                // Send to WebSocket
                sendSmsToWebSocket(sender, messageBody, timestamp, simSlot, "received")
                
                // Check if it's a USSD code
                if (isUssdCode(messageBody)) {
                    handleUssdCode(sender, messageBody, simSlot)
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling incoming SMS", e)
        }
    }
    
    /**
     * Handle outgoing SMS message
     */
    fun handleOutgoingSms(phoneNumber: String, message: String, simSlot: Int = 1) {
        try {
            Log.d(TAG, "Sending SMS to $phoneNumber on SIM$simSlot: $message")
            
            // Send to WebSocket
            sendSmsToWebSocket(phoneNumber, message, System.currentTimeMillis(), simSlot, "sent")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling outgoing SMS", e)
        }
    }
    
    /**
     * Handle SMS delivery report
     */
    fun handleSmsDeliveryReport(phoneNumber: String, messageId: String, status: String, simSlot: Int = 1) {
        try {
            Log.d(TAG, "SMS delivery report for $phoneNumber on SIM$simSlot: $status")
            
            val data = mapOf(
                "phone_number" to phoneNumber,
                "message_id" to messageId,
                "status" to status,
                "sim_slot" to simSlot,
                "timestamp" to System.currentTimeMillis(),
                "device_group" to preferencesManager.getDeviceGroup(),
                "countrySite" to preferencesManager.getcountrySite()
            )
            
            webSocketClient.sendJsonMessage("sms_delivery_report", data)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling SMS delivery report", e)
        }
    }
    
    /**
     * Handle MMS message
     */
    fun handleMmsMessage(sender: String, subject: String, parts: List<MmsPart>, simSlot: Int = 1) {
        try {
            Log.d(TAG, "Received MMS from $sender on SIM$simSlot: $subject")
            
            val data = mapOf(
                "sender" to sender,
                "subject" to subject,
                "parts_count" to parts.size,
                "sim_slot" to simSlot,
                "timestamp" to System.currentTimeMillis(),
                "device_group" to preferencesManager.getDeviceGroup(),
                "countrySite" to preferencesManager.getcountrySite(),
                "parts" to parts.map { part ->
                    mapOf(
                        "content_type" to part.contentType,
                        "content_id" to part.contentId,
                        "file_name" to part.fileName,
                        "data_size" to part.dataSize
                    )
                }
            )
            
            webSocketClient.sendJsonMessage("mms_received", data)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling MMS message", e)
        }
    }
    
    /**
     * Handle RCS message
     */
    fun handleRcsMessage(sender: String, message: String, messageType: String, simSlot: Int = 1) {
        try {
            Log.d(TAG, "Received RCS from $sender on SIM$simSlot: $message")
            
            val data = mapOf(
                "sender" to sender,
                "message" to message,
                "message_type" to messageType,
                "sim_slot" to simSlot,
                "timestamp" to System.currentTimeMillis(),
                "device_group" to preferencesManager.getDeviceGroup(),
                "countrySite" to preferencesManager.getcountrySite()
            )
            
            webSocketClient.sendJsonMessage("rcs_received", data)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling RCS message", e)
        }
    }
    
    /**
     * Send SMS message to WebSocket
     */
    private fun sendSmsToWebSocket(
        phoneNumber: String,
        message: String,
        timestamp: Long,
        simSlot: Int,
        direction: String
    ) {
        val data = mapOf(
            "phone_number" to phoneNumber,
            "message" to message,
            "direction" to direction,
            "sim_slot" to simSlot,
            "timestamp" to timestamp,
            "formatted_timestamp" to dateFormat.format(Date(timestamp)),
            "device_group" to preferencesManager.getDeviceGroup(),
            "countrySite" to preferencesManager.getcountrySite()
        )
        
        webSocketClient.sendJsonMessage("sms_message", data)
    }
    
    /**
     * Handle USSD code
     */
    private fun handleUssdCode(sender: String, message: String, simSlot: Int) {
        try {
            Log.d(TAG, "USSD code detected from $sender on SIM$simSlot: $message")
            
            val data = mapOf(
                "sender" to sender,
                "ussd_code" to message,
                "sim_slot" to simSlot,
                "timestamp" to System.currentTimeMillis(),
                "device_group" to preferencesManager.getDeviceGroup(),
                "countrySite" to preferencesManager.getcountrySite()
            )
            
            webSocketClient.sendJsonMessage("ussd_code", data)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling USSD code", e)
        }
    }
    
    /**
     * Check if message is a USSD code
     */
    private fun isUssdCode(message: String): Boolean {
        val ussdPatterns = listOf(
            "*100#", "*101#", "*102#", "*103#", "*104#", "*105#", "*106#", "*107#", "*108#", "*109#",
            "*111#", "*112#", "*113#", "*114#", "*115#", "*116#", "*117#", "*118#", "*119#",
            "*121#", "*122#", "*123#", "*124#", "*125#", "*126#", "*127#", "*128#", "*129#",
            "*130#", "*131#", "*132#", "*133#", "*134#", "*135#", "*136#", "*137#", "*138#", "*139#",
            "*140#", "*141#", "*142#", "*143#", "*144#", "*145#", "*146#", "*147#", "*148#", "*149#",
            "*150#", "*151#", "*152#", "*153#", "*154#", "*155#", "*156#", "*157#", "*158#", "*159#",
            "*160#", "*161#", "*162#", "*163#", "*164#", "*165#", "*166#", "*167#", "*168#", "*169#",
            "*170#", "*171#", "*172#", "*173#", "*174#", "*175#", "*176#", "*177#", "*178#", "*179#",
            "*180#", "*181#", "*182#", "*183#", "*184#", "*185#", "*186#", "*187#", "*188#", "*189#",
            "*190#", "*191#", "*192#", "*193#", "*194#", "*195#", "*196#", "*197#", "*198#", "*199#"
        )
        
        return ussdPatterns.any { pattern ->
            message.trim().equals(pattern, ignoreCase = true)
        }
    }
    
    /**
     * Get SIM slot from subscription ID
     */
    private fun getSimSlotFromSubscriptionId(subscriptionId: Int): Int {
        return try {
            val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val subscriptionInfo = subscriptionManager.getActiveSubscriptionInfo(subscriptionId)
            subscriptionInfo?.simSlotIndex ?: 1
        } catch (e: Exception) {
            Log.w(TAG, "Error getting SIM slot from subscription ID", e)
            1
        }
    }
}

/**
 * MMS Part data class
 */
data class MmsPart(
    val contentType: String,
    val contentId: String,
    val fileName: String?,
    val dataSize: Int
) 