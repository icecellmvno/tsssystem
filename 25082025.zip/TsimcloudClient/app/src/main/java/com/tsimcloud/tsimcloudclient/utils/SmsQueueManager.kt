package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

class SmsQueueManager(
    private val context: Context,
    private val smsDatabase: SmsDatabase,
    private val webSocketClient: WebSocketClient,
    private val preferencesManager: PreferencesManager
) {
    
    companion object {
        private const val TAG = "SmsQueueManager"
        private const val DELIVERY_REPORT_CHECK_INTERVAL = 5000L // 5 seconds
        private const val USSD_LOG_CHECK_INTERVAL = 30000L // 30 seconds
        private const val ALARM_LOG_CHECK_INTERVAL = 15000L // 15 seconds
        private const val CLEANUP_INTERVAL = 3600000L // 1 hour
    }
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val isRunning = AtomicBoolean(false)
    
    private var deliveryReportJob: Job? = null
    private var ussdLogJob: Job? = null
    private var alarmLogJob: Job? = null
    private var cleanupJob: Job? = null
    
    /**
     * Start the queue manager
     */
    fun start() {
        if (isRunning.compareAndSet(false, true)) {
            Log.d(TAG, "Starting SMS Queue Manager")
            
            // Start delivery report processing
            startDeliveryReportProcessing()
            
            // Start USSD log processing
            startUssdLogProcessing()
            
            // Start alarm log processing
            startAlarmLogProcessing()
            
            // Start cleanup job
            startCleanupJob()
        }
    }
    
    /**
     * Stop the queue manager
     */
    fun stop() {
        if (isRunning.compareAndSet(true, false)) {
            Log.d(TAG, "Stopping SMS Queue Manager")
            
            deliveryReportJob?.cancel()
            ussdLogJob?.cancel()
            alarmLogJob?.cancel()
            cleanupJob?.cancel()
        }
    }
    
    /**
     * Add delivery report to queue
     */
    fun addDeliveryReport(
        smsId: String,
        phoneNumber: String,
        simSlot: Int,
        deliveryStatus: String,
        failureReason: String? = null
    ): Long {
        return smsDatabase.addDeliveryReport(smsId, phoneNumber, simSlot, deliveryStatus, failureReason)
    }
    
    /**
     * Add USSD log to queue
     */
    fun addUssdLog(
        ussdCode: String,
        response: String?,
        sessionId: String,
        messageId: String,
        simSlot: Int,
        logType: String
    ): Long {
        return smsDatabase.addUssdLog(ussdCode, response, sessionId, messageId, simSlot, logType)
    }
    
    /**
     * Add alarm log to queue
     */
    fun addAlarmLog(
        alarmType: String,
        alarmMessage: String,
        alarmSeverity: String
    ): Long {
        return smsDatabase.addAlarmLog(alarmType, alarmMessage, alarmSeverity)
    }
    
    /**
     * Start delivery report processing
     */
    private fun startDeliveryReportProcessing() {
        deliveryReportJob?.cancel()
        deliveryReportJob = scope.launch {
            while (isRunning.get()) {
                try {
                    processDeliveryReports()
                    delay(DELIVERY_REPORT_CHECK_INTERVAL)
                } catch (e: Exception) {
                    Log.e(TAG, "Error in delivery report processing", e)
                    delay(DELIVERY_REPORT_CHECK_INTERVAL)
                }
            }
        }
    }
    
    /**
     * Process delivery reports
     */
    private suspend fun processDeliveryReports() {
        // Check WebSocket connection first
        if (!webSocketClient.isConnected()) {
            Log.w(TAG, "WebSocket not connected, skipping delivery report processing")
            return
        }
        
        val pendingReports = smsDatabase.getPendingDeliveryReports()
        
        if (pendingReports.isNotEmpty()) {
            Log.d(TAG, "Processing ${pendingReports.size} pending delivery reports")
            
            for (report in pendingReports) {
                try {
                    // Send delivery report to WebSocket
                    val success = sendDeliveryReportToServer(report)
                    
                    if (success) {
                        // Mark as sent
                        smsDatabase.markDeliveryReportAsSent(report.reportId)
                        Log.d(TAG, "Delivery report sent successfully: ReportID=${report.reportId}, SMSID=${report.smsId}")
                    } else {
                        Log.w(TAG, "Failed to send delivery report: ReportID=${report.reportId}, SMSID=${report.smsId}")
                    }
                    
                    // Small delay between reports
                    delay(100)
                    
                } catch (e: Exception) {
                    Log.e(TAG, "Error processing delivery report: ReportID=${report.reportId}", e)
                }
            }
        }
    }
    
    /**
     * Send delivery report to server via WebSocket
     */
    private suspend fun sendDeliveryReportToServer(report: DeliveryReportItem): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val reportData = mapOf<String, Any>(
                    "message_id" to report.smsId,
                    "phone_number" to report.phoneNumber,
                    "sim_slot" to report.simSlot,
                    "status" to report.deliveryStatus,
                    "timestamp" to report.deliveryTime,
                    "device_group" to preferencesManager.getDeviceGroup(),
                    "country_site" to preferencesManager.getcountrySite()
                )
                
                val success = webSocketClient.sendJsonMessage("sms_delivery_report", reportData)
                
                if (success) {
                    Log.d(TAG, "Delivery report sent to server: SMSID=${report.smsId}, Status=${report.deliveryStatus}")
                } else {
                    Log.w(TAG, "Failed to send delivery report to server: SMSID=${report.smsId}")
                }
                
                success
            } catch (e: Exception) {
                Log.e(TAG, "Error sending delivery report to server: SMSID=${report.smsId}", e)
                false
            }
        }
    }
    
    /**
     * Start USSD log processing
     */
    private fun startUssdLogProcessing() {
        ussdLogJob?.cancel()
        ussdLogJob = scope.launch {
            while (isRunning.get()) {
                try {
                    processUssdLogs()
                    delay(USSD_LOG_CHECK_INTERVAL)
                } catch (e: Exception) {
                    Log.e(TAG, "Error in USSD log processing", e)
                    delay(USSD_LOG_CHECK_INTERVAL)
                }
            }
        }
    }
    
    /**
     * Process USSD logs
     */
    private suspend fun processUssdLogs() {
        val pendingLogs = smsDatabase.getPendingUssdLogs()
        
        if (pendingLogs.isNotEmpty()) {
            Log.d(TAG, "Processing ${pendingLogs.size} pending USSD logs")
            
            for (log in pendingLogs) {
                try {
                    // Send USSD log to WebSocket
                    val success = sendUssdLogToServer(log)
                    
                    if (success) {
                        // Mark as sent
                        smsDatabase.markUssdLogAsSent(log.logId)
                        Log.d(TAG, "USSD log sent successfully: LogID=${log.logId}, Code=${log.ussdCode}")
                    } else {
                        Log.w(TAG, "Failed to send USSD log: LogID=${log.logId}, Code=${log.ussdCode}")
                    }
                    
                    // Small delay between logs
                    delay(300)
                    
                } catch (e: Exception) {
                    Log.e(TAG, "Error processing USSD log: LogID=${log.logId}", e)
                }
            }
        }
    }
    
    /**
     * Send USSD log to server via WebSocket
     */
    private suspend fun sendUssdLogToServer(log: UssdLogItem): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val logData = mapOf<String, Any>(
                    "ussd_code" to log.ussdCode,
                    "response" to (log.response ?: ""),
                    "session_id" to log.sessionId,
                    "message_id" to log.messageId,
                    "sim_slot" to log.simSlot,
                    "log_type" to log.logType,
                    "log_time" to log.logTime
                )
                
                val success = webSocketClient.sendJsonMessage("ussd_log", logData)
                
                if (success) {
                    Log.d(TAG, "USSD log sent to server: Code=${log.ussdCode}, Type=${log.logType}")
                } else {
                    Log.w(TAG, "Failed to send USSD log to server: Code=${log.ussdCode}")
                }
                
                success
            } catch (e: Exception) {
                Log.e(TAG, "Error sending USSD log to server: Code=${log.ussdCode}", e)
                false
            }
        }
    }
    
    /**
     * Start alarm log processing
     */
    private fun startAlarmLogProcessing() {
        alarmLogJob?.cancel()
        alarmLogJob = scope.launch {
            while (isRunning.get()) {
                try {
                    processAlarmLogs()
                    delay(ALARM_LOG_CHECK_INTERVAL)
                } catch (e: Exception) {
                    Log.e(TAG, "Error in alarm log processing", e)
                    delay(ALARM_LOG_CHECK_INTERVAL)
                }
            }
        }
    }
    
    /**
     * Process alarm logs
     */
    private suspend fun processAlarmLogs() {
        val pendingLogs = smsDatabase.getPendingAlarmLogs()
        
        if (pendingLogs.isNotEmpty()) {
            Log.d(TAG, "Processing ${pendingLogs.size} pending alarm logs")
            
            for (log in pendingLogs) {
                try {
                    // Send alarm log to WebSocket
                    val success = sendAlarmLogToServer(log)
                    
                    if (success) {
                        // Mark as sent
                        smsDatabase.markAlarmLogAsSent(log.alarmId)
                        Log.d(TAG, "Alarm log sent successfully: AlarmID=${log.alarmId}, Type=${log.alarmType}")
                    } else {
                        Log.w(TAG, "Failed to send alarm log: AlarmID=${log.alarmId}, Type=${log.alarmType}")
                    }
                    
                    // Small delay between logs
                    delay(200)
                    
                } catch (e: Exception) {
                    Log.e(TAG, "Error processing alarm log: AlarmID=${log.alarmId}", e)
                }
            }
        }
    }
    
    /**
     * Send alarm log to server via WebSocket
     */
    private suspend fun sendAlarmLogToServer(log: AlarmLogItem): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val logData = mapOf<String, Any>(
                    "alarm_type" to log.alarmType,
                    "alarm_message" to log.alarmMessage,
                    "alarm_severity" to log.alarmSeverity,
                    "alarm_time" to log.alarmTime
                )
                
                val success = webSocketClient.sendJsonMessage("alarm_log", logData)
                
                if (success) {
                    Log.d(TAG, "Alarm log sent to server: Type=${log.alarmType}, Severity=${log.alarmSeverity}")
                } else {
                    Log.w(TAG, "Failed to send alarm log to server: Type=${log.alarmType}")
                }
                
                success
            } catch (e: Exception) {
                Log.e(TAG, "Error sending alarm log to server: Type=${log.alarmType}", e)
                false
            }
        }
    }
    
    /**
     * Start cleanup job
     */
    private fun startCleanupJob() {
        cleanupJob?.cancel()
        cleanupJob = scope.launch {
            while (isRunning.get()) {
                try {
                    // Clean up old records (older than 30 days)
                    smsDatabase.cleanupOldRecords(30)
                    delay(CLEANUP_INTERVAL)
                } catch (e: Exception) {
                    Log.e(TAG, "Error in cleanup job", e)
                    delay(CLEANUP_INTERVAL)
                }
            }
        }
    }
    
    /**
     * Get queue statistics
     */
    fun getQueueStats(): QueueStats {
        val deliveryStats = smsDatabase.getDeliveryReportStats()
        val ussdStats = smsDatabase.getUssdLogStats()
        val alarmStats = smsDatabase.getAlarmLogStats()
        
        return QueueStats(
            deliveryReports = deliveryStats,
            ussdLogs = ussdStats,
            alarmLogs = alarmStats
        )
    }
    
    /**
     * Force process delivery reports (for manual trigger)
     */
    fun forceProcessDeliveryReports() {
        scope.launch {
            processDeliveryReports()
        }
    }
    
    /**
     * Force process USSD logs (for manual trigger)
     */
    fun forceProcessUssdLogs() {
        scope.launch {
            processUssdLogs()
        }
    }
    
    /**
     * Force process alarm logs (for manual trigger)
     */
    fun forceProcessAlarmLogs() {
        scope.launch {
            processAlarmLogs()
        }
    }
    
    /**
     * Cleanup resources
     */
    fun cleanup() {
        stop()
        scope.cancel()
    }
}

/**
 * Combined queue statistics
 */
data class QueueStats(
    val deliveryReports: DeliveryReportStats,
    val ussdLogs: UssdLogStats,
    val alarmLogs: AlarmLogStats
) 