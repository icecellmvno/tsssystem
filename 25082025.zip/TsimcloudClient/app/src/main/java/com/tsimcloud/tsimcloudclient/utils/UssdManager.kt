package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import android.telephony.TelephonyManager
import android.util.Log
import java.util.*

class UssdManager(
    private val context: Context,
    private val webSocketClient: WebSocketClient
) {
    companion object {
        private const val TAG = "UssdManager"
    }

    private val activeSessions = mutableMapOf<String, UssdSession>()
    private val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    data class UssdSession(
        val sessionId: String,
        val messageId: String,
        val ussdCode: String,
        val simSlot: Int,
        val startTime: Long = System.currentTimeMillis()
    )

    /**
     * Start USSD session
     */
    fun startUssdSession(ussdCode: String, simSlot: Int): String {
        val sessionId = generateSessionId()
        val messageId = generateMessageId()
        
        val session = UssdSession(
            sessionId = sessionId,
            messageId = messageId,
            ussdCode = ussdCode,
            simSlot = simSlot
        )
        
        activeSessions[sessionId] = session
        Log.d(TAG, "USSD session started: $sessionId for code: $ussdCode")
        
        return sessionId
    }

    /**
     * Handle USSD response
     */
    fun handleUssdResponse(sessionId: String, response: String, status: String) {
        val session = activeSessions[sessionId]
        if (session == null) {
            Log.w(TAG, "USSD session not found: $sessionId")
            return
        }

        try {
            val cleanedResponse = cleanUssdResponse(response)
            val isMenu = isUssdMenu(response)
            val autoCancel = shouldAutoCancel(response)

            // Send to WebSocket server
            val success = webSocketClient.sendUssdResponse(
                sessionId = session.sessionId,
                messageId = session.messageId,
                response = response,
                cleanedResponse = cleanedResponse,
                status = status,
                isMenu = isMenu,
                autoCancel = autoCancel
            )

            if (success) {
                Log.d(TAG, "USSD response sent successfully: $sessionId")
            } else {
                Log.e(TAG, "Failed to send USSD response: $sessionId")
            }

            // Remove session if completed
            if (status == "success" || status == "failed" || status == "cancelled") {
                activeSessions.remove(sessionId)
                Log.d(TAG, "USSD session completed and removed: $sessionId")
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error handling USSD response", e)
            handleUssdError(sessionId, "Error processing response: ${e.message}")
        }
    }

    /**
     * Handle USSD error
     */
    fun handleUssdError(sessionId: String, errorMessage: String) {
        val session = activeSessions[sessionId]
        if (session == null) {
            Log.w(TAG, "USSD session not found for error: $sessionId")
            return
        }

        try {
            val success = webSocketClient.sendUssdResponseFailed(
                sessionId = session.sessionId,
                messageId = session.messageId,
                ussdCode = session.ussdCode,
                simSlot = session.simSlot,
                failureCode = -1,
                errorMessage = errorMessage,
                status = "failed"
            )

            if (success) {
                Log.d(TAG, "USSD error sent successfully: $sessionId")
            } else {
                Log.e(TAG, "Failed to send USSD error: $sessionId")
            }

            // Remove session
            activeSessions.remove(sessionId)
            Log.d(TAG, "USSD session failed and removed: $sessionId")

        } catch (e: Exception) {
            Log.e(TAG, "Error handling USSD error", e)
        }
    }

    /**
     * Handle USSD cancellation
     */
    fun handleUssdCancelled(sessionId: String, reason: String) {
        val session = activeSessions[sessionId]
        if (session == null) {
            Log.w(TAG, "USSD session not found for cancellation: $sessionId")
            return
        }

        try {
            val success = webSocketClient.sendUssdCancelled(
                sessionId = session.sessionId,
                messageId = session.messageId,
                ussdCode = session.ussdCode,
                simSlot = session.simSlot,
                status = "cancelled",
                reason = reason
            )

            if (success) {
                Log.d(TAG, "USSD cancellation sent successfully: $sessionId")
            } else {
                Log.e(TAG, "Failed to send USSD cancellation: $sessionId")
            }

            // Remove session
            activeSessions.remove(sessionId)
            Log.d(TAG, "USSD session cancelled and removed: $sessionId")

        } catch (e: Exception) {
            Log.e(TAG, "Error handling USSD cancellation", e)
        }
    }

    /**
     * Handle incoming USSD code
     */
    fun handleIncomingUssdCode(sender: String, ussdCode: String, simSlot: Int) {
        try {
            val success = webSocketClient.sendUssdCode(
                sender = sender,
                ussdCode = ussdCode,
                simSlot = simSlot
            )

            if (success) {
                Log.d(TAG, "Incoming USSD code sent successfully: $ussdCode")
            } else {
                Log.e(TAG, "Failed to send incoming USSD code: $ussdCode")
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error handling incoming USSD code", e)
        }
    }

    /**
     * Clean USSD response
     */
    private fun cleanUssdResponse(response: String): String {
        return response.trim()
            .replace(Regex("\\s+"), " ") // Multiple spaces to single space
            .replace(Regex("\\n+"), "\n") // Multiple newlines to single newline
            .trim()
    }

    /**
     * Check if USSD response is a menu
     */
    private fun isUssdMenu(response: String): Boolean {
        val menuPatterns = listOf(
            Regex("\\d+\\."), // Numbered options like "1."
            Regex("\\*\\d+"), // Star options like "*1"
            Regex("Reply with"), // "Reply with" text
            Regex("Select"), // "Select" text
            Regex("Choose"), // "Choose" text
            Regex("Press"), // "Press" text
            Regex("Enter"), // "Enter" text
            Regex("Dial") // "Dial" text
        )

        return menuPatterns.any { it.containsMatchIn(response) }
    }

    /**
     * Check if USSD should auto-cancel
     */
    private fun shouldAutoCancel(response: String): Boolean {
        val autoCancelPatterns = listOf(
            Regex("insufficient balance", RegexOption.IGNORE_CASE),
            Regex("not enough balance", RegexOption.IGNORE_CASE),
            Regex("service unavailable", RegexOption.IGNORE_CASE),
            Regex("network error", RegexOption.IGNORE_CASE),
            Regex("timeout", RegexOption.IGNORE_CASE),
            Regex("failed", RegexOption.IGNORE_CASE)
        )

        return autoCancelPatterns.any { it.containsMatchIn(response) }
    }

    /**
     * Generate unique session ID
     */
    private fun generateSessionId(): String {
        return "ussd_${System.currentTimeMillis()}_${Random().nextInt(10000)}"
    }

    /**
     * Generate unique message ID
     */
    private fun generateMessageId(): String {
        return "msg_${System.currentTimeMillis()}_${Random().nextInt(10000)}"
    }

    /**
     * Get active sessions count
     */
    fun getActiveSessionsCount(): Int = activeSessions.size

    /**
     * Clear all active sessions
     */
    fun clearAllSessions() {
        activeSessions.clear()
        Log.d(TAG, "All USSD sessions cleared")
    }

    /**
     * Get session info
     */
    fun getSessionInfo(sessionId: String): UssdSession? = activeSessions[sessionId]
} 