package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Utility class for USSD operations
 * Centralizes all USSD-related functions to avoid duplicates
 */
object UssdUtils {
    
    private const val TAG = "UssdUtils"
    
    /**
     * USSD yanıtının menü olup olmadığını kontrol et
     */
    fun isUssdMenu(response: String): Boolean {
        Log.d(TAG, "=== USSD DEBUG: isUssdMenu START ===")
        Log.d(TAG, "USSD DEBUG: Checking if response is menu: '$response'")
        
        if (response.isBlank()) {
            Log.d(TAG, "USSD DEBUG: Response is blank, returning false")
            return false
        }
        
        val lowerResponse = response.lowercase()
        Log.d(TAG, "USSD DEBUG: Lowercase response: '$lowerResponse'")
        
        // Menü göstergeleri
        val menuIndicators = listOf(
            "menu", "seçenek", "option", "1.", "2.", "3.", "4.", "5.", "6.", "7.", "8.", "9.",
            "seçiniz", "select", "giriniz", "enter", "yazınız", "write",
            "geri", "back", "çıkış", "exit", "iptal", "cancel",
            "evet", "yes", "hayır", "no", "tamam", "ok",
            "bakiye", "balance", "kalan", "remaining", "sorgula", "query",
            "paket", "package", "kampanya", "campaign", "fatura", "bill",
            "ana menü", "main menu", "geri dön", "go back", "çıkış yap", "logout"
        )
        
        Log.d(TAG, "USSD DEBUG: Checking menu indicators...")
        
        // Menü içeriyor mu kontrol et
        val hasMenuIndicator = menuIndicators.any { indicator ->
            val contains = lowerResponse.contains(indicator)
            if (contains) {
                Log.d(TAG, "USSD DEBUG: Found menu indicator: '$indicator'")
            }
            contains
        }
        
        val hasNumberedOptions = response.matches(Regex(".*\\d+\\..*"))
        Log.d(TAG, "USSD DEBUG: Has numbered options (1. 2. etc.): $hasNumberedOptions")
        
        val isMenu = hasMenuIndicator || hasNumberedOptions
        Log.d(TAG, "USSD DEBUG: Final result - is menu: $isMenu")
        Log.d(TAG, "=== USSD DEBUG: isUssdMenu END ===")
        
        return isMenu
    }
    
    /**
     * USSD yanıtını temizle
     */
    fun cleanUssdResponse(response: String): String {
        Log.d(TAG, "=== USSD DEBUG: cleanUssdResponse START ===")
        Log.d(TAG, "USSD DEBUG: Original response: '$response'")
        
        val step1 = response.replace(Regex("\\s+"), " ") // Fazla boşlukları temizle
        Log.d(TAG, "USSD DEBUG: After whitespace cleanup: '$step1'")
        
        val step2 = step1.trim() // Başındaki ve sonundaki boşlukları kaldır
        Log.d(TAG, "USSD DEBUG: After trim: '$step2'")
        
        val step3 = step2.replace(Regex("\\*\\d+\\*\\d+#"), "") // USSD kodlarını kaldır
        Log.d(TAG, "USSD DEBUG: After USSD code removal: '$step3'")
        
        val step4 = step3.replace(Regex("\\d+\\)"), "") // Numaralı seçenekleri kaldır
        Log.d(TAG, "USSD DEBUG: After numbered options removal: '$step4'")
        
        Log.d(TAG, "USSD DEBUG: Final cleaned response: '$step4'")
        Log.d(TAG, "=== USSD DEBUG: cleanUssdResponse END ===")
        
        return step4
    }
    
    /**
     * USSD menüsünü cancel et
     */
    fun cancelUssdMenu(context: Context?, delay: Long = 2000L) {
        Log.d(TAG, "=== USSD DEBUG: cancelUssdMenu START ===")
        Log.d(TAG, "USSD DEBUG: Context null: ${context == null}")
        Log.d(TAG, "USSD DEBUG: Delay: $delay ms")
        
        context?.let { ctx ->
            Log.d(TAG, "USSD DEBUG: Scheduling cancel operation...")
            
            // Delay ile cancel işlemi
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    Log.d(TAG, "=== USSD DEBUG: Executing cancel operation ===")
                    Log.d(TAG, "USSD DEBUG: Executing USSD menu cancel after $delay ms delay")
                    
                    // Method 1: Send cancel USSD code
                    Log.d(TAG, "USSD DEBUG: Method 1 - Sending cancel USSD codes")
                    sendCancelUssdCode(ctx)
                    
                    // Method 2: Close system dialogs
                    Log.d(TAG, "USSD DEBUG: Method 2 - Closing system dialogs")
                    val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                    ctx.sendBroadcast(closeIntent)
                    Log.d(TAG, "USSD DEBUG: Sent ACTION_CLOSE_SYSTEM_DIALOGS for USSD cancel")
                    
                    // Method 3: Go to home screen
                    Log.d(TAG, "USSD DEBUG: Method 3 - Going to home screen")
                    val homeIntent = Intent(Intent.ACTION_MAIN)
                    homeIntent.addCategory(Intent.CATEGORY_HOME)
                    homeIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    homeIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    ctx.startActivity(homeIntent)
                    Log.d(TAG, "USSD DEBUG: Sent home intent for USSD cancel")
                    
                    // Method 4: Bring app to foreground
                    Log.d(TAG, "USSD DEBUG: Method 4 - Bringing app to foreground")
                    val appIntent = Intent(ctx, com.tsimcloud.tsimcloudclient.MainActivity::class.java)
                    appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    appIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    ctx.startActivity(appIntent)
                    Log.d(TAG, "USSD DEBUG: Brought app to foreground for USSD cancel")
                    
                    Log.d(TAG, "=== USSD DEBUG: Cancel operation completed ===")
                    
                } catch (e: Exception) {
                    Log.e(TAG, "USSD DEBUG: Error cancelling USSD menu", e)
                }
            }, delay)
            
            Log.d(TAG, "USSD DEBUG: Cancel operation scheduled successfully")
        } ?: run {
            Log.w(TAG, "USSD DEBUG: Cannot cancel - context is null")
        }
        
        Log.d(TAG, "=== USSD DEBUG: cancelUssdMenu END ===")
    }
    
    /**
     * Cancel USSD kodu gönder
     */
    fun sendCancelUssdCode(context: Context) {
        Log.d(TAG, "=== USSD DEBUG: sendCancelUssdCode START ===")
        try {
            // Yaygın cancel kodları
            val cancelCodes = listOf("0", "00", "000", "99", "999", "*0#", "*00#", "*000#", "*99#", "*999#")
            Log.d(TAG, "USSD DEBUG: Will try ${cancelCodes.size} cancel codes: $cancelCodes")
            
            for ((index, cancelCode) in cancelCodes.withIndex()) {
                try {
                    Log.d(TAG, "USSD DEBUG: Attempt ${index + 1}/${cancelCodes.size} - Trying cancel code: '$cancelCode'")
                    
                    val callIntent = Intent(Intent.ACTION_CALL)
                    callIntent.data = android.net.Uri.parse("tel:$cancelCode")
                    callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                    callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    callIntent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                    
                    Log.d(TAG, "USSD DEBUG: Starting activity for cancel code: $cancelCode")
                    context.startActivity(callIntent)
                    Log.d(TAG, "USSD DEBUG: Cancel USSD code sent successfully: $cancelCode")
                    
                    // Kısa bir bekleme
                    Log.d(TAG, "USSD DEBUG: Waiting 500ms after sending cancel code")
                    Thread.sleep(500)
                    
                    // Popup'ı kapat
                    Log.d(TAG, "USSD DEBUG: Closing popup after cancel code")
                    val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                    context.sendBroadcast(closeIntent)
                    Log.d(TAG, "USSD DEBUG: Popup close intent sent")
                    
                } catch (e: Exception) {
                    Log.w(TAG, "USSD DEBUG: Failed to send cancel USSD code '$cancelCode': ${e.message}", e)
                }
            }
            
            Log.d(TAG, "USSD DEBUG: All cancel codes processed")
            
        } catch (e: Exception) {
            Log.e(TAG, "USSD DEBUG: Error in sendCancelUssdCode", e)
        }
        Log.d(TAG, "=== USSD DEBUG: sendCancelUssdCode END ===")
    }
    
    /**
     * USSD kodunun geçerli olup olmadığını kontrol et
     */
    fun isValidUssdCode(code: String): Boolean {
        return code.startsWith("*") && code.endsWith("#") && code.length >= 3
    }
    
    /**
     * USSD kodunu formatla
     */
    fun formatUssdCode(code: String): String {
        return if (!code.startsWith("*")) "*$code" else code
    }
} 