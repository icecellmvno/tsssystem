package com.tsimcloud.tsimcloudclient.utils

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import java.util.*

class DeviceInfo(private val context: Context) {
    
    /**
     * Get device manufacturer
     */
    fun getManufacturer(): String {
        return Build.MANUFACTURER
    }
    
    /**
     * Get device model
     */
    fun getModel(): String {
        return Build.MODEL
    }
    
    /**
     * Get device brand
     */
    fun getBrand(): String {
        return Build.BRAND
    }
    
    /**
     * Get device product name
     */
    fun getProduct(): String {
        return Build.PRODUCT
    }
    
    /**
     * Get Android version
     */
    fun getAndroidVersion(): String {
        return Build.VERSION.RELEASE
    }
    
    /**
     * Get Android SDK version
     */
    fun getAndroidSDKVersion(): Int {
        return Build.VERSION.SDK_INT
    }
    
    /**
     * Get device unique identifier
     */
    fun getDeviceId(): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: ""
    }
    
    /**
     * Get device serial number
     */
    fun getSerialNumber(): String {
        return try {
            @Suppress("DEPRECATION")
            Build.SERIAL ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get app version
     */
    fun getAppVersion(): String {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get IMEI number (requires READ_PHONE_STATE permission)
     */
    fun getIMEI(): String {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            telephonyManager.deviceId ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get IMSI number (requires READ_PHONE_STATE permission)
     */
    fun getIMSI(): String {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            telephonyManager.subscriberId ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get SIM operator name
     */
    fun getSimOperatorName(): String {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            telephonyManager.simOperatorName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get SIM operator code
     */
    fun getSimOperatorCode(): String {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            telephonyManager.simOperator ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get network operator name
     */
    fun getNetworkOperatorName(): String {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            telephonyManager.networkOperatorName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get network operator code
     */
    fun getNetworkOperatorCode(): String {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            telephonyManager.networkOperator ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get number of SIM slots
     */
    fun getSimSlotCount(): Int {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                telephonyManager.phoneCount
            } else {
                1 // Default to 1 for older versions
            }
        } catch (e: Exception) {
            1
        }
    }
    
    /**
     * Get dual SIM information
     */
    fun getDualSimInfo(): Map<String, Any> {
        val dualSimInfo = mutableMapOf<String, Any>()
        
        try {
            val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            
            dualSimInfo["sim_slot_count"] = getSimSlotCount()
            dualSimInfo["is_dual_sim"] = getSimSlotCount() > 1
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                val activeSubscriptions = subscriptionManager.activeSubscriptionInfoList
                dualSimInfo["active_subscriptions_count"] = activeSubscriptions?.size ?: 0
                
                val simInfoList = mutableListOf<Map<String, String>>()
                
                activeSubscriptions?.forEach { subscriptionInfo ->
                    val simInfo = mutableMapOf<String, String>()
                    
                    simInfo["subscription_id"] = subscriptionInfo.subscriptionId.toString()
                    simInfo["sim_slot_index"] = subscriptionInfo.simSlotIndex.toString()
                    simInfo["carrier_name"] = subscriptionInfo.carrierName?.toString() ?: ""
                    simInfo["display_name"] = subscriptionInfo.displayName?.toString() ?: ""
                    simInfo["number"] = subscriptionInfo.number ?: ""
                    simInfo["country_iso"] = subscriptionInfo.countryIso ?: ""
                    simInfo["mcc"] = subscriptionInfo.mcc.toString()
                    simInfo["mnc"] = subscriptionInfo.mnc.toString()
                    simInfo["is_embedded"] = subscriptionInfo.isEmbedded.toString()
                    
                    // Get IMEI and IMSI for specific SIM slot
                    try {
                        val specificTelephonyManager = telephonyManager.createForSubscriptionId(subscriptionInfo.subscriptionId)
                        @Suppress("DEPRECATION")
                        simInfo["imei"] = specificTelephonyManager.deviceId ?: ""
                        @Suppress("DEPRECATION")
                        simInfo["imsi"] = specificTelephonyManager.subscriberId ?: ""
                    } catch (e: Exception) {
                        simInfo["imei"] = ""
                        simInfo["imsi"] = ""
                    }
                    
                    simInfoList.add(simInfo)
                }
                
                dualSimInfo["sim_info_list"] = simInfoList
            }
            
        } catch (e: Exception) {
            dualSimInfo["error"] = e.message ?: "Unknown error"
        }
        
        return dualSimInfo
    }
    
    /**
     * Get SIM information for specific slot
     */
    fun getSimInfoForSlot(slotIndex: Int): Map<String, String> {
        val simInfo = mutableMapOf<String, String>()
        
        try {
            val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                val activeSubscriptions = subscriptionManager.activeSubscriptionInfoList
                
                activeSubscriptions?.find { it.simSlotIndex == slotIndex }?.let { subscriptionInfo ->
                    simInfo["subscription_id"] = subscriptionInfo.subscriptionId.toString()
                    simInfo["sim_slot_index"] = subscriptionInfo.simSlotIndex.toString()
                    simInfo["carrier_name"] = subscriptionInfo.carrierName?.toString() ?: ""
                    simInfo["display_name"] = subscriptionInfo.displayName?.toString() ?: ""
                    simInfo["number"] = subscriptionInfo.number ?: ""
                    simInfo["country_iso"] = subscriptionInfo.countryIso ?: ""
                    simInfo["mcc"] = subscriptionInfo.mcc.toString()
                    simInfo["mnc"] = subscriptionInfo.mnc.toString()
                    simInfo["is_embedded"] = subscriptionInfo.isEmbedded.toString()
                    
                    // Get IMEI and IMSI for specific SIM slot
                    try {
                        val specificTelephonyManager = telephonyManager.createForSubscriptionId(subscriptionInfo.subscriptionId)
                        @Suppress("DEPRECATION")
                        simInfo["imei"] = specificTelephonyManager.deviceId ?: ""
                        @Suppress("DEPRECATION")
                        simInfo["imsi"] = specificTelephonyManager.subscriberId ?: ""
                    } catch (e: Exception) {
                        simInfo["imei"] = ""
                        simInfo["imsi"] = ""
                    }
                }
            }
            
        } catch (e: Exception) {
            simInfo["error"] = e.message ?: "Unknown error"
        }
        
        return simInfo
    }
    
    /**
     * Check if device supports dual SIM
     */
    fun isDualSimSupported(): Boolean {
        return getSimSlotCount() > 1
    }
    
    /**
     * Get all device information as a map
     */
    fun getAllDeviceInfo(): Map<String, Any> {
        val basicInfo = mapOf(
            "manufacturer" to getManufacturer(),
            "model" to getModel(),
            "brand" to getBrand(),
            "product" to getProduct(),
            "android_version" to getAndroidVersion(),
            "android_sdk_version" to getAndroidSDKVersion().toString(),
            "device_id" to getDeviceId(),
            "device_name" to getModel(), // Use model as device name
            "name" to getModel(), // Alternative field name
            "imei" to getIMEI(),
            "serial_number" to getSerialNumber(), // Add serial number
            "app_version" to getAppVersion(), // Add app version
            "sim_operator_name" to getSimOperatorName(),
            "sim_operator_code" to getSimOperatorCode(),
            "network_operator_name" to getNetworkOperatorName(),
            "network_operator_code" to getNetworkOperatorCode(),
            "sim_slot_count" to getSimSlotCount(),
            "is_dual_sim" to isDualSimSupported(),
//            "countrySite" to getcountrySite(), // Add countrySite from preferences
//            "device_group" to getDeviceGroup() // Add device group from preferences
        )
        
        val dualSimInfo = getDualSimInfo()
        
        return basicInfo + dualSimInfo
    }
    
    /**
     * Get device information as JSON string
     */
    fun getDeviceInfoAsJson(): String {
        val deviceInfo = getAllDeviceInfo()
        return buildString {
            append("{")
            deviceInfo.entries.forEachIndexed { index, entry ->
                when (entry.value) {
                    is String -> append("\"${entry.key}\": \"${entry.value}\"")
                    is Int -> append("\"${entry.key}\": ${entry.value}")
                    is Boolean -> append("\"${entry.key}\": ${entry.value}")
                    is List<*> -> {
                        append("\"${entry.key}\": [")
                        (entry.value as List<*>).forEachIndexed { listIndex, item ->
                            if (item is Map<*, *>) {
                                append("{")
                                (item as Map<*, *>).entries.forEachIndexed { mapIndex, mapEntry ->
                                    append("\"${mapEntry.key}\": \"${mapEntry.value}\"")
                                    if (mapIndex < (item as Map<*, *>).size - 1) append(", ")
                                }
                                append("}")
                            }
                            if (listIndex < (entry.value as List<*>).size - 1) append(", ")
                        }
                        append("]")
                    }
                    else -> append("\"${entry.key}\": \"${entry.value}\"")
                }
                if (index < deviceInfo.size - 1) {
                    append(", ")
                }
            }
            append("}")
        }
    }
    
    /**
     * Get device group from preferences
     */
    fun getDeviceGroup(): String {
        return try {
            val preferencesManager = PreferencesManager(context)
            preferencesManager.getDeviceGroup()
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get countrySite from preferences
     */
    fun getcountrySite(): String {
        return try {
            val preferencesManager = PreferencesManager(context)
            preferencesManager.getcountrySite()
        } catch (e: Exception) {
            ""
        }
    }

    fun getWebsocketUrl(): String {
        return try {
            val preferencesManager = PreferencesManager(context)
            preferencesManager.getWebsocketUrl()
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * Get battery level
     */
    fun getBatteryLevel(): Int {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
            val level = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            level
        } catch (e: Exception) {
            -1
        }
    }
    
    /**
     * Get battery status
     */
    fun getBatteryStatus(): String {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
            val status = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_STATUS)
            val result = when (status) {
                android.os.BatteryManager.BATTERY_STATUS_CHARGING -> "charging"
                android.os.BatteryManager.BATTERY_STATUS_DISCHARGING -> "discharging"
                android.os.BatteryManager.BATTERY_STATUS_FULL -> "full"
                android.os.BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "not_charging"
                else -> "unknown"
            }
            android.util.Log.d("DeviceInfo", "Battery status: $result (raw: $status)")
            result
        } catch (e: Exception) {
            android.util.Log.e("DeviceInfo", "Error getting battery status", e)
            "unknown"
        }
    }
    
    /**
     * Get signal strength
     */
    fun getSignalStrength(): Int {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val signalStrength = telephonyManager.signalStrength
            signalStrength?.level ?: -1
        } catch (e: Exception) {
            -1
        }
    }
    
    /**
     * Get signal strength in dBm
     */
    fun getSignalDbm(): Int {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val signalStrength = telephonyManager.signalStrength
            // asuLevel is deprecated, use level instead for dBm approximation
            signalStrength?.level ?: -1
        } catch (e: Exception) {
            -1
        }
    }
    
    /**
     * Get network type
     */
    fun getNetworkType(): String {
        return try {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            when (telephonyManager.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_GPRS -> "GPRS"
                TelephonyManager.NETWORK_TYPE_EDGE -> "EDGE"
                TelephonyManager.NETWORK_TYPE_UMTS -> "UMTS"
                TelephonyManager.NETWORK_TYPE_HSDPA -> "HSDPA"
                TelephonyManager.NETWORK_TYPE_HSUPA -> "HSUPA"
                TelephonyManager.NETWORK_TYPE_HSPA -> "HSPA"
                TelephonyManager.NETWORK_TYPE_CDMA -> "CDMA"
                TelephonyManager.NETWORK_TYPE_EVDO_0 -> "EVDO_0"
                TelephonyManager.NETWORK_TYPE_EVDO_A -> "EVDO_A"
                TelephonyManager.NETWORK_TYPE_EVDO_B -> "EVDO_B"
                TelephonyManager.NETWORK_TYPE_1xRTT -> "1xRTT"
                TelephonyManager.NETWORK_TYPE_IDEN -> "IDEN"
                TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
                TelephonyManager.NETWORK_TYPE_EHRPD -> "EHRPD"
                TelephonyManager.NETWORK_TYPE_HSPAP -> "HSPAP"
                TelephonyManager.NETWORK_TYPE_GSM -> "GSM"
                TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "TD_SCDMA"
                TelephonyManager.NETWORK_TYPE_IWLAN -> "IWLAN"
                else -> "UNKNOWN"
            }
        } catch (e: Exception) {
            "UNKNOWN"
        }
    }
    
    /**
     * Get location (latitude, longitude)
     */
    fun getLocation(): Pair<Double, Double>? {
        return try {
            // Check if location permissions are granted
            if (context.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return null
            }
            
            val locationManager = context.getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
            
            // Try to get last known location from GPS provider
            var location: android.location.Location? = null
            
            if (locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
                location = locationManager.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
            }
            
            // If GPS location is not available, try network provider
            if (location == null && locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)) {
                location = locationManager.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
            }
            
            // If network location is not available, try passive provider
            if (location == null && locationManager.isProviderEnabled(android.location.LocationManager.PASSIVE_PROVIDER)) {
                location = locationManager.getLastKnownLocation(android.location.LocationManager.PASSIVE_PROVIDER)
            }
            
            if (location != null) {
                Pair(location.latitude, location.longitude)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * Get SIM cards information for heartbeat message
     */
    fun getSimCardsForHeartbeat(): List<Map<String, Any>> {
        val simCards = mutableListOf<Map<String, Any>>()
        
        try {
            val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                val activeSubscriptions = subscriptionManager.activeSubscriptionInfoList
                
                activeSubscriptions?.forEach { subscriptionInfo ->
                    val simCard = mutableMapOf<String, Any>()
                    
                    simCard["slot_index"] = subscriptionInfo.simSlotIndex
                    simCard["carrier_name"] = subscriptionInfo.carrierName?.toString() ?: ""
                    simCard["phone_number"] = subscriptionInfo.number ?: ""
                    simCard["network_mcc"] = subscriptionInfo.mcc.toString()
                    simCard["network_mnc"] = subscriptionInfo.mnc.toString()
                    simCard["is_active"] = true
                    
                    // Get IMEI and IMSI for specific SIM slot
                    try {
                        val specificTelephonyManager = telephonyManager.createForSubscriptionId(subscriptionInfo.subscriptionId)
                        @Suppress("DEPRECATION")
                        val imei = specificTelephonyManager.deviceId ?: ""
                        @Suppress("DEPRECATION")
                        val imsi = specificTelephonyManager.subscriberId ?: ""
                        
                        // Try to get ICCID (may not be available on all devices)
                        val iccid = try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                // Try to get ICCID using reflection or use subscription ID as fallback
                                try {
                                    val iccIdField = specificTelephonyManager.javaClass.getDeclaredField("mIccId")
                                    iccIdField.isAccessible = true
                                    iccIdField.get(specificTelephonyManager) as? String ?: ""
                                } catch (e: Exception) {
                                    // Fallback to subscription ID if ICCID not available
                                    "SUB_${subscriptionInfo.subscriptionId}"
                                }
                            } else {
                                ""
                            }
                        } catch (e: Exception) {
                            ""
                        }
                        
                        simCard["imei"] = imei
                        simCard["imsi"] = imsi
                        simCard["iccid"] = iccid
                        
                        // Get signal strength for this SIM
                        try {
                            val signalStrength = specificTelephonyManager.signalStrength
                            if (signalStrength != null) {
                                simCard["signal_strength"] = signalStrength.level
                                // asuLevel is deprecated, use level instead for dBm approximation
                                simCard["signal_dbm"] = signalStrength.level
                            }
                        } catch (e: Exception) {
                            simCard["signal_strength"] = -1
                            simCard["signal_dbm"] = -1
                        }
                        
                        // Get network type for this SIM
                        try {
                            val networkType = when (specificTelephonyManager.dataNetworkType) {
                                TelephonyManager.NETWORK_TYPE_GPRS -> "GPRS"
                                TelephonyManager.NETWORK_TYPE_EDGE -> "EDGE"
                                TelephonyManager.NETWORK_TYPE_UMTS -> "UMTS"
                                TelephonyManager.NETWORK_TYPE_HSDPA -> "HSDPA"
                                TelephonyManager.NETWORK_TYPE_HSUPA -> "HSUPA"
                                TelephonyManager.NETWORK_TYPE_HSPA -> "HSPA"
                                TelephonyManager.NETWORK_TYPE_CDMA -> "CDMA"
                                TelephonyManager.NETWORK_TYPE_EVDO_0 -> "EVDO_0"
                                TelephonyManager.NETWORK_TYPE_EVDO_A -> "EVDO_A"
                                TelephonyManager.NETWORK_TYPE_EVDO_B -> "EVDO_B"
                                TelephonyManager.NETWORK_TYPE_1xRTT -> "1xRTT"
                                TelephonyManager.NETWORK_TYPE_IDEN -> "IDEN"
                                TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
                                TelephonyManager.NETWORK_TYPE_EHRPD -> "EHRPD"
                                TelephonyManager.NETWORK_TYPE_HSPAP -> "HSPAP"
                                TelephonyManager.NETWORK_TYPE_GSM -> "GSM"
                                TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "TD_SCDMA"
                                TelephonyManager.NETWORK_TYPE_IWLAN -> "IWLAN"
                                else -> "UNKNOWN"
                            }
                            simCard["network_type"] = networkType
                        } catch (e: Exception) {
                            simCard["network_type"] = "UNKNOWN"
                        }
                        
                    } catch (e: Exception) {
                        simCard["imei"] = ""
                        simCard["imsi"] = ""
                        simCard["iccid"] = ""
                        simCard["signal_strength"] = -1
                        simCard["signal_dbm"] = -1
                        simCard["network_type"] = "UNKNOWN"
                    }
                    
                    simCards.add(simCard)
                }
            }
            
        } catch (e: Exception) {
            // Return empty list if there's an error
        }
        
        return simCards
    }
}