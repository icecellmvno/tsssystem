package com.tsimcloud.tsimcloudclient

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.telephony.TelephonyManager

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material3.Switch
import androidx.compose.material3.Slider
import androidx.compose.material3.Button
import androidx.compose.runtime.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.*
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.tsimcloud.tsimcloudclient.utils.DeviceInfo
import com.tsimcloud.tsimcloudclient.utils.PreferencesManager
import com.tsimcloud.tsimcloudclient.utils.QrConfigManager
import com.tsimcloud.tsimcloudclient.utils.WebSocketClient
import com.tsimcloud.tsimcloudclient.utils.UssdManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.widget.Toast
import android.content.IntentFilter
import android.content.BroadcastReceiver
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.PermanentNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    
    private lateinit var deviceInfo: DeviceInfo
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var qrConfigManager: QrConfigManager
    private var webSocketClient: WebSocketClient? = null
    private var ussdManager: UssdManager? = null
    private var configUpdateTrigger by mutableStateOf(0)
    private var isAlarmActive by mutableStateOf(false)
    private var simCardChangeReceiver: SimCardChangeReceiver? = null
    private var autoReconnectUpdateTrigger by mutableStateOf(0)
    
    private val roleRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            android.util.Log.d("MainActivity", "SMS role request successful")
        } else {
            android.util.Log.d("MainActivity", "SMS role request failed or cancelled")
        }
    }
    
    private val qrScanLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val configSaved = result.data?.getBooleanExtra("config_saved", false) ?: false
            if (configSaved) {
                // Configuration saved successfully, update UI
                configUpdateTrigger++ // recomposition tetikleyici
                updateConfigurationStatus()
                
                // Restart services to use new configuration
                restartServicesWithNewConfig()
            }
        }
    }
    
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            // All permissions granted, can proceed
        } else {
            // Some permissions denied, show message
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Hide action bar

        
        deviceInfo = DeviceInfo(this)
        preferencesManager = PreferencesManager(this)
        qrConfigManager = QrConfigManager(this)
        

        

        // Create notification channel
        createNotificationChannel()
        
        // Request permissions
        requestPermissions()
        
        // Register SIM card change receiver
        registerSimCardChangeReceiver()
        
        // Initialize alarm status
        updateAlarmStatus()
        
        // Start periodic alarm status updates
        startAlarmStatusUpdates()
        
        setContent {
            MaterialTheme {
                val backgroundColor by animateColorAsState(
                    targetValue = if (isAlarmActive) Color.Red else Color.White,
                    animationSpec = tween(1000),
                    label = "main_background_color"
                )
                
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = backgroundColor
                ) {
                    MainScreenWithDrawer(
                        onQrScanClick = { startQrScan() },
                        onSetDefaultSmsClick = { setAsDefaultSmsApp() },
                        onSetDefaultDialerClick = { setAsDefaultDialer() },
                        onStartServicesClick = { startServices() },
                        onStopServicesClick = { stopServices() },
                        onToggleAlarm = { toggleAlarm() },
                        onAutoReconnectUpdate = { updateAutoReconnectSetting() },
                        configUpdateTrigger = configUpdateTrigger,
                        autoReconnectUpdateTrigger = autoReconnectUpdateTrigger,
                        isAlarmActive = isAlarmActive
                    )
                }
            }
        }
    }
    
    private fun startQrScan() {
        val intent = Intent(this, QrScanActivity::class.java)
        qrScanLauncher.launch(intent)
    }
    
    private fun setAsDefaultSmsApp() {
        android.util.Log.d("MainActivity", "setAsDefaultSmsApp called")
        
        if (isDefaultSmsApp()) {
            android.util.Log.d("MainActivity", "Already default SMS app")
            return
        }

        try {
            val roleManager = getSystemService(android.app.role.RoleManager::class.java)
            android.util.Log.d("MainActivity", "RoleManager: $roleManager")
            
            if (roleManager != null && roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_SMS)) {
                android.util.Log.d("MainActivity", "SMS role is available")
                if (!roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_SMS)) {
                    android.util.Log.d("MainActivity", "Requesting SMS role via RoleManager")
                    val intent = roleManager.createRequestRoleIntent(android.app.role.RoleManager.ROLE_SMS)
                    roleRequestLauncher.launch(intent)
                } else {
                    android.util.Log.d("MainActivity", "SMS role already held")
                }
            } else {
                android.util.Log.d("MainActivity", "RoleManager not available, trying SMS intent")
                // Fallback for devices that don't support RoleManager properly (like Xiaomi)
                try {
                    val intent = Intent(android.provider.Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    intent.putExtra(android.provider.Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                    startActivity(intent)
                    android.util.Log.d("MainActivity", "SMS intent started")
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "SMS intent failed", e)
                    // If that fails too, try to open app settings
                    try {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.data = Uri.fromParts("package", packageName, null)
                        startActivity(intent)
                        android.util.Log.d("MainActivity", "App settings intent started")
                    } catch (e2: Exception) {
                        android.util.Log.e("MainActivity", "App settings intent failed", e2)
                        // Last resort - open general settings
                        val intent = Intent(Settings.ACTION_SETTINGS)
                        startActivity(intent)
                        android.util.Log.d("MainActivity", "General settings intent started")
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "RoleManager failed completely", e)
            // If RoleManager fails completely, try direct SMS intent
            try {
                val intent = Intent(android.provider.Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(android.provider.Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                startActivity(intent)
                android.util.Log.d("MainActivity", "Direct SMS intent started")
            } catch (e2: Exception) {
                android.util.Log.e("MainActivity", "Direct SMS intent failed", e2)
                // Last resort - open app settings
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.fromParts("package", packageName, null)
                startActivity(intent)
                android.util.Log.d("MainActivity", "Last resort app settings started")
            }
        }
    }

    private fun setAsDefaultDialer() {
        android.util.Log.d("MainActivity", "setAsDefaultDialer called")
        
        if (isDefaultDialer()) {
            android.util.Log.d("MainActivity", "Already default dialer")
            return
        }

        try {
            val roleManager = getSystemService(android.app.role.RoleManager::class.java)
            android.util.Log.d("MainActivity", "RoleManager: $roleManager")
            
            if (roleManager != null && roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER)) {
                android.util.Log.d("MainActivity", "Dialer role is available")
                if (!roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)) {
                    android.util.Log.d("MainActivity", "Requesting dialer role via RoleManager")
                    val intent = roleManager.createRequestRoleIntent(android.app.role.RoleManager.ROLE_DIALER)
                    roleRequestLauncher.launch(intent)
                } else {
                    android.util.Log.d("MainActivity", "Dialer role already held")
                }
            } else {
                android.util.Log.d("MainActivity", "RoleManager not available, trying dialer intent")
                // Fallback for devices that don't support RoleManager properly
                try {
                    // For Android 10+ (API 29+)
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val intent = Intent("android.telephony.action.CHANGE_DEFAULT_DIALER")
                        intent.putExtra("android.telephony.extra.CHANGE_DEFAULT_DIALER_PACKAGE_NAME", packageName)
                        startActivity(intent)
                        android.util.Log.d("MainActivity", "Dialer intent started")
                    } else {
                        // For older versions, try to open settings
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.data = Uri.fromParts("package", packageName, null)
                        startActivity(intent)
                        android.util.Log.d("MainActivity", "App settings intent started for older Android")
                    }
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "Dialer intent failed", e)
                    // If that fails too, try to open app settings
                    try {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.data = Uri.fromParts("package", packageName, null)
                        startActivity(intent)
                        android.util.Log.d("MainActivity", "App settings intent started")
                    } catch (e2: Exception) {
                        android.util.Log.e("MainActivity", "App settings intent failed", e2)
                        // Last resort - open general settings
                        val intent = Intent(Settings.ACTION_SETTINGS)
                        startActivity(intent)
                        android.util.Log.d("MainActivity", "General settings intent started")
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "RoleManager failed completely", e)
            // If RoleManager fails completely, try direct dialer intent
            try {
                // For Android 10+ (API 29+)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    val intent = Intent("android.telephony.action.CHANGE_DEFAULT_DIALER")
                    intent.putExtra("android.telephony.extra.CHANGE_DEFAULT_DIALER_PACKAGE_NAME", packageName)
                    startActivity(intent)
                    android.util.Log.d("MainActivity", "Direct dialer intent started")
                } else {
                    // For older versions, try to open settings
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    intent.data = Uri.fromParts("package", packageName, null)
                    startActivity(intent)
                    android.util.Log.d("MainActivity", "Direct app settings intent started for older Android")
                }
            } catch (e2: Exception) {
                android.util.Log.e("MainActivity", "Direct dialer intent failed", e2)
                // Last resort - open app settings
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.fromParts("package", packageName, null)
                startActivity(intent)
                android.util.Log.d("MainActivity", "Last resort app settings started")
            }
        }
    }

    private fun isDefaultSmsApp(): Boolean {
        return packageName == android.provider.Telephony.Sms.getDefaultSmsPackage(this)
    }
    
    private fun isDefaultDialer(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            try {
                val roleManager = getSystemService(android.app.role.RoleManager::class.java)
                if (roleManager != null && roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER)) {
                    roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)
                } else {
                    // Fallback to reflection method
                    val telephonyManager = getSystemService(android.telephony.TelephonyManager::class.java)
                    val defaultDialerPackage = telephonyManager.javaClass.getMethod("getDefaultDialerPackage").invoke(telephonyManager) as? String
                    packageName == defaultDialerPackage
                }
            } catch (e: Exception) {
                android.util.Log.w("MainActivity", "Error checking default dialer: ${e.message}")
                false
            }
        } else {
            // For older versions, we can't reliably check this
            false
        }
    }
    

    
    private fun startServices() {
        if (!qrConfigManager.isDeviceConfigured()) {
            // Show error message
            Toast.makeText(this, "Please scan QR code first to configure device", Toast.LENGTH_LONG).show()
            return
        }
        
        if (!isDefaultSmsApp()) {
            // Show error message
            Toast.makeText(this, "Please set as default SMS app first", Toast.LENGTH_LONG).show()
            return
        }
        
        // Start SmsGatewayService which handles all WebSocket messages and device commands
        val serviceIntent = Intent(this, SmsGatewayService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        
        android.util.Log.d("MainActivity", "SmsGatewayService started")
    }
    
    private fun stopServices() {
        // Stop SmsGatewayService
        val serviceIntent = Intent(this, SmsGatewayService::class.java)
        stopService(serviceIntent)
        
        android.util.Log.d("MainActivity", "SmsGatewayService stopped")
    }
    
    private fun testAlarm() {
        try {
            val intent = Intent(this, SmsGatewayService::class.java)
            intent.action = SmsGatewayService.ACTION_TEST_ALARM
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            android.util.Log.d("MainActivity", "Test alarm sent")
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error sending test alarm", e)
        }
    }
    
    private fun stopAlarm() {
        try {
            val intent = Intent(this, SmsGatewayService::class.java)
            intent.action = SmsGatewayService.ACTION_STOP_ALARM
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            android.util.Log.d("MainActivity", "Stop alarm sent")
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error stopping alarm", e)
        }
    }
    
    private fun toggleAlarm() {
        if (SmsGatewayService.isAlarmActive) {
            stopAlarm()
            // Immediately update UI to show "Test Alarm" button
            isAlarmActive = false
        } else {
            testAlarm()
            // Immediately update UI to show "Stop Alarm" button
            isAlarmActive = true
        }
        // Update the UI state after a short delay to allow the service to process
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            updateAlarmStatus()
        }, 500)
    }
    
    private fun updateConfigurationStatus() {
        // This will trigger recomposition
    }
    
    private fun updateAlarmStatus() {
        isAlarmActive = SmsGatewayService.isAlarmActive
    }
    
    private fun updateAutoReconnectSetting() {
        try {
            val intent = Intent(this, SmsGatewayService::class.java)
            intent.action = "UPDATE_AUTO_RECONNECT"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            android.util.Log.d("MainActivity", "Auto reconnect update sent to service")
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error updating auto reconnect setting", e)
        }
    }
    
    private fun startAlarmStatusUpdates() {
        // Update alarm status every 1 second to keep UI in sync
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(object : Runnable {
            override fun run() {
                updateAlarmStatus()
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this, 1000)
            }
        }, 1000)
    }
    

    
    private fun restartServicesWithNewConfig() {
        try {
            android.util.Log.d("MainActivity", "Restarting services with new configuration")
            
            // Stop existing services
            val stopIntent = Intent(this, SmsGatewayService::class.java)
            stopService(stopIntent)
            
            // Wait a bit for services to stop
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                // Start services with new configuration
                val startIntent = Intent(this, SmsGatewayService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    startForegroundService(startIntent)
                } else {
                    startService(startIntent)
                }
                
                android.util.Log.d("MainActivity", "Services restarted with new configuration")
            }, 1000) // 1 second delay
            
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error restarting services", e)
        }
    }
    
    private fun requestPermissions() {
        val permissions = mutableListOf<String>()
        
        // SMS permissions
        permissions.add(android.Manifest.permission.RECEIVE_SMS)
        permissions.add(android.Manifest.permission.SEND_SMS)
        permissions.add(android.Manifest.permission.READ_SMS)
        
        // Phone state permissions
        permissions.add(android.Manifest.permission.READ_PHONE_STATE)
        permissions.add(android.Manifest.permission.READ_PHONE_NUMBERS)
        
        // Note: READ_SUBSCRIPTION_INFO is a system-level permission
        // and cannot be requested by regular apps
        
        // Camera permission for QR scanning
        permissions.add(android.Manifest.permission.CAMERA)
        
        // Location permission for better signal strength
        permissions.add(android.Manifest.permission.ACCESS_FINE_LOCATION)
        permissions.add(android.Manifest.permission.ACCESS_COARSE_LOCATION)
        
        // Vibration permission for find device feature
        permissions.add(android.Manifest.permission.VIBRATE)
        
        // Check which permissions are not granted
        val permissionsToRequest = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()
        
        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "sms_gateway_channel",
                "SMS Gateway Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background service for SMS gateway"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun registerSimCardChangeReceiver() {
        try {
            simCardChangeReceiver = SimCardChangeReceiver()
            
            // WebSocketClient ve DeviceInfo'yu receiver'a bağla
            webSocketClient?.let { client ->
                SimCardChangeReceiver.setWebSocketClient(client)
            }
            SimCardChangeReceiver.setDeviceInfo(deviceInfo)
            
            val intentFilter = IntentFilter().apply {
                addAction(android.telephony.TelephonyManager.ACTION_PHONE_STATE_CHANGED)
                addAction("android.intent.action.SIM_STATE_CHANGED")
                addAction("android.intent.action.SERVICE_STATE")
                addAction("android.intent.action.AIRPLANE_MODE")
            }
            
            registerReceiver(simCardChangeReceiver, intentFilter)
            android.util.Log.d("MainActivity", "SIM card change receiver registered")
            
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error registering SIM card change receiver", e)
        }
    }
    
    private fun unregisterSimCardChangeReceiver() {
        try {
            simCardChangeReceiver?.let { receiver ->
                unregisterReceiver(receiver)
                simCardChangeReceiver = null
                android.util.Log.d("MainActivity", "SIM card change receiver unregistered")
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error unregistering SIM card change receiver", e)
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        unregisterSimCardChangeReceiver()
        webSocketClient?.cleanup()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreenWithDrawer(
    onQrScanClick: () -> Unit,
    onSetDefaultSmsClick: () -> Unit,
    onSetDefaultDialerClick: () -> Unit,
    onStartServicesClick: () -> Unit,
    onStopServicesClick: () -> Unit,
    onToggleAlarm: () -> Unit,
    onAutoReconnectUpdate: () -> Unit,
    configUpdateTrigger: Int,
    autoReconnectUpdateTrigger: Int,
    isAlarmActive: Boolean
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var selectedItem by remember { mutableStateOf(0) }
    
    val items = listOf(
        NavigationItem(
            title = "Home",
            icon = Icons.Default.Home,
            description = "Main dashboard"
        ),
        NavigationItem(
            title = "SIM Information",
            icon = Icons.Default.Info,
            description = "SIM card details"
        ),
        NavigationItem(
            title = "Permissions",
            icon = Icons.Default.Settings,
            description = "App permissions"
        ),
        NavigationItem(
            title = "Settings",
            icon = Icons.Default.Settings,
            description = "App settings"
        ),
        NavigationItem(
            title = "About",
            icon = Icons.Default.Info,
            description = "App information"
        )
    )
    
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "TSIM Cloud Client",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                items.forEachIndexed { index, item ->
                    NavigationDrawerItem(
                        icon = { Icon(item.icon, contentDescription = null) },
                        label = { Text(item.title) },
                        selected = index == selectedItem,
                        onClick = {
                            scope.launch {
                                selectedItem = index
                                drawerState.close()
                            }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("TSIM Cloud Client") },
                    navigationIcon = {
                        IconButton(onClick = {
                            scope.launch {
                                drawerState.open()
                            }
                        }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { paddingValues ->
            when (selectedItem) {
                0 ->                     MainScreen(
                        onQrScanClick = onQrScanClick,
                        onSetDefaultSmsClick = onSetDefaultSmsClick,
                        onSetDefaultDialerClick = onSetDefaultDialerClick,
                        onStartServicesClick = onStartServicesClick,
                        onStopServicesClick = onStopServicesClick,
                        onToggleAlarm = onToggleAlarm,
                        configUpdateTrigger = configUpdateTrigger,
                        isAlarmActive = isAlarmActive,
                        modifier = Modifier.padding(paddingValues)
                    )
                1 -> SimInfoScreen(
                    configUpdateTrigger = configUpdateTrigger,
                    modifier = Modifier.padding(paddingValues)
                )
                2 -> PermissionsScreen(
                    modifier = Modifier.padding(paddingValues)
                )
                3 -> SettingsScreen(
                    onAutoReconnectChanged = onAutoReconnectUpdate,
                    modifier = Modifier.padding(paddingValues)
                )
                4 -> AboutScreen(
                    modifier = Modifier.padding(paddingValues)
                )
            }
        }
    }
}

data class NavigationItem(
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val description: String
)



@Composable
fun SimInfoScreen(configUpdateTrigger: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val deviceInfo = remember { DeviceInfo(context) }
    val preferencesManager = remember { PreferencesManager(context) }
    var simInfo by remember { mutableStateOf(deviceInfo.getDualSimInfo()) }
    
    LaunchedEffect(configUpdateTrigger) {
        simInfo = deviceInfo.getDualSimInfo()
    }
    
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SIM Information",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Device Information",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text("Manufacturer: ${deviceInfo.getManufacturer()}")
                    Text("Model: ${deviceInfo.getModel()}")
                    Text("Android Version: ${deviceInfo.getAndroidVersion()}")
                    Text("Group Name: ${deviceInfo.getDeviceGroup()}")
                    Text("Site Name: ${deviceInfo.getcountrySite()}")
                    Text("WebSocket URL: ${deviceInfo.getWebsocketUrl()}")
                    Text("SIM Slots: ${simInfo["sim_slot_count"]}")
                    Text("Dual SIM: ${if (simInfo["is_dual_sim"] == true) "Yes" else "No"}")
                }
            }
        }
        
        if (simInfo["is_dual_sim"] == true) {
            val simInfoList = simInfo["sim_info_list"] as? List<Map<String, String>>
            
            simInfoList?.forEachIndexed { index, sim ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "SIM ${index + 1}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text("Carrier: ${sim["carrier_name"]}")
                            Text("Number: ${sim["number"]}")
                            Text("MCC/MNC: ${sim["mcc"]}/${sim["mnc"]}")
                            Text("IMEI: ${sim["imei"]}")
                            Text("IMSI: ${sim["imsi"]}")
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text(
                                text = "Protection & Alarm Settings",
                                fontWeight = FontWeight.Bold
                            )
                            Text("Daily SMS Limit: ${if (index == 0) preferencesManager.getSim1DailySmsLimit() else preferencesManager.getSim2DailySmsLimit()}")
                            Text("Monthly SMS Limit: ${if (index == 0) preferencesManager.getSim1MonthlySmsLimit() else preferencesManager.getSim2MonthlySmsLimit()}")
                            Text("Guard Interval (sec): ${if (index == 0) preferencesManager.getSim1GuardInterval() else preferencesManager.getSim2GuardInterval()}")
                            

                            
                            Text("Battery Alarm: ${if (preferencesManager.isEnableBatteryAlarms()) "Enabled" else "Disabled"}")
                            Text("Error Alarm: ${if (preferencesManager.isEnableErrorAlarms()) "Enabled" else "Disabled"}")
                            Text("Offline Alarm: ${if (preferencesManager.isEnableOfflineAlarms()) "Enabled" else "Disabled"}")
                            Text("Signal Alarm: ${if (preferencesManager.isEnableSignalAlarms()) "Enabled" else "Disabled"}")
                            Text("SIM Balance Alarm: ${if (preferencesManager.isEnableSimBalanceAlarms()) "Enabled" else "Disabled"}")
                            Text("Auto Disable SIM: ${if (preferencesManager.isAutoDisableSimOnAlarm()) "Enabled" else "Disabled"}")
                        }
                    }
                }
            }
        }
        
        // IMSI-based SIM Card Detection Settings
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "SIM Card Change Detection",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    var enableImsiDetection by remember { mutableStateOf(preferencesManager.isImsiBasedDetectionEnabled()) }
                    var alarmDelay by remember { mutableStateOf(preferencesManager.getSimCardChangeAlarmDelay() / 1000) } // Convert to seconds
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("IMSI-based Detection")
                        Switch(
                            checked = enableImsiDetection,
                            onCheckedChange = { checked ->
                                enableImsiDetection = checked
                                preferencesManager.setEnableImsiBasedDetection(checked)
                            }
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text("Alarm Delay (seconds): $alarmDelay")
                    Slider(
                        value = alarmDelay.toFloat(),
                        onValueChange = { value ->
                            alarmDelay = value.toInt()
                            preferencesManager.setSimCardChangeAlarmDelay(value.toInt() * 1000)
                        },
                        valueRange = 1f..30f,
                        steps = 29
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Current IMSI List:",
                        fontWeight = FontWeight.Bold
                    )
                    val currentImsis = preferencesManager.getLastImsiList()
                    if (currentImsis.isNotEmpty()) {
                        currentImsis.forEachIndexed { index, imsi ->
                            Text("IMSI ${index + 1}: $imsi")
                        }
                    } else {
                        Text("No IMSI data available")
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Button(
                        onClick = {
                            preferencesManager.clearLastImsiList()
                            preferencesManager.clearLastSimCards()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Clear SIM Card History")
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var permissionsStatus by remember { mutableStateOf(getPermissionsStatus(context)) }
    
    LaunchedEffect(Unit) {
        permissionsStatus = getPermissionsStatus(context)
    }
    
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Permissions",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Required Permissions",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    permissionsStatus.forEach { (permission, granted) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = getPermissionDisplayName(permission),
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = getPermissionDescription(permission),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = if (granted) "✓" else "✗",
                                color = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Permission Information",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "This app requires various permissions to function properly:",
                        fontSize = 14.sp
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text("• SMS permissions for sending and receiving messages")
                    Text("• Phone permissions for device information")
                    Text("• Camera permission for QR code scanning")
                    Text("• Location permissions for signal strength")
                    Text("• Vibration permission for alarm notifications")
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    onAutoReconnectChanged: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val preferencesManager = remember { PreferencesManager(context) }
    val qrConfigManager = remember { QrConfigManager(context) }
    
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Connection Settings",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    var host by remember { mutableStateOf(extractHostFromUrl(qrConfigManager.getWebsocketUrl() ?: "")) }
                    var apiKey by remember { mutableStateOf(qrConfigManager.getApiKey() ?: "") }
                    var selectedProtocol by remember { mutableStateOf(extractProtocolFromUrl(qrConfigManager.getWebsocketUrl() ?: "")) }
                    
                    // Protocol Selection
                    Text(
                        text = "Protocol",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedProtocol == "wss",
                                onClick = { selectedProtocol = "wss" }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WSS (Secure)")
                        }
                        
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedProtocol == "ws",
                                onClick = { selectedProtocol = "ws" }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WS (Plain)")
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedTextField(
                        value = host,
                        onValueChange = { host = it },
                        label = { Text("Host") },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("tsimserver.icell.cloud") }
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = { Text("API Key") },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Enter your API key") }
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Button(
                        onClick = {
                            val websocketUrl = "$selectedProtocol://$host/ws"
                            qrConfigManager.setWebsocketUrl(websocketUrl)
                            qrConfigManager.setApiKey(apiKey)
                            
                            Toast.makeText(context, "Connection settings updated", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = host.isNotEmpty() && apiKey.isNotEmpty()
                    ) {
                        Text("Update Connection Settings")
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedButton(
                        onClick = {
                            // Reset to current QR config values
                            host = extractHostFromUrl(qrConfigManager.getWebsocketUrl() ?: "")
                            apiKey = qrConfigManager.getApiKey() ?: ""
                            selectedProtocol = extractProtocolFromUrl(qrConfigManager.getWebsocketUrl() ?: "")
                            
                            Toast.makeText(context, "Reset to QR configuration", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reset to QR Config")
                    }
                }
            }
        }
        

        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Queue Statistics",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Delivery Reports
                    Text(
                        text = "Delivery Reports",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text("Pending: 0 | Sent: 0 | Delivered: 0 | Failed: 0")
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // USSD Logs
                    Text(
                        text = "USSD Logs",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text("Pending: 0 | Sent: 0")
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Alarm Logs
                    Text(
                        text = "Alarm Logs",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text("Pending: 0 | Sent: 0")
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Statistics will be updated when SMS Gateway Service is running",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Connection Settings",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    var autoReconnect by remember { mutableStateOf(preferencesManager.isAutoReconnectEnabled()) }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Auto Reconnect")
                            Text(
                                text = "Automatically reconnect when connection is lost",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = autoReconnect,
                            onCheckedChange = { 
                                autoReconnect = it
                                preferencesManager.saveAutoReconnect(it)
                                onAutoReconnectChanged()
                            }
                        )
                    }
                }
            }
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Alarm Settings",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    var batteryAlarm by remember { mutableStateOf(preferencesManager.isEnableBatteryAlarms()) }
                    var errorAlarm by remember { mutableStateOf(preferencesManager.isEnableErrorAlarms()) }
                    var offlineAlarm by remember { mutableStateOf(preferencesManager.isEnableOfflineAlarms()) }
                    var signalAlarm by remember { mutableStateOf(preferencesManager.isEnableSignalAlarms()) }
                    var simBalanceAlarm by remember { mutableStateOf(preferencesManager.isEnableSimBalanceAlarms()) }
                    var autoDisableSim by remember { mutableStateOf(preferencesManager.isAutoDisableSimOnAlarm()) }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Battery Alarm")
                        Switch(
                            checked = batteryAlarm,
                            onCheckedChange = { 
                                batteryAlarm = it
                                preferencesManager.setEnableBatteryAlarms(it)
                            }
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Error Alarm")
                        Switch(
                            checked = errorAlarm,
                            onCheckedChange = { 
                                errorAlarm = it
                                preferencesManager.setEnableErrorAlarms(it)
                            }
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Offline Alarm")
                        Switch(
                            checked = offlineAlarm,
                            onCheckedChange = { 
                                offlineAlarm = it
                                preferencesManager.setEnableOfflineAlarms(it)
                            }
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Signal Alarm")
                        Switch(
                            checked = signalAlarm,
                            onCheckedChange = { 
                                signalAlarm = it
                                preferencesManager.setEnableSignalAlarms(it)
                            }
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SIM Balance Alarm")
                        Switch(
                            checked = simBalanceAlarm,
                            onCheckedChange = { 
                                simBalanceAlarm = it
                                preferencesManager.setEnableSimBalanceAlarms(it)
                            }
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Auto Disable SIM on Alarm")
                        Switch(
                            checked = autoDisableSim,
                            onCheckedChange = { 
                                autoDisableSim = it
                                preferencesManager.setAutoDisableSimOnAlarm(it)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val deviceInfo = remember { DeviceInfo(context) }
    
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "About",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "App Information",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text("Version: 1.0.0")
                    Text("Package: ${context.packageName}")
                    Text("Manufacturer: ${deviceInfo.getManufacturer()}")
                    Text("Model: ${deviceInfo.getModel()}")
                    Text("Android Version: ${deviceInfo.getAndroidVersion()}")
                    Text("Device Group: ${deviceInfo.getDeviceGroup()}")
                    Text("Site Name: ${deviceInfo.getcountrySite()}")
                }
            }
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Features",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text("• SMS Gateway Service")
                    Text("• USSD Command Support")
                    Text("• Dual SIM Support")
                    Text("• Alarm Management")
                    Text("• WebSocket Communication")
                    Text("• QR Code Configuration")
                    Text("• Background Service")
                    Text("• Notification Support")
                }
            }
        }
    }
}

@Composable
fun MainScreen(
    onQrScanClick: () -> Unit,
    onSetDefaultSmsClick: () -> Unit,
    onSetDefaultDialerClick: () -> Unit,
    onStartServicesClick: () -> Unit,
    onStopServicesClick: () -> Unit,
    onToggleAlarm: () -> Unit,
    configUpdateTrigger: Int,
    isAlarmActive: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val deviceInfo = remember { DeviceInfo(context) }
    val preferencesManager = remember { PreferencesManager(context) }
    val qrConfigManager = remember { QrConfigManager(context) }
    val view = LocalView.current
    
    var isConfigured by remember { mutableStateOf(qrConfigManager.isDeviceConfigured()) }
    var isDefaultSmsApp by remember { mutableStateOf(false) }
    var isDefaultDialer by remember { mutableStateOf(false) }
    var isServicesRunning by remember { mutableStateOf(false) }

    
    // Background color animation
    val backgroundColor by animateColorAsState(
        targetValue = if (isAlarmActive) Color.Red else Color.Transparent,
        animationSpec = tween(1000),
        label = "background_color"
    )
    
    // Set window background color
    LaunchedEffect(backgroundColor) {
        view.setBackgroundColor(backgroundColor.toArgb())
    }
    
    // Check if app is default SMS app
    LaunchedEffect(Unit) {
        isDefaultSmsApp = context.packageName == android.provider.Telephony.Sms.getDefaultSmsPackage(context)
    }
    
    // Check if app is default dialer
    LaunchedEffect(Unit) {
        isDefaultDialer = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            try {
                val roleManager = context.getSystemService(android.app.role.RoleManager::class.java)
                if (roleManager != null && roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER)) {
                    roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)
                } else {
                    // Fallback to reflection method
                    val telephonyManager = context.getSystemService(android.telephony.TelephonyManager::class.java)
                    val defaultDialerPackage = telephonyManager.javaClass.getMethod("getDefaultDialerPackage").invoke(telephonyManager) as? String
                    context.packageName == defaultDialerPackage
                }
            } catch (e: Exception) {
                android.util.Log.w("MainActivity", "Error checking default dialer: ${e.message}")
                false
            }
        } else {
            // For older versions, we can't reliably check this
            false
        }
    }
    

    
    // Update configuration status
    LaunchedEffect(configUpdateTrigger) {
        isConfigured = qrConfigManager.isDeviceConfigured()
    }
    
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
    Text(
                text = "TSIM Cloud Client",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            ConfigurationCard(
                isConfigured = isConfigured,
                onQrScanClick = onQrScanClick
            )
        }
        
        item {
            DefaultSmsAppCard(
                isDefaultSmsApp = isDefaultSmsApp,
                onSetDefaultClick = onSetDefaultSmsClick
            )
        }
        
        item {
            DefaultDialerCard(
                isDefaultDialer = isDefaultDialer,
                onSetDefaultClick = onSetDefaultDialerClick
            )
        }
        
        item {
            ServicesCard(
                isConfigured = isConfigured,
                isDefaultSmsApp = isDefaultSmsApp,
                isServicesRunning = isServicesRunning,
                onStartServices = {
                    onStartServicesClick()
                    isServicesRunning = true
                },
                onStopServices = {
                    onStopServicesClick()
                    isServicesRunning = false
                }
            )
        }
        
        item {
            AlarmStatusCard(
                isAlarmActive = isAlarmActive,
                onAlarmToggle = onToggleAlarm
            )
        }
        

    }
}



private fun getPermissionsStatus(context: android.content.Context): Map<String, Boolean> {
    val permissions = mutableListOf(
        android.Manifest.permission.RECEIVE_SMS,
        android.Manifest.permission.SEND_SMS,
        android.Manifest.permission.READ_SMS,
        android.Manifest.permission.READ_PHONE_STATE,
        android.Manifest.permission.READ_PHONE_NUMBERS,
        android.Manifest.permission.CAMERA,
        android.Manifest.permission.ACCESS_FINE_LOCATION,
        android.Manifest.permission.ACCESS_COARSE_LOCATION,
        android.Manifest.permission.VIBRATE
    )
    
    // Note: READ_SUBSCRIPTION_INFO is a system-level permission
    // and cannot be requested by regular apps
    
    return permissions.associateWith { permission ->
        context.checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}

private fun getPermissionDisplayName(permission: String): String {
    return when (permission) {
        android.Manifest.permission.RECEIVE_SMS -> "Receive SMS"
        android.Manifest.permission.SEND_SMS -> "Send SMS"
        android.Manifest.permission.READ_SMS -> "Read SMS"
        android.Manifest.permission.READ_PHONE_STATE -> "Read Phone State"
        android.Manifest.permission.READ_PHONE_NUMBERS -> "Read Phone Numbers"
        // READ_SUBSCRIPTION_INFO is system-level permission
        android.Manifest.permission.CAMERA -> "Camera"
        android.Manifest.permission.ACCESS_FINE_LOCATION -> "Fine Location"
        android.Manifest.permission.ACCESS_COARSE_LOCATION -> "Coarse Location"
        android.Manifest.permission.VIBRATE -> "Vibrate"
        else -> permission
    }
}

private fun getPermissionDescription(permission: String): String {
    return when (permission) {
        android.Manifest.permission.RECEIVE_SMS -> "Required to receive incoming SMS messages"
        android.Manifest.permission.SEND_SMS -> "Required to send SMS messages"
        android.Manifest.permission.READ_SMS -> "Required to read SMS messages from device"
        android.Manifest.permission.READ_PHONE_STATE -> "Required to get device information"
        android.Manifest.permission.READ_PHONE_NUMBERS -> "Required to get phone numbers"
        android.Manifest.permission.CAMERA -> "Required for QR code scanning"
        android.Manifest.permission.ACCESS_FINE_LOCATION -> "Required for better signal strength detection"
        android.Manifest.permission.ACCESS_COARSE_LOCATION -> "Required for location-based services"
        android.Manifest.permission.VIBRATE -> "Required for alarm notifications"
        else -> "Required for app functionality"
    }
}

private fun extractHostFromUrl(url: String): String {
    return try {
        if (url.startsWith("ws://") || url.startsWith("wss://")) {
            val withoutProtocol = url.substringAfter("://")
            val host = withoutProtocol.substringBefore("/")
            host
        } else {
            url
        }
    } catch (e: Exception) {
        url
    }
}

private fun extractProtocolFromUrl(url: String): String {
    return try {
        when {
            url.startsWith("wss://") -> "wss"
            url.startsWith("ws://") -> "ws"
            else -> "wss" // Default to secure
        }
    } catch (e: Exception) {
        "wss" // Default to secure
    }
}

@Composable
fun AlarmStatusCard(
    isAlarmActive: Boolean,
    onAlarmToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Alarm Status",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isAlarmActive) "ALARM ACTIVE" else "Normal",
                    color = if (isAlarmActive) Color.Red else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                
                Button(
                    onClick = onAlarmToggle,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAlarmActive) Color.Red else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(if (isAlarmActive) "Stop Alarm" else "Test Alarm")
                }
            }
            
            if (isAlarmActive) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Alarm is active - device is vibrating and showing notification",
                    color = Color.Red,
                    fontSize = 12.sp
                )
            } else {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Click 'Test Alarm' to send test alarm to server",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }
        }
    }
}



@Composable
fun ConfigurationCard(
    isConfigured: Boolean,
    onQrScanClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Configuration",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isConfigured) "Configured" else "Not Configured",
                    color = if (isConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                
                Button(
                    onClick = onQrScanClick
                ) {
                    Text("Scan QR Code")
                }
            }
        }
    }
}

@Composable
fun DefaultSmsAppCard(
    isDefaultSmsApp: Boolean,
    onSetDefaultClick: () -> Unit
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Default SMS App",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isDefaultSmsApp) "Default" else "Not Default",
                    color = if (isDefaultSmsApp) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                Button(
                    onClick = {
                        if (!isDefaultSmsApp) {
                            onSetDefaultClick()
                        }
                    },
                    enabled = !isDefaultSmsApp
                ) {
                    Text("Set as Default")
                }
            }
        }
    }
}

@Composable
fun DefaultDialerCard(
    isDefaultDialer: Boolean,
    onSetDefaultClick: () -> Unit
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Default Dialer App",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isDefaultDialer) "Default" else "Not Default",
                    color = if (isDefaultDialer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                Button(
                    onClick = {
                        if (!isDefaultDialer) {
                            onSetDefaultClick()
                        }
                    },
                    enabled = !isDefaultDialer
                ) {
                    Text("Set as Default")
                }
            }
            if (!isDefaultDialer) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Required for automatic USSD popup control",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "USSD popups will be automatically controlled",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}



@Composable
fun ServicesCard(
    isConfigured: Boolean,
    isDefaultSmsApp: Boolean,
    isServicesRunning: Boolean,
    onStartServices: () -> Unit,
    onStopServices: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Services",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isServicesRunning) "Running" else "Stopped",
                    color = if (isServicesRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onStartServices,
                        enabled = isConfigured && isDefaultSmsApp && !isServicesRunning
                    ) {
                        Text("Start")
                    }
                    
                    Button(
                        onClick = onStopServices,
                        enabled = isServicesRunning
                    ) {
                        Text("Stop")
                    }
                }
            }
            
            // Show requirements status
            Spacer(modifier = Modifier.height(8.dp))
            
            if (!isConfigured) {
                Text(
                    text = "⚠️ Please scan QR code to configure device first",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp
                )
            } else if (!isDefaultSmsApp) {
                Text(
                    text = "⚠️ Please set as default SMS app first",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp
                )
            } else if (!isServicesRunning) {
                Text(
                    text = "✅ Ready to start services",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 12.sp
                )
            } else {
                Text(
                    text = "✅ Services are running",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 12.sp
                )
            }
        }
    }
}