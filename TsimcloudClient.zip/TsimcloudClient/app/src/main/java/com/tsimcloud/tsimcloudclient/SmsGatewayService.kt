package com.tsimcloud.tsimcloudclient

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.util.Log
import com.tsimcloud.tsimcloudclient.utils.PreferencesManager
import com.tsimcloud.tsimcloudclient.utils.QrConfigManager
import com.tsimcloud.tsimcloudclient.utils.SmsMessageHandler
import com.tsimcloud.tsimcloudclient.utils.WebSocketClient
import com.tsimcloud.tsimcloudclient.utils.UssdUtils
import com.tsimcloud.tsimcloudclient.utils.UssdManager
import com.tsimcloud.tsimcloudclient.utils.SmsDatabase
import com.tsimcloud.tsimcloudclient.utils.SmsQueueManager
import kotlinx.coroutines.*
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import android.app.PendingIntent
import android.content.Context
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.app.Activity
import androidx.core.app.NotificationCompat

class SmsGatewayService : Service() {
    
    companion object {
        private const val TAG = "SmsGatewayService"
        const val ACTION_SEND_SMS = "com.tsimcloud.tsimcloudclient.SEND_SMS"
        const val ACTION_SEND_MMS = "com.tsimcloud.tsimcloudclient.SEND_MMS"
        const val ACTION_SEND_USSD = "com.tsimcloud.tsimcloudclient.SEND_USSD"
        const val ACTION_RESPOND_VIA_MESSAGE = "android.intent.action.RESPOND_VIA_MESSAGE"
        const val ACTION_TEST_ALARM = "com.tsimcloud.tsimcloudclient.TEST_ALARM"
        const val ACTION_STOP_ALARM = "com.tsimcloud.tsimcloudclient.STOP_ALARM"
        @Volatile
        var isRunning = false
        @Volatile
        var isAlarmActive = false
    }
    
    private lateinit var qrConfigManager: QrConfigManager
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var deviceInfo: com.tsimcloud.tsimcloudclient.utils.DeviceInfo
    private lateinit var webSocketClient: WebSocketClient
    private lateinit var ussdManager: UssdManager
    private lateinit var smsHandler: SmsMessageHandler
    private lateinit var smsDatabase: SmsDatabase
    private lateinit var smsQueueManager: SmsQueueManager
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val pendingMessages = ConcurrentHashMap<String, Boolean>()
    
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "SmsGatewayService created")
        
        qrConfigManager = QrConfigManager(this)
        preferencesManager = PreferencesManager(this)
        deviceInfo = com.tsimcloud.tsimcloudclient.utils.DeviceInfo(this)
        
        // Register USSD popup killer
        registerUssdPopupKiller()
        
        // Initialize USSD response receiver
        registerUssdResponseReceiver()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "SmsGatewayService started")
        
        // Multiple instance koruması
        if (isRunning) {
            Log.w(TAG, "SmsGatewayService already running, checking for config updates")
            
            // Check if configuration has changed and reconnect if needed
            if (::webSocketClient.isInitialized) {
                val currentConfig = qrConfigManager.getCurrentConfig()
                if (currentConfig != null) {
                    val currentUrl = webSocketClient.getCurrentUrl()
                    if (currentUrl != currentConfig.websocketUrl) {
                        Log.d(TAG, "Configuration changed, reconnecting WebSocket")
                        Log.d(TAG, "Old URL: $currentUrl")
                        Log.d(TAG, "New URL: ${currentConfig.websocketUrl}")
                        
                        // Cleanup old connection
                        webSocketClient.cleanup()
                        
                        // Create new WebSocket client with updated config
                        webSocketClient = WebSocketClient(
                            this,
                            currentConfig.websocketUrl,
                            currentConfig.apiKey,
                            deviceInfo
                        )
                        
                        // Set auto reconnect setting from preferences
                        val autoReconnectEnabled = preferencesManager.isAutoReconnectEnabled()
                        webSocketClient.setAutoReconnect(autoReconnectEnabled)
                        Log.d(TAG, "Auto reconnect setting: $autoReconnectEnabled")
                        
                        // Update other components
                        smsHandler = SmsMessageHandler(
                            this,
                            webSocketClient,
                            deviceInfo,
                            preferencesManager
                        )
                        
                        // Connect to new WebSocket
                        webSocketClient.connect()
                        
                        // Set up WebSocket message handler
                        webSocketClient.onMessage = { message ->
                            Log.d(TAG, "WebSocket callback triggered with message: $message")
                            handleWebSocketMessage(message)
                        }
                        
                        Log.d(TAG, "WebSocket client reconnected with new configuration")
                    }
                }
            }
            
            intent?.let { handleIntent(it) }
            return START_STICKY
        }
        
        isRunning = true
        
        // Start foreground service
        startForegroundService()
        
        // Debug: Check configuration status
        Log.d(TAG, "Device configured: ${qrConfigManager.isDeviceConfigured()}")
        
        // Check if device is configured
        if (!qrConfigManager.isDeviceConfigured()) {
            Log.w(TAG, "Device not configured, stopping service")
            stopSelf()
            return START_NOT_STICKY
        }
        
        // Initialize WebSocket client if not already initialized
        if (!::webSocketClient.isInitialized) {
            val config = qrConfigManager.getCurrentConfig()
            Log.d(TAG, "Config from QrConfigManager: $config")
            
            if (config != null) {
                Log.d(TAG, "WebSocket URL: ${config.websocketUrl}")
                Log.d(TAG, "API Key: ${config.apiKey}")

                
                webSocketClient = WebSocketClient(
                    this,
                    config.websocketUrl,
                    config.apiKey,
                    deviceInfo
                )
                
                // Set auto reconnect setting from preferences
                val autoReconnectEnabled = preferencesManager.isAutoReconnectEnabled()
                webSocketClient.setAutoReconnect(autoReconnectEnabled)
                Log.d(TAG, "Auto reconnect setting: $autoReconnectEnabled")
                
                // Initialize USSD Manager
                ussdManager = UssdManager(this, webSocketClient)
                
                // Set USSD Manager in UssdResponseReceiver
                UssdResponseReceiver.ussdManager = ussdManager
                
                smsHandler = SmsMessageHandler(
                    this,
                    webSocketClient,
                    deviceInfo,
                    preferencesManager
                )
                
                // Initialize SMS database and queue manager
                smsDatabase = SmsDatabase(this)
                smsQueueManager = SmsQueueManager(this, smsDatabase, webSocketClient, preferencesManager)
                
                // Connect to WebSocket
                webSocketClient.connect()
                
                // Set up WebSocket message handler
                webSocketClient.onMessage = { message ->
                    Log.d(TAG, "WebSocket callback triggered with message: $message")
                    handleWebSocketMessage(message)
                }
                
                // Start SMS queue manager
                smsQueueManager.start()
                
                Log.d(TAG, "WebSocket client initialized and connected")
                Log.d(TAG, "SMS queue manager started")
                

            } else {
                Log.e(TAG, "Failed to get device configuration")
                // Debug: Check raw preferences
                Log.d(TAG, "Raw websocket URL: ${preferencesManager.getWebsocketUrl()}")
                Log.d(TAG, "Raw API key: ${preferencesManager.getApiKey()}")
                Log.d(TAG, "Raw queue name: ${preferencesManager.getQueueName()}")
                Log.d(TAG, "Raw device group: ${preferencesManager.getDeviceGroup()}")
                Log.d(TAG, "Raw countrySite: ${preferencesManager.getcountrySite()}")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        
        intent?.let { handleIntent(it) }
        
        return START_STICKY
    }
    
    private fun startForegroundService() {
        val notification = NotificationCompat.Builder(this, "sms_gateway_channel")
            .setContentTitle("SMS Gateway Service")
            .setContentText("Running in background")
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
        
        startForeground(1, notification)
        Log.d(TAG, "Foreground service started")
    }
    
    private fun handleIntent(intent: Intent) {
        when (intent.action) {
            ACTION_SEND_SMS -> {
                val phoneNumber = intent.getStringExtra("phone_number")
                val message = intent.getStringExtra("message")
                val simSlot = intent.getIntExtra("sim_slot", 1)
                val messageId = intent.getStringExtra("message_id") ?: ""
                
                if (phoneNumber != null && message != null) {
                    sendSms(phoneNumber, message, simSlot, messageId)
                }
            }
            ACTION_SEND_MMS -> {
                val phoneNumber = intent.getStringExtra("phone_number")
                val subject = intent.getStringExtra("subject")
                val parts = intent.getStringArrayListExtra("parts")
                val simSlot = intent.getIntExtra("sim_slot", 1)
                
                if (phoneNumber != null && parts != null) {
                    sendMms(phoneNumber, subject ?: "", parts, simSlot)
                }
            }
            ACTION_SEND_USSD -> {
                val ussdCode = intent.getStringExtra("ussd_code")
                val simSlot = intent.getIntExtra("sim_slot", 1)
                val messageId = intent.getStringExtra("message_id") ?: ""
                val sessionId = intent.getStringExtra("session_id") ?: ""
                
                if (ussdCode != null) {
                    sendUssd(ussdCode, simSlot, messageId, sessionId)
                }
            }
            ACTION_RESPOND_VIA_MESSAGE -> {
                // Handle RESPOND_VIA_MESSAGE intent (from deleted SmsSendService)
                val phoneNumber = intent.data?.schemeSpecificPart
                val message = intent.getStringExtra("sms_body")
                val simSlot = intent.getIntExtra("sim_slot", 1)
                val messageId = intent.getStringExtra("message_id") ?: ""
                
                if (phoneNumber != null && message != null) {
                    Log.d(TAG, "Handling RESPOND_VIA_MESSAGE: $phoneNumber, $message")
                    sendSms(phoneNumber, message, simSlot, messageId)
                } else {
                    Log.w(TAG, "RESPOND_VIA_MESSAGE missing phone number or message")
                }
            }
            ACTION_TEST_ALARM -> {
                Log.d(TAG, "Test alarm requested")
                startAlarm("test_alarm", "Test alarm from device")
            }
            ACTION_STOP_ALARM -> {
                Log.d(TAG, "Stop alarm requested")
                stopAlarm()
            }
            "UPDATE_AUTO_RECONNECT" -> {
                Log.d(TAG, "Update auto reconnect setting requested")
                updateAutoReconnectSetting()
            }
        }
    }
    
    /**
     * Handle WebSocket messages
     */
    private fun handleWebSocketMessage(message: String) {
        try {
            Log.d(TAG, "WebSocket message received: $message")
            
            val jsonObject = JSONObject(message)
            val type = jsonObject.getString("type")
            
            Log.d(TAG, "Processing WebSocket message type: $type")
            
            when (type) {
                "connection_established" -> {
                    // Auth başarılı, ayarları kaydet
                    val settings = jsonObject.getJSONObject("data")
                    saveSettingsToPreferences(settings)
                    Log.d(TAG, "Connection established, settings saved")
                }
                "heartbeat_response" -> {
                    // Heartbeat response, data alanı yok
                    Log.d(TAG, "Heartbeat response received")
                }
                "update_settings" -> {
                    // Ayarları güncelle
                    val settings = jsonObject.getJSONObject("data")
                    saveSettingsToPreferences(settings)
                    Log.d(TAG, "Settings updated from WebSocket")
                }
                "disconnect" -> {
                    // Server'dan disconnect mesajı geldi - sadece log yaz, bağlantıyı kapatma
                    val disconnectMessage = jsonObject.optString("message", "Device deactivated by admin")
                    Log.w(TAG, "Disconnect message received: $disconnectMessage")
                    // WebSocket bağlantısını kapatmıyoruz, sadece log yazıyoruz
                }
                "message_rejected" -> {
                    // Server'dan message rejected mesajı geldi - sadece log yaz, bağlantıyı kapatma
                    val rejectMessage = jsonObject.optString("message", "Device is inactive")
                    val deviceId = jsonObject.optString("device_id", "")
                    Log.w(TAG, "Message rejected: $rejectMessage, Device ID: $deviceId")
                    // WebSocket bağlantısını kapatmıyoruz, sadece log yazıyoruz
                }
                "disconnect_device" -> {
                    // Server'dan disconnect_device mesajı geldi - sadece log yaz, bağlantıyı kapatma
                    val disconnectMessage = jsonObject.optString("message", "Device disconnect requested")
                    val deviceId = jsonObject.optString("device_id", "")
                    Log.w(TAG, "Disconnect device message received: $disconnectMessage, Device ID: $deviceId")
                    // WebSocket bağlantısını kapatmıyoruz, sadece log yazıyoruz
                }
                else -> {
                    // Diğer mesajlar için data objesi gerekli
                    val data = try {
                        jsonObject.getJSONObject("data")
                    } catch (e: Exception) {
                        // data alanı JSONObject değilse (örneğin boş array []), null olarak bırak
                        null
                    }
                    
                    Log.d(TAG, "Processing command with data: $data")
                    
                    when (type) {
                        "send_sms" -> {
                            if (data != null) {
                                val phoneNumber = data.getString("phone_number")
                                val message = data.getString("message")
                                val simSlot = data.optInt("sim_slot", 1)
                                val messageId = data.optString("message_id", "") // Laravel'den gelen message_id
                                
                                Log.d(TAG, "SMS command received: $phoneNumber, $message, SIM$simSlot, MessageID: $messageId")
                                sendSms(phoneNumber, message, simSlot, messageId)
                            } else {
                                Log.w(TAG, "SMS command received but data is null")
                            }
                        }
                        "send_mms" -> {
                            if (data != null) {
                                val phoneNumber = data.getString("phone_number")
                                val subject = data.optString("subject", "")
                                val parts = data.getJSONArray("parts")
                                val simSlot = data.optInt("sim_slot", 1)
                                
                                Log.d(TAG, "MMS command received: $phoneNumber, SIM$simSlot")
                                
                                val partsList = mutableListOf<String>()
                                for (i in 0 until parts.length()) {
                                    partsList.add(parts.getString(i))
                                }
                                
                                sendMms(phoneNumber, subject, partsList, simSlot)
                            } else {
                                Log.w(TAG, "MMS command received but data is null")
                            }
                        }
                        "send_ussd" -> {
                            if (data != null) {
                                val ussdCode = data.getString("ussd_code")
                                val simSlot = data.optInt("sim_slot", 1)
                                val messageId = data.optString("message_id", "")
                                val sessionId = data.optString("session_id", "")
                                val delay = data.optInt("delay", 0) // GSL tarzında delay parametresi
                                
                                Log.d(TAG, "USSD command received: $ussdCode, SIM$simSlot, MessageID: $messageId, SessionID: $sessionId, Delay: ${delay}s")
                                
                                // GSL tarzında delay ile USSD gönderimi
                                scope.launch {
                                    if (delay > 0) {
                                        Log.d(TAG, "Waiting for $delay seconds before sending USSD request...")
                                        delay(delay * 1000L)
                                    }
                                    sendUssd(ussdCode, simSlot, messageId, sessionId)
                                }
                            } else {
                                Log.w(TAG, "USSD command received but data is null")
                            }
                        }
                        "send_rcs" -> {
                            if (data != null) {
                                val phoneNumber = data.getString("phone_number")
                                val message = data.getString("message")
                                val messageType = data.optString("message_type", "text")
                                val simSlot = data.optInt("sim_slot", 1)
                                
                                Log.d(TAG, "RCS command received: $phoneNumber, $message, SIM$simSlot")
                                sendRcs(phoneNumber, message, messageType, simSlot)
                            } else {
                                Log.w(TAG, "RCS command received but data is null")
                            }
                        }
                        "find_device" -> {
                            if (data != null) {
                                val message = data.optString("message", "Find my device")
                                
                                Log.d(TAG, "Find device command received: $message")
                                findDevice(message)
                            } else {
                                Log.d(TAG, "Find device command received with default message")
                                findDevice("Find my device")
                            }
                        }
                        "alarm_start" -> {
                            if (data != null) {
                                val alarmType = data.optString("alarm_type", "sim_blocked")
                                val message = data.optString("message", "SIM card is blocked")
                                
                                Log.d(TAG, "Alarm start command received: $alarmType, $message")
                                startAlarm(alarmType, message)
                            } else {
                                Log.d(TAG, "Alarm start command received with default values")
                                startAlarm("sim_blocked", "SIM card is blocked")
                            }
                        }
                        "alarm_stop" -> {
                            Log.d(TAG, "Alarm stop command received")
                            stopAlarm()
                        }
                        else -> {
                            Log.w(TAG, "Unknown WebSocket message type: $type")
                        }
                    }
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error handling WebSocket message: $message", e)
        }
    }
    
    /**
     * Save settings from WebSocket auth response to SharedPreferences
     */
    private fun saveSettingsToPreferences(settings: JSONObject) {
        try {
            // Alarm ayarları
            preferencesManager.setBatteryLowThreshold(settings.optInt("battery_low_threshold", 20))
            preferencesManager.setErrorCountThreshold(settings.optInt("error_count_threshold", 5))
            preferencesManager.setOfflineThresholdMinutes(settings.optInt("offline_threshold_minutes", 30))
            preferencesManager.setSignalLowThreshold(settings.optInt("signal_low_threshold", 10))
            preferencesManager.setLowBalanceThreshold(settings.optDouble("low_balance_threshold", 5.0))
            
            // Alarm enable/disable ayarları
            preferencesManager.setEnableBatteryAlarms(settings.optBoolean("enable_battery_alarms", true))
            preferencesManager.setEnableErrorAlarms(settings.optBoolean("enable_error_alarms", true))
            preferencesManager.setEnableOfflineAlarms(settings.optBoolean("enable_offline_alarms", true))
            preferencesManager.setEnableSignalAlarms(settings.optBoolean("enable_signal_alarms", true))
            preferencesManager.setEnableSimBalanceAlarms(settings.optBoolean("enable_sim_balance_alarms", true))
            preferencesManager.setAutoDisableSimOnAlarm(settings.optBoolean("auto_disable_sim_on_alarm", true))
            
            // SMS limit ayarları
            preferencesManager.setSim1DailySmsLimit(settings.optInt("sim1_daily_sms_limit", 200))
            preferencesManager.setSim1MonthlySmsLimit(settings.optInt("sim1_monthly_sms_limit", 6000))
            preferencesManager.setSim2DailySmsLimit(settings.optInt("sim2_daily_sms_limit", 200))
            preferencesManager.setSim2MonthlySmsLimit(settings.optInt("sim2_monthly_sms_limit", 6000))
            preferencesManager.setEnableSmsLimits(settings.optBoolean("enable_sms_limits", true))
            preferencesManager.setSmsLimitResetHour(settings.optInt("sms_limit_reset_hour", 0))
            preferencesManager.setSim1GuardInterval(settings.optInt("sim1_guard_interval", 60))
            preferencesManager.setSim2GuardInterval(settings.optInt("sim2_guard_interval", 60))
            
            Log.d(TAG, "Settings saved to SharedPreferences")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error saving settings to preferences", e)
        }
    }
    
    /**
     * Send SMS message
     */
    private fun sendSms(phoneNumber: String, message: String, simSlot: Int, messageId: String = "") {
        scope.launch {
            try {
                Log.d(TAG, "Sending SMS to $phoneNumber on SIM$simSlot: $message")
                

                
                // Check SMS limits if enabled
                if (preferencesManager.isSmsLimitsEnabled()) {
                    if (!checkSmsLimits(simSlot)) {
                        Log.w(TAG, "SMS limit exceeded for SIM$simSlot")
                        webSocketClient.sendAlarm("sms_limit_exceeded", "SMS limit exceeded for SIM$simSlot", "warning")
                        return@launch
                    }
                }
                
                // Get SMS manager for specific SIM slot
                val smsManager = getSmsManagerForSlot(simSlot)
                
                // Use provided message_id or generate unique SMS ID
                val smsId = if (messageId.isNotEmpty()) messageId else "sms_${System.currentTimeMillis()}_${(0..9999).random()}"
                
                // Create PendingIntents for delivery reports
                val sentIntent = Intent("SMS_SENT")
                sentIntent.putExtra("sms_id", smsId)
                sentIntent.putExtra("phone_number", phoneNumber)
                sentIntent.putExtra("sim_slot", simSlot)
                val sentPendingIntent = PendingIntent.getBroadcast(
                    this@SmsGatewayService,
                    smsId.hashCode(),
                    sentIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
                
                val deliveredIntent = Intent("SMS_DELIVERED")
                deliveredIntent.putExtra("sms_id", smsId)
                deliveredIntent.putExtra("phone_number", phoneNumber)
                deliveredIntent.putExtra("sim_slot", simSlot)
                val deliveredPendingIntent = PendingIntent.getBroadcast(
                    this@SmsGatewayService,
                    (smsId + "_delivered").hashCode(),
                    deliveredIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
                
                // Register broadcast receivers
                val sentReceiver = object : BroadcastReceiver() {
                    override fun onReceive(context: Context?, intent: Intent?) {
                        val resultCode = this.resultCode
                        when (resultCode) {
                            Activity.RESULT_OK -> {
                                Log.d(TAG, "SMS sent successfully: $smsId")
                                webSocketClient.sendDeviceStatus("sms_sent", mutableMapOf(
                                    "sms_id" to smsId,
                                    "phone_number" to phoneNumber,
                                    "sim_slot" to simSlot,
                                    "status" to "SENT"
                                ))
                            }
                            else -> {
                                Log.e(TAG, "SMS sending failed: $smsId, result code: $resultCode")
                                
                                webSocketClient.sendDeviceStatus("sms_failed", mutableMapOf(
                                    "sms_id" to smsId,
                                    "phone_number" to phoneNumber,
                                    "sim_slot" to simSlot,
                                    "status" to "FAILED",
                                    "error_code" to resultCode
                                ))
                            }
                        }
                        unregisterReceiver(this)
                    }
                }
                
                val deliveredReceiver = object : BroadcastReceiver() {
                    override fun onReceive(context: Context?, intent: Intent?) {
                        val resultCode = this.resultCode
                        when (resultCode) {
                            Activity.RESULT_OK -> {
                                Log.d(TAG, "SMS delivered successfully: $smsId")
                                
                                                // Send delivery report immediately if WebSocket is connected, otherwise add to queue
                if (::smsQueueManager.isInitialized) {
                    if (webSocketClient.isConnected()) {
                        // Send immediately via WebSocket
                        val reportData = mapOf<String, Any>(
                            "message_id" to smsId,
                            "phone_number" to phoneNumber,
                            "sim_slot" to simSlot,
                            "status" to "delivered",
                            "timestamp" to System.currentTimeMillis(),
                            "device_group" to preferencesManager.getDeviceGroup(),
                            "country_site" to preferencesManager.getcountrySite()
                        )
                        val success = webSocketClient.sendJsonMessage("sms_delivery_report", reportData)
                        if (success) {
                            Log.d(TAG, "Delivery report sent immediately: $smsId")
                        } else {
                            // If immediate send fails, add to queue
                            smsQueueManager.addDeliveryReport(smsId, phoneNumber, simSlot, "delivered")
                            Log.d(TAG, "Delivery report added to queue (immediate send failed): $smsId")
                        }
                    } else {
                        // WebSocket not connected, add to queue
                        smsQueueManager.addDeliveryReport(smsId, phoneNumber, simSlot, "delivered")
                        Log.d(TAG, "Delivery report added to queue (WebSocket disconnected): $smsId")
                    }
                }
                            }
                            else -> {
                                Log.e(TAG, "SMS delivery failed: $smsId, result code: $resultCode")
                                
                                // Send delivery report immediately if WebSocket is connected, otherwise add to queue
                                if (::smsQueueManager.isInitialized) {
                                    if (webSocketClient.isConnected()) {
                                        // Send immediately via WebSocket
                                        val reportData = mapOf<String, Any>(
                                            "message_id" to smsId,
                                            "phone_number" to phoneNumber,
                                            "sim_slot" to simSlot,
                                            "status" to "failed",
                                            "timestamp" to System.currentTimeMillis(),
                                            "device_group" to preferencesManager.getDeviceGroup(),
                                            "country_site" to preferencesManager.getcountrySite(),
                                            "failure_reason" to "Error code: $resultCode"
                                        )
                                        val success = webSocketClient.sendJsonMessage("sms_delivery_report", reportData)
                                        if (success) {
                                            Log.d(TAG, "Failed delivery report sent immediately: $smsId")
                                        } else {
                                            // If immediate send fails, add to queue
                                            smsQueueManager.addDeliveryReport(smsId, phoneNumber, simSlot, "failed", "Error code: $resultCode")
                                            Log.d(TAG, "Failed delivery report added to queue (immediate send failed): $smsId")
                                        }
                                    } else {
                                        // WebSocket not connected, add to queue
                                        smsQueueManager.addDeliveryReport(smsId, phoneNumber, simSlot, "failed", "Error code: $resultCode")
                                        Log.d(TAG, "Failed delivery report added to queue (WebSocket disconnected): $smsId")
                                    }
                                }
                            }
                        }
                        unregisterReceiver(this)
                    }
                }
                
                registerReceiver(sentReceiver, IntentFilter("SMS_SENT"))
                registerReceiver(deliveredReceiver, IntentFilter("SMS_DELIVERED"))
                
                // Split message if needed
                val parts = smsManager.divideMessage(message)
                
                // Send SMS parts
                if (parts.size == 1) {
                    smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        parts[0],
                        sentPendingIntent,
                        deliveredPendingIntent
                    )
                } else {
                    val sentPendingIntents = ArrayList<PendingIntent>()
                    val deliveredPendingIntents = ArrayList<PendingIntent>()
                    
                    for (i in parts.indices) {
                        sentPendingIntents.add(sentPendingIntent)
                        deliveredPendingIntents.add(deliveredPendingIntent)
                    }
                    
                    smsManager.sendMultipartTextMessage(
                        phoneNumber,
                        null,
                        parts,
                        sentPendingIntents,
                        deliveredPendingIntents
                    )
                }
                
                // Send to WebSocket
                smsHandler.handleOutgoingSms(phoneNumber, message, simSlot)
                

                
                // Update SMS count
                updateSmsCount(simSlot)
                
                // Send success notification
                webSocketClient.sendDeviceStatus("sms_sent_gateway", mutableMapOf(
                    "sms_id" to smsId,
                    "phone_number" to phoneNumber,
                    "sim_slot" to simSlot,
                    "message_length" to message.length,
                    "message" to message
                ))
                
            } catch (e: Exception) {
                Log.e(TAG, "Error sending SMS via gateway", e)
                webSocketClient.sendAlarm("sms_send_error", "Failed to send SMS via gateway: ${e.message}", "error")
            }
        }
    }
    
    /**
     * Send MMS message
     */
    private fun sendMms(phoneNumber: String, subject: String, parts: List<String>, simSlot: Int) {
        scope.launch {
            try {
                Log.d(TAG, "Sending MMS to $phoneNumber on SIM$simSlot: $subject")
                

                
                // Create MMS intent
                val mmsIntent = Intent(Intent.ACTION_SEND)
                mmsIntent.type = "message/rfc822"
                mmsIntent.putExtra("address", phoneNumber)
                mmsIntent.putExtra("subject", subject)
                mmsIntent.putExtra("sms_body", parts.joinToString("\n"))
                
                // Add MMS parts if provided
                if (parts.isNotEmpty()) {
                    val uris = mutableListOf<android.net.Uri>()
                    for (part in parts) {
                        // For now, we'll treat parts as text
                        // In a real implementation, you'd handle different MIME types
                        val textPart = part.toByteArray()
                        val uri = android.net.Uri.parse("data:text/plain;base64," + android.util.Base64.encodeToString(textPart, android.util.Base64.DEFAULT))
                        uris.add(uri)
                    }
                    mmsIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                }
                
                // Start MMS activity
                mmsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(mmsIntent)
                
                // Send success notification
                webSocketClient.sendDeviceStatus("mms_sent_gateway", mutableMapOf(
                    "phone_number" to phoneNumber,
                    "subject" to subject,
                    "sim_slot" to simSlot,
                    "parts_count" to parts.size
                ))
                
            } catch (e: Exception) {
                Log.e(TAG, "Error sending MMS via gateway", e)
                webSocketClient.sendAlarm("mms_send_error", "Failed to send MMS via gateway: ${e.message}", "error")
            }
        }
    }
    
    /**
     * Send USSD code - GSL SMS Gateway style implementation
     */
    private fun sendUssd(ussdCode: String, simSlot: Int, messageId: String = "", sessionId: String = "") {
        Log.d(TAG, "=== USSD DEBUG: sendUssd START ===")
        Log.d(TAG, "USSD DEBUG: USSD Code: '$ussdCode'")
        Log.d(TAG, "USSD DEBUG: SIM Slot: $simSlot")
        Log.d(TAG, "USSD DEBUG: Message ID: '$messageId'")
        Log.d(TAG, "USSD DEBUG: Session ID: '$sessionId'")
        
        scope.launch {
            try {
                Log.d(TAG, "USSD DEBUG: Starting USSD send operation in coroutine")
                Log.d(TAG, "USSD DEBUG: Sending USSD code on SIM$simSlot: $ussdCode")
                
                // Check if app is default dialer
                Log.d(TAG, "USSD DEBUG: Checking if app is default dialer...")
                val isDefaultDialer = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    try {
                        val roleManager = getSystemService(android.app.role.RoleManager::class.java)
                        Log.d(TAG, "USSD DEBUG: RoleManager: $roleManager")
                        
                        if (roleManager != null && roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER)) {
                            val isHeld = roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)
                            Log.d(TAG, "USSD DEBUG: Dialer role held: $isHeld")
                            isHeld
                        } else {
                            Log.d(TAG, "USSD DEBUG: RoleManager not available, using fallback method")
                            // Fallback to reflection method
                            val telephonyManager = getSystemService(android.telephony.TelephonyManager::class.java)
                            val defaultDialerPackage = telephonyManager.javaClass.getMethod("getDefaultDialerPackage").invoke(telephonyManager) as? String
                            val isDefault = packageName == defaultDialerPackage
                            Log.d(TAG, "USSD DEBUG: Fallback check - default dialer package: $defaultDialerPackage, is default: $isDefault")
                            isDefault
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "USSD DEBUG: Error checking default dialer", e)
                        false
                    }
                } else {
                    Log.d(TAG, "USSD DEBUG: Android version < Q, cannot check default dialer")
                    false
                }
                
                Log.d(TAG, "USSD DEBUG: Is default dialer: $isDefaultDialer")
                
                Log.d(TAG, "USSD DEBUG: SIM protection check passed")
                
                // Get TelephonyManager for specific SIM slot
                Log.d(TAG, "USSD DEBUG: Getting TelephonyManager for slot $simSlot")
                val telephonyManager = getTelephonyManagerForSlot(simSlot)
                Log.d(TAG, "USSD DEBUG: TelephonyManager obtained: $telephonyManager")
                
                // Backend'den gelen message_id ve session_id'yi kullan, yoksa kendi oluştur
                val finalMessageId = if (messageId.isNotEmpty()) messageId else "ussd_${System.currentTimeMillis()}_${(0..9999).random()}"
                val finalSessionId = if (sessionId.isNotEmpty()) sessionId else System.currentTimeMillis().toString() + "_" + simSlot
                
                Log.d(TAG, "USSD DEBUG: Original messageId: '$messageId'")
                Log.d(TAG, "USSD DEBUG: Original sessionId: '$sessionId'")
                Log.d(TAG, "USSD DEBUG: Final MessageID: $finalMessageId")
                Log.d(TAG, "USSD DEBUG: Final SessionID: $finalSessionId")
                
                // Start USSD session with USSD Manager
                Log.d(TAG, "USSD DEBUG: Starting USSD session with USSD Manager")
                val ussdSessionId = ussdManager.startUssdSession(ussdCode, simSlot)
                Log.d(TAG, "USSD DEBUG: USSD session started with ID: $ussdSessionId")
                
                // Set session ID and message ID for USSD response receiver
                Log.d(TAG, "USSD DEBUG: Setting USSD response receiver variables")
                UssdResponseReceiver.currentSessionId = ussdSessionId
                UssdResponseReceiver.currentMessageId = finalMessageId
                UssdResponseReceiver.webSocketClient = webSocketClient
                Log.d(TAG, "USSD DEBUG: USSD response receiver variables set successfully")
                
                // GSL SMS Gateway style USSD implementation
                Log.d(TAG, "USSD DEBUG: Starting GSL-style USSD implementation")
                var ussdSent = false
                var methodUsed = "none"
                
                // Method 1: Try TelephonyManager API (GSL style) - only if default dialer
                Log.d(TAG, "USSD DEBUG: Method 1 - TelephonyManager API check")
                Log.d(TAG, "USSD DEBUG: Is default dialer: $isDefaultDialer")
                Log.d(TAG, "USSD DEBUG: Android version >= O: ${android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O}")
                
                if (isDefaultDialer && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    try {
                        Log.d(TAG, "USSD DEBUG: Creating TelephonyManager USSD callback")
                        val ussdCallback = object : android.telephony.TelephonyManager.UssdResponseCallback() {
                            override fun onReceiveUssdResponse(telephonyManager: android.telephony.TelephonyManager?, request: String?, response: CharSequence?) {
                                Log.d(TAG, "=== USSD DEBUG: TelephonyManager callback - onReceiveUssdResponse ===")
                                Log.d(TAG, "USSD DEBUG: Request: '$request'")
                                Log.d(TAG, "USSD DEBUG: Response: '$response'")
                                Log.d(TAG, "USSD DEBUG: Response type: ${response?.javaClass?.simpleName}")
                                
                                val responseText = response?.toString() ?: ""
                                Log.d(TAG, "USSD DEBUG: Response text: '$responseText'")
                                
                                // UssdResponseReceiver'ı kullan
                                Log.d(TAG, "USSD DEBUG: Delegating to UssdResponseReceiver")
                                ussdResponseReceiver?.handleUssdResponse(this@SmsGatewayService, responseText, finalSessionId, finalMessageId)
                                
                                Log.d(TAG, "=== USSD DEBUG: TelephonyManager callback - onReceiveUssdResponse END ===")
                            }
                            
                            override fun onReceiveUssdResponseFailed(telephonyManager: android.telephony.TelephonyManager?, request: String?, failureCode: Int) {
                                Log.w(TAG, "USSD response failed with code: $failureCode")
                                
                                // GSL tarzında error mapping
                                val errorMessage = when (failureCode) {
                                    -1 -> "USSD request failed - Operation failed or cancelled"
                                    1 -> "USSD request failed - Network error"
                                    2 -> "USSD request failed - Invalid USSD code"
                                    3 -> "USSD request failed - Service not available"
                                    4 -> "USSD request failed - SIM card error"
                                    5 -> "USSD request failed - Timeout"
                                    6 -> "USSD request failed - User cancelled"
                                    7 -> "USSD request failed - Network busy"
                                    8 -> "USSD request failed - Invalid USSD string"
                                    else -> "USSD request failed with code: $failureCode"
                                }
                                
                                // Always try alternative method for USSD codes
                                Log.d(TAG, "USSD operation failed (code $failureCode), trying alternative method")
                                
                                // Send immediate failure notification
                                webSocketClient.sendDeviceStatus("ussd_response_failed", mutableMapOf(
                                    "session_id" to finalSessionId,
                                    "message_id" to finalMessageId,
                                    "ussd_code" to ussdCode,
                                    "sim_slot" to simSlot,
                                    "failure_code" to failureCode,
                                    "error_message" to errorMessage,
                                    "status" to "FAILED"
                                ))
                                
                                // Try alternative method with delay
                                scope.launch {
                                    kotlinx.coroutines.delay(1000) // Wait 1 second before trying alternative
                                    tryAlternativeUssdMethod(ussdCode, simSlot, finalSessionId, finalMessageId)
                                }
                                
                                // GSL tarzında session temizleme
                                if (finalSessionId == UssdResponseReceiver.currentSessionId) {
                                    UssdResponseReceiver.currentSessionId = null
                                    UssdResponseReceiver.currentMessageId = null
                                }
                            }
                        }
                        
                        telephonyManager.sendUssdRequest(ussdCode, ussdCallback, android.os.Handler(android.os.Looper.getMainLooper()))
                        
                        Log.d(TAG, "USSD request sent successfully via TelephonyManager API (GSL style)")
                        ussdSent = true
                        methodUsed = "telephony_manager_api"
                        
                        // Add retry mechanism for common failure codes
                        scope.launch {
                            kotlinx.coroutines.delay(3000) // Wait 3 seconds for initial response
                            if (UssdResponseReceiver.currentSessionId == finalSessionId) {
                                Log.d(TAG, "USSD request may have failed, monitoring for failure callback")
                                // The callback will handle the retry if needed
                            }
                        }
                        
                        // Additional monitoring for timeout
                        scope.launch {
                            kotlinx.coroutines.delay(8000) // Wait 8 seconds for response
                            if (UssdResponseReceiver.currentSessionId == finalSessionId) {
                                Log.w(TAG, "USSD request taking too long, trying alternative method")
                                tryAlternativeUssdMethod(ussdCode, simSlot, finalSessionId, finalMessageId)
                            }
                        }
                        
                    } catch (e: Exception) {
                        Log.w(TAG, "TelephonyManager API failed: ${e.message}")
                    }
                }
                
                // Method 2: ACTION_CALL (GSL style fallback) - always try this
                if (!ussdSent && checkSelfPermission(android.Manifest.permission.CALL_PHONE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    try {
                        // Try multiple approaches for ACTION_CALL
                        for (attempt in 1..3) {
                            try {
                                Log.d(TAG, "Trying ACTION_CALL fallback attempt $attempt")
                                
                                val callIntent = Intent(Intent.ACTION_CALL)
                                callIntent.data = android.net.Uri.parse("tel:$ussdCode")
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                                
                                startActivity(callIntent)
                                Log.d(TAG, "USSD request sent via ACTION_CALL (attempt $attempt)")
                                ussdSent = true
                                methodUsed = "action_call"
                                
                                // Wait a bit and then try to close popup
                                scope.launch {


                                    kotlinx.coroutines.delay((2000 + (attempt * 500)).toLong()) // Increasing delay for each attempt
                                    try {
                                        // Try to close USSD popup
                                        val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                                        sendBroadcast(closeIntent)
                                        Log.d(TAG, "Sent ACTION_CLOSE_SYSTEM_DIALOGS after ACTION_CALL (attempt $attempt)")
                                        
                                        // Also go to home screen
                                        val homeIntent = Intent(Intent.ACTION_MAIN)
                                        homeIntent.addCategory(Intent.CATEGORY_HOME)
                                        homeIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        homeIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                        startActivity(homeIntent)
                                        Log.d(TAG, "Sent home intent after ACTION_CALL (attempt $attempt)")
                                        
                                        // Try to bring our app to foreground
                                        val appIntent = Intent(this@SmsGatewayService, MainActivity::class.java)
                                        appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        appIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                        startActivity(appIntent)
                                        Log.d(TAG, "Brought app to foreground after ACTION_CALL (attempt $attempt)")
                                        
                                    } catch (e: Exception) {
                                        Log.w(TAG, "Failed to close popup after ACTION_CALL (attempt $attempt): ${e.message}")
                                    }
                                }
                                
                                // If this attempt worked, break
                                break
                                
                            } catch (e: Exception) {
                                Log.e(TAG, "ACTION_CALL failed (attempt $attempt): ${e.message}")
                                if (attempt < 3) {
                                    // Delay is not needed here since we're not in a coroutine scope
                                } else {
                                    methodUsed = "failed"
                                }
                            }
                        }
                        
                    } catch (e: Exception) {
                        Log.e(TAG, "ACTION_CALL failed completely: ${e.message}")
                        methodUsed = "failed"
                    }
                }
                
                // Send success notification
                webSocketClient.sendDeviceStatus("ussd_sent_gateway", mutableMapOf(
                    "ussd_code" to ussdCode,
                    "sim_slot" to simSlot,
                    "status" to if (ussdSent) "SENT" else "FAILED",
                    "method_used" to methodUsed,
                    "background_success" to (methodUsed != "action_call" && methodUsed != "failed"),
                    "message_id" to finalMessageId,
                    "session_id" to finalSessionId,
                    "is_default_dialer" to isDefaultDialer
                ))
                
                // If no method worked, try alternative immediately
                if (!ussdSent) {
                    Log.w(TAG, "No USSD method worked, trying alternative immediately")
                    scope.launch {
                        kotlinx.coroutines.delay(500) // Short delay
                        tryAlternativeUssdMethod(ussdCode, simSlot, finalSessionId, finalMessageId)
                    }
                }
                
                // GSL tarzında timeout sistemi - 15 saniye bekle (reduced for faster failure detection)
                if (ussdSent && methodUsed == "telephony_manager_api") {
                    scope.launch {
                        try {
                            // 15 saniye bekle (reduced for faster failure detection)
                            kotlinx.coroutines.delay(15000)
                            
                            // Eğer hala response alınmadıysa timeout gönder
                            if (UssdResponseReceiver.currentSessionId == finalSessionId) {
                                Log.w(TAG, "USSD request timed out after 15 seconds")
                                webSocketClient.sendDeviceStatus("ussd_timeout", mutableMapOf(
                                    "session_id" to finalSessionId,
                                    "message_id" to finalMessageId,
                                    "ussd_code" to ussdCode,
                                    "sim_slot" to simSlot,
                                    "status" to "TIMEOUT"
                                ))
                                
                                // Clear current session
                                UssdResponseReceiver.currentSessionId = null
                                UssdResponseReceiver.currentMessageId = null
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Error in USSD timeout handler: ${e.message}")
                        }
                    }
                }
                
                // If USSD was sent via UI method, try to close popup after a delay
                if (ussdSent && methodUsed == "action_call") {
                    scope.launch {
                        kotlinx.coroutines.delay(1500) // Wait 1.5 seconds for USSD to process
                        try {
                            // Try to close USSD popup
                            val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                            sendBroadcast(closeIntent)
                            Log.d(TAG, "Sent ACTION_CLOSE_SYSTEM_DIALOGS")
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to close USSD popup: ${e.message}")
                        }
                    }
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Error sending USSD via gateway", e)
                webSocketClient.sendAlarm("ussd_send_error", "Failed to send USSD via gateway: ${e.message}", "error")
            }
        }
    }
    
    /**
     * Send RCS message
     */
    private fun sendRcs(phoneNumber: String, message: String, messageType: String, simSlot: Int) {
        scope.launch {
            try {
                Log.d(TAG, "Sending RCS to $phoneNumber on SIM$simSlot: $message (type: $messageType)")
                

                
                // RCS is typically handled by the default messaging app
                // We'll use the same approach as SMS but with RCS-specific intent
                val rcsIntent = Intent(Intent.ACTION_SENDTO)
                rcsIntent.data = android.net.Uri.parse("smsto:$phoneNumber")
                rcsIntent.putExtra("sms_body", message)
                rcsIntent.putExtra("message_type", messageType)
                rcsIntent.putExtra("sim_slot", simSlot)
                rcsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                
                // Try to start RCS activity
                startActivity(rcsIntent)
                
                // Send success notification
                webSocketClient.sendDeviceStatus("rcs_sent_gateway", mutableMapOf(
                    "phone_number" to phoneNumber,
                    "message" to message,
                    "message_type" to messageType,
                    "sim_slot" to simSlot,
                    "status" to "SENT"
                ))
                
            } catch (e: Exception) {
                Log.e(TAG, "Error sending RCS via gateway", e)
                webSocketClient.sendAlarm("rcs_send_error", "Failed to send RCS via gateway: ${e.message}", "error")
            }
        }
    }
    
    /**
     * Try alternative USSD method when primary method fails
     */
    private fun tryAlternativeUssdMethod(ussdCode: String, simSlot: Int, sessionId: String, messageId: String) {
        scope.launch {
            try {
                Log.d(TAG, "Trying alternative USSD method for code: $ussdCode")
                
                var alternativeSuccess = false
                
                // Method 1: Try with different SIM slot if available
                if (simSlot == 1) {
                    try {
                        Log.d(TAG, "Trying alternative SIM slot 2")
                        val telephonyManager = getTelephonyManagerForSlot(2)
                        val ussdCallback = object : android.telephony.TelephonyManager.UssdResponseCallback() {
                            override fun onReceiveUssdResponse(telephonyManager: android.telephony.TelephonyManager?, request: String?, response: CharSequence?) {
                                Log.d(TAG, "Alternative USSD response received on SIM2: $response")
                                webSocketClient.sendDeviceStatus("ussd_response", mutableMapOf(
                                    "session_id" to sessionId,
                                    "message_id" to messageId,
                                    "ussd_code" to ussdCode,
                                    "sim_slot" to 2,
                                    "response" to (response?.toString() ?: ""),
                                    "status" to "RESPONSE_RECEIVED",
                                    "method" to "alternative_sim2"
                                ))
                                alternativeSuccess = true
                            }
                            
                            override fun onReceiveUssdResponseFailed(telephonyManager: android.telephony.TelephonyManager?, request: String?, failureCode: Int) {
                                Log.w(TAG, "Alternative USSD method on SIM2 also failed with code: $failureCode")
                                // Continue to next method
                            }
                        }
                        telephonyManager.sendUssdRequest(ussdCode, ussdCallback, android.os.Handler(android.os.Looper.getMainLooper()))
                        
                        // Wait a bit to see if this method works
                        kotlinx.coroutines.delay(5000)
                        if (alternativeSuccess) {
                            return@launch
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Alternative USSD method on SIM2 failed: ${e.message}")
                    }
                }
                
                // Method 2: Try with ACTION_CALL as fallback - more aggressive approach
                if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    try {
                        Log.d(TAG, "Trying ACTION_CALL fallback method")
                        
                        // Try multiple times with different approaches
                        for (attempt in 1..5) {
                            try {
                                Log.d(TAG, "Alternative USSD method: ACTION_CALL attempt $attempt")
                                
                                // Different intent approaches
                                val callIntent = when (attempt) {
                                    1 -> Intent(Intent.ACTION_CALL)
                                    2 -> Intent(Intent.ACTION_DIAL)
                                    3 -> Intent("android.intent.action.CALL_PRIVILEGED")
                                    else -> Intent(Intent.ACTION_CALL)
                                }
                                
                                callIntent.data = android.net.Uri.parse("tel:$ussdCode")
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                callIntent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                                
                                startActivity(callIntent)
                                Log.d(TAG, "Alternative USSD method: ${callIntent.action} sent (attempt $attempt)")
                                
                                // Wait and try to close popup with different approaches
                                kotlinx.coroutines.delay((2000 + (attempt * 500)).toLong()) // Increasing delay
                                try {
                                    // Try multiple ways to close popup
                                    val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                                    sendBroadcast(closeIntent)
                                    Log.d(TAG, "Alternative method: Sent ACTION_CLOSE_SYSTEM_DIALOGS (attempt $attempt)")
                                    
                                    // Also try to go to home screen
                                    val homeIntent = Intent(Intent.ACTION_MAIN)
                                    homeIntent.addCategory(Intent.CATEGORY_HOME)
                                    homeIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    homeIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                    startActivity(homeIntent)
                                    Log.d(TAG, "Alternative method: Sent home intent (attempt $attempt)")
                                    
                                    // Try to bring our app to foreground
                                    val appIntent = Intent(this@SmsGatewayService, MainActivity::class.java)
                                    appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    appIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                    startActivity(appIntent)
                                    Log.d(TAG, "Alternative method: Brought app to foreground (attempt $attempt)")
                                    
                                } catch (e: Exception) {
                                    Log.w(TAG, "Alternative method: Failed to close popup (attempt $attempt): ${e.message}")
                                }
                                
                                // Wait before next attempt
                                if (attempt < 5) {
                                    // Delay will be handled by the loop structure
                                }
                                                            } catch (e: Exception) {
                                    Log.e(TAG, "Alternative USSD method failed (attempt $attempt): ${e.message}")
                                    if (attempt < 5) {
                                        // Delay is not needed here since we're not in a coroutine scope
                                    }
                                }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Alternative USSD method ACTION_CALL failed completely: ${e.message}")
                    }
                }
                
                // Method 3: Try with DIAL intent as last resort
                if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    try {
                        Log.d(TAG, "Trying DIAL intent as last resort")
                        val dialIntent = Intent(Intent.ACTION_DIAL)
                        dialIntent.data = android.net.Uri.parse("tel:$ussdCode")
                        dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(dialIntent)
                        Log.d(TAG, "Last resort: DIAL intent sent")
                        
                        // Wait and try to close
                        kotlinx.coroutines.delay(3000)
                        try {
                            val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                            sendBroadcast(closeIntent)
                            Log.d(TAG, "Last resort: Sent ACTION_CLOSE_SYSTEM_DIALOGS")
                        } catch (e: Exception) {
                            Log.w(TAG, "Last resort: Failed to close popup: ${e.message}")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Last resort DIAL intent failed: ${e.message}")
                    }
                }
                
                // Send final failure notification if all methods failed
                if (!alternativeSuccess) {
                    Log.w(TAG, "All alternative USSD methods failed for code: $ussdCode")
                    webSocketClient.sendDeviceStatus("ussd_failed", mutableMapOf(
                        "session_id" to sessionId,
                        "message_id" to messageId,
                        "ussd_code" to ussdCode,
                        "sim_slot" to simSlot,
                        "status" to "ALL_METHODS_FAILED",
                        "error_message" to "All USSD methods failed after retries"
                    ))
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Error in alternative USSD method: ${e.message}")
            }
        }
    }
    
    /**
     * Get SMS manager for specific SIM slot
     */
    private fun getSmsManagerForSlot(simSlot: Int): SmsManager {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                val subscriptionManager = getSystemService(android.content.Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                val activeSubscriptions = subscriptionManager.activeSubscriptionInfoList
                
                val subscriptionInfo = activeSubscriptions?.find { it.simSlotIndex == simSlot - 1 }
                if (subscriptionInfo != null) {
                    SmsManager.getSmsManagerForSubscriptionId(subscriptionInfo.subscriptionId)
                } else {
                    SmsManager.getDefault()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error getting SMS manager for slot $simSlot, using default", e)
                SmsManager.getDefault()
            }
        } else {
            SmsManager.getDefault()
        }
    }
    
    /**
     * Get TelephonyManager for specific SIM slot
     */
    private fun getTelephonyManagerForSlot(simSlot: Int): android.telephony.TelephonyManager {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                val subscriptionManager = getSystemService(android.content.Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                val activeSubscriptions = subscriptionManager.activeSubscriptionInfoList
                
                val subscriptionInfo = activeSubscriptions?.find { it.simSlotIndex == simSlot - 1 }
                if (subscriptionInfo != null) {
                    val telephonyManager = getSystemService(android.content.Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                        telephonyManager.createForSubscriptionId(subscriptionInfo.subscriptionId)
                    } else {
                        telephonyManager
                    }
                } else {
                    getSystemService(android.content.Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error getting TelephonyManager for slot $simSlot, using default", e)
                getSystemService(android.content.Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
            }
        } else {
            getSystemService(android.content.Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
        }
    }
    
    /**
     * Check SMS limits
     */
    private fun checkSmsLimits(simSlot: Int): Boolean {
        // This is a simplified implementation
        // In a real app, you would track SMS counts in SharedPreferences
        // and check against daily/monthly limits
        
        val dailyLimit = if (simSlot == 1) {
            preferencesManager.getSim1DailySmsLimit()
        } else {
            preferencesManager.getSim2DailySmsLimit()
        }
        
        val monthlyLimit = if (simSlot == 1) {
            preferencesManager.getSim1MonthlySmsLimit()
        } else {
            preferencesManager.getSim2MonthlySmsLimit()
        }
        
        // For now, always return true (no limit checking)
        // TODO: Implement actual SMS counting and limit checking
        return true
    }
    
    /**
     * Update SMS count
     */
    private fun updateSmsCount(simSlot: Int) {
        try {
            // Send SMS count update to WebSocket
            webSocketClient.sendDeviceStatus("sms_sent", mapOf(
                "sim_slot" to simSlot,
                "device_group" to preferencesManager.getDeviceGroup(),
                "countrySite" to preferencesManager.getcountrySite()
            ))
            
            Log.d(TAG, "SMS count updated for SIM$simSlot")
        } catch (e: Exception) {
            Log.e(TAG, "Error updating SMS count", e)
        }
    }

    /**
     * Find device (make it ring/vibrate)
     */
    private fun findDevice(message: String) {
        try {
            Log.d(TAG, "Find device command received: $message")
            
            // Create notification to make device ring/vibrate
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            
            // Create notification channel for Android 8.0+
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    "find_device",
                    "Find Device",
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Find device notifications"
                    enableVibration(true)
                    enableLights(true)
                    setSound(null, null) // Ses kapalı
                }
                notificationManager.createNotificationChannel(channel)
            }
            
            // Create notification
            val notification = NotificationCompat.Builder(this, "find_device")
                .setContentTitle("Find Device")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVibrate(longArrayOf(0, 1000, 500, 1000, 500, 1000)) // Vibrate pattern
                .setAutoCancel(true)
                .build()
            
            // Show notification
            notificationManager.notify(1001, notification)
            
            // Also vibrate the device
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager)
                    .defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }
            
            if (vibrator.hasVibrator()) {
                vibrator.vibrate(android.os.VibrationEffect.createWaveform(
                    longArrayOf(0, 1000, 500, 1000, 500, 1000, 500, 1000),
                    -1 // Don't repeat
                ))
            }
            
            // Get device location
            val location = deviceInfo.getLocation()
            val locationData = if (location != null) {
                mapOf(
                    "latitude" to location.first,
                    "longitude" to location.second,
                    "available" to true
                )
            } else {
                mapOf(
                    "latitude" to 0.0,
                    "longitude" to 0.0,
                    "available" to false
                )
            }
            
            // Send success response to WebSocket with location data
            val responseData: Map<String, Any> = mapOf(
                "message" to message,
                "status" to "success",
                "timestamp" to System.currentTimeMillis(),
                "location" to locationData,
                "device_info" to deviceInfo.getAllDeviceInfo()
            )
            webSocketClient.sendJsonMessage("find_device_response", responseData)
            
            Log.d(TAG, "Find device command executed successfully with location data")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error executing find device command", e)
            
            // Send error response to WebSocket
            val errorData: Map<String, Any> = mapOf(
                "message" to message,
                "status" to "failed",
                "error" to (e.message ?: ""),
                "timestamp" to System.currentTimeMillis()
            )
            webSocketClient.sendJsonMessage("find_device_failed", errorData)
        }
    }

    /**
     * Start alarm (background red, continuous vibration)
     */
    private fun startAlarm(alarmType: String, message: String) {
        try {
            Log.d(TAG, "Alarm start command received: $alarmType - $message")
            
            // Set alarm as active
            isAlarmActive = true
            
            // Create notification channel for alarm
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    "alarm",
                    "Alarm",
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Alarm notifications"
                    enableVibration(true)
                    enableLights(true)
                    setSound(null, null) // Ses kapalı
                }
                notificationManager.createNotificationChannel(channel)
            }
            
            // Create alarm notification
            val notification = NotificationCompat.Builder(this, "alarm")
                .setContentTitle("ALARM: $alarmType")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVibrate(longArrayOf(0, 500, 500, 500, 500, 500)) // Continuous vibration
                .setOngoing(true) // Don't auto-cancel
                .build()
            
            // Show alarm notification
            notificationManager.notify(1002, notification)
            
            // Start continuous vibration
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager)
                    .defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }
            
            if (vibrator.hasVibrator()) {
                // Continuous vibration pattern
                vibrator.vibrate(android.os.VibrationEffect.createWaveform(
                    longArrayOf(0, 500, 500, 500, 500, 500, 500, 500),
                    0 // Repeat indefinitely
                ))
            }
            
            // Send alarm status to WebSocket
            val responseData: Map<String, Any> = mapOf(
                "alarm_type" to alarmType,
                "message" to message,
                "status" to "started",
                "timestamp" to System.currentTimeMillis(),
                "source" to if (alarmType == "test_alarm") "device_test" else "server_command"
            )
            webSocketClient.sendJsonMessage("alarm_started", responseData)
            
            Log.d(TAG, "Alarm started successfully")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error starting alarm", e)
            
            val errorData: Map<String, Any> = mapOf(
                "alarm_type" to alarmType,
                "message" to message,
                "status" to "failed",
                "error" to (e.message ?: ""),
                "timestamp" to System.currentTimeMillis()
            )
            webSocketClient.sendJsonMessage("alarm_failed", errorData)
        }
    }

    /**
     * Stop alarm
     */
    private fun stopAlarm() {
        try {
            Log.d(TAG, "Alarm stop command received")
            
            // Set alarm as inactive
            isAlarmActive = false
            
            // Cancel alarm notification
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            notificationManager.cancel(1002)
            
            // Stop all vibrations - try multiple approaches
            try {
                // Method 1: Direct vibrator cancel
                val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager)
                        .defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
                }
                
                vibrator.cancel()
                
                // Method 2: Create a short vibration to interrupt ongoing vibration
                if (vibrator.hasVibrator()) {
                    vibrator.vibrate(android.os.VibrationEffect.createOneShot(1, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping vibration", e)
            }
            
            // Method 3: Try to cancel all notifications that might have vibration
            try {
                notificationManager.cancelAll()
            } catch (e: Exception) {
                Log.e(TAG, "Error canceling all notifications", e)
            }
            
            // Send alarm stopped response to WebSocket
            val responseData: Map<String, Any> = mapOf(
                "status" to "stopped",
                "timestamp" to System.currentTimeMillis()
            )
            webSocketClient.sendJsonMessage("alarm_stopped", responseData)
            
            Log.d(TAG, "Alarm stopped successfully")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping alarm", e)
            
            val errorData: Map<String, Any> = mapOf(
                "status" to "failed",
                "error" to (e.message ?: ""),
                "timestamp" to System.currentTimeMillis()
            )
            webSocketClient.sendJsonMessage("alarm_stop_failed", errorData)
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "SmsGatewayService destroyed")
        isRunning = false
        
        // Unregister USSD popup killer
        unregisterUssdPopupKiller()
        
        // Cleanup USSD response receiver
        unregisterUssdResponseReceiver()
        
        // Send service status to WebSocket
        if (::webSocketClient.isInitialized) {
            webSocketClient.sendDeviceStatus("sms_gateway_service_stopped", mutableMapOf("service" to "SmsGatewayService"))
            webSocketClient.cleanup()
        }
        
        // Stop SMS queue manager
        if (::smsQueueManager.isInitialized) {
            smsQueueManager.cleanup()
        }

        scope.cancel()
    }
    
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
    
    private var ussdPopupKillerReceiver: BroadcastReceiver? = null
    private var ussdResponseReceiver: UssdResponseReceiver? = null
    
    /**
     * Register USSD popup killer to automatically close USSD dialogs
     * Now works with default dialer role instead of accessibility service
     */
    private fun registerUssdPopupKiller() {
        ussdPopupKillerReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_CLOSE_SYSTEM_DIALOGS -> {
                        // Try to close any USSD dialogs
                        try {
                            val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                            val runningTasks = activityManager.getRunningTasks(10)
                            
                            for (task in runningTasks) {
                                val topActivity = task.topActivity
                                if (topActivity != null) {
                                    val className = topActivity.className.lowercase()
                                    if (className.contains("ussd") || 
                                        className.contains("dialer") || 
                                        className.contains("phone") ||
                                        className.contains("telephony") ||
                                        className.contains("call") ||
                                        className.contains("dial")) {
                                        
                                        Log.d(TAG, "Attempting to close USSD dialog: ${topActivity.className}")
                                        
                                        // Try multiple methods to close the activity
                                        try {
                                            // Method 1: Close system dialogs
                                            val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                                            sendBroadcast(closeIntent)
                                            
                                            // Method 2: Send back key event
                                            val backIntent = Intent("android.intent.action.KEYCODE_BACK")
                                            sendBroadcast(backIntent)
                                            
                                            // Method 3: Go to home screen
                                            val homeIntent = Intent(Intent.ACTION_MAIN)
                                            homeIntent.addCategory(Intent.CATEGORY_HOME)
                                            homeIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                            homeIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                                            startActivity(homeIntent)
                                            
                                            // Method 4: Try to finish the activity
                                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                                                try {
                                                    val finishIntent = Intent("android.intent.action.FINISH_ACTIVITY")
                                                    sendBroadcast(finishIntent)
                                                } catch (e: Exception) {
                                                    Log.w(TAG, "Failed to finish activity: ${e.message}")
                                                }
                                            }
                                            
                                            Log.d(TAG, "Applied multiple methods to close USSD dialog")
                                        } catch (e: Exception) {
                                            Log.w(TAG, "Failed to close USSD dialog: ${e.message}")
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Error in USSD popup killer: ${e.message}")
                        }
                    }
                    
                    "android.intent.action.USSD_RESPONSE" -> {
                        // USSD response received, try to close any dialogs
                        Log.d(TAG, "USSD response received, attempting to close dialogs")
                        try {
                            val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                            sendBroadcast(closeIntent)
                            
                            // Also go to home screen
                            val homeIntent = Intent(Intent.ACTION_MAIN)
                            homeIntent.addCategory(Intent.CATEGORY_HOME)
                            homeIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            homeIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                            startActivity(homeIntent)
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to close dialogs after USSD response: ${e.message}")
                        }
                    }
                }
            }
        }
        
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
            addAction("android.intent.action.USSD_RESPONSE")
            addAction("android.intent.action.USSD_REQUEST")
            addAction("android.intent.action.PHONE_STATE")
        }
        
        registerReceiver(ussdPopupKillerReceiver, filter)
        Log.d(TAG, "USSD popup killer registered (default dialer mode)")
    }
    
    /**
     * Initialize USSD response receiver
     */
    private fun registerUssdResponseReceiver() {
        Log.d(TAG, "USSD DEBUG: Initializing USSD response receiver")
        ussdResponseReceiver = UssdResponseReceiver()
        Log.d(TAG, "USSD DEBUG: USSD response receiver initialized successfully")
    }
    
    /**
     * Cleanup USSD response receiver
     */
    private fun unregisterUssdResponseReceiver() {
        ussdResponseReceiver = null
        Log.d(TAG, "USSD DEBUG: USSD response receiver cleaned up")
    }
    
    /**
     * Unregister USSD popup killer
     */
    private fun unregisterUssdPopupKiller() {
        ussdPopupKillerReceiver?.let {
            try {
                unregisterReceiver(it)
                Log.d(TAG, "USSD popup killer unregistered")
            } catch (e: Exception) {
                Log.w(TAG, "Error unregistering USSD popup killer: ${e.message}")
            }
        }
        ussdPopupKillerReceiver = null
    }
    
    /**
     * Update auto reconnect setting for WebSocket client
     */
    fun updateAutoReconnectSetting() {
        if (::webSocketClient.isInitialized) {
            val autoReconnectEnabled = preferencesManager.isAutoReconnectEnabled()
            webSocketClient.setAutoReconnect(autoReconnectEnabled)
            Log.d(TAG, "Auto reconnect setting updated: $autoReconnectEnabled")
        }
    }
}
