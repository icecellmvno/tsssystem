package com.tsimcloud.tsimcloudclient.utils

import android.util.Log
import kotlinx.coroutines.*
import okhttp3.*
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import android.content.Context
import java.util.concurrent.atomic.AtomicLong

class WebSocketClient(
    private val context: Context,
    private val url: String,
    private val apiKey: String,
    private val deviceInfo: DeviceInfo
) {

    companion object {
        private const val TAG = "WebSocketClient"
        private const val RECONNECT_DELAY_MS = 5000L // Reduced from 10s to 5s
        private const val HEARTBEAT_INTERVAL_MS = 10000L // Keep 10s heartbeat
        private const val CONNECTION_HEALTH_CHECK_MS = 15000L // New: Check connection health every 15s
        private const val MAX_RECONNECT_ATTEMPTS = 999999 // Unlimited retry attempts
        private const val CONNECTION_TIMEOUT_MS = 30000L // New: 30s connection timeout
        private const val HEARTBEAT_TIMEOUT_MS = 20000L // New: 20s heartbeat timeout
    }

    private var webSocket: WebSocket? = null
    private var client: OkHttpClient? = null
    private var isConnected = false
    private var shouldReconnect = true
    private var reconnectJob: Job? = null
    private var heartbeatJob: Job? = null
    private var healthCheckJob: Job? = null // New: Connection health check job
    private var reconnectAttempts = 0
    private var lastReconnectTime = 0L
    private var lastHeartbeatTime = AtomicLong(0L) // New: Track last heartbeat time
    private var lastPongTime = AtomicLong(0L) // New: Track last pong response time
    
    // Device group settings (will be updated from backend)
    private var deviceGroupSettings: Map<String, Any>? = null

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val preferencesManager = PreferencesManager(context)

    // Callbacks
    var onConnected: (() -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    var onMessage: ((String) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var onConnectionHealthChanged: ((Boolean) -> Unit)? = null // New: Connection health callback

    private val webSocketListener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d(TAG, "WebSocket connected")
            isConnected = true
            shouldReconnect = getAutoReconnectSetting()
            // reconnectAttempts = 0 // Counter'ı sıfırlama - LIMITSIZ RETRY için
            lastReconnectTime = 0L
            lastHeartbeatTime.set(System.currentTimeMillis())
            lastPongTime.set(System.currentTimeMillis())
            
            startHeartbeat()
            startConnectionHealthCheck() // New: Start health monitoring
            onConnected?.invoke()
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            Log.d(TAG, "Received message: $text")
            try {
                val json = JSONObject(text)
                val messageType = json.optString("type")
                
                when (messageType) {
                    "connection_established" -> {
                        val settings = json.optJSONObject("data")
                        if (settings != null) {
                            preferencesManager.saveSettingsFromJson(settings)
                            deviceGroupSettings = jsonObjectToMap(settings)
                            Log.d(TAG, "Device group settings saved: $deviceGroupSettings")
                        }
                    }
                    "pong" -> {
                        // Update last pong time for connection health monitoring
                        val previousPongTime = lastPongTime.get()
                        lastPongTime.set(System.currentTimeMillis())
                        val timeSinceLastPong = System.currentTimeMillis() - previousPongTime
                        Log.d(TAG, "Pong received, connection health updated. Time since last pong: ${timeSinceLastPong}ms")
                    }
                    "heartbeat_response" -> {
                        // Also accept heartbeat_response as a valid pong for connection health
                        val previousPongTime = lastPongTime.get()
                        lastPongTime.set(System.currentTimeMillis())
                        val timeSinceLastPong = System.currentTimeMillis() - previousPongTime
                        Log.d(TAG, "Heartbeat response received, treating as pong. Time since last pong: ${timeSinceLastPong}ms")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error parsing WebSocket message", e)
            }
            onMessage?.invoke(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            Log.d(TAG, "Received bytes: ${bytes.hex()}")
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.d(TAG, "WebSocket closing: $code / $reason")
            isConnected = false
            stopHeartbeat()
            stopConnectionHealthCheck() // New: Stop health monitoring
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.d(TAG, "WebSocket closed: $code / $reason")
            isConnected = false
            stopHeartbeat()
            stopConnectionHealthCheck() // New: Stop health monitoring
            onDisconnected?.invoke()

            if (shouldReconnect && getAutoReconnectSetting()) {
                scheduleReconnect()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "WebSocket failure", t)
            isConnected = false
            stopHeartbeat()
            stopConnectionHealthCheck() // New: Stop health monitoring
            onError?.invoke("Connection failed: ${t.message}")

            if (shouldReconnect && getAutoReconnectSetting()) {
                scheduleReconnect()
            }
        }
    }

    /**
     * Connect to WebSocket server
     */
    fun connect() {
        if (isConnected) {
            Log.d(TAG, "Already connected")
            return
        }

        try {
            // Create new client for each connection attempt to avoid stale connections
            client = OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS) // Reduced from 60s to 30s
                .readTimeout(60, TimeUnit.SECONDS)   // Reduced from 120s to 60s
                .writeTimeout(30, TimeUnit.SECONDS)  // Reduced from 60s to 30s
                .pingInterval(20, TimeUnit.SECONDS)  // Reduced from 30s to 20s for faster health detection
                .retryOnConnectionFailure(false)     // Disable automatic retry to handle manually
                .build()

            // IMEI'yi al
            val imei = deviceInfo.getIMEI()
            
            // API key ve IMEI'yi URL query parametresi olarak ekle
            val urlWithParams = if (url.contains("?")) {
                "$url&api_key=$apiKey&imei=$imei&type=android&reconnect_attempt=${reconnectAttempts + 1}"
            } else {
                "$url?api_key=$apiKey&imei=$imei&type=android&reconnect_attempt=${reconnectAttempts + 1}"
            }

            val request = Request.Builder()
                .url(urlWithParams)
                .addHeader("Device-Info", deviceInfo.getDeviceInfoAsJson())
                .addHeader("Reconnect-Attempt", (reconnectAttempts + 1).toString())
                .addHeader("Last-Heartbeat", lastHeartbeatTime.get().toString())
                .build()

            webSocket = client?.newWebSocket(request, webSocketListener)
            Log.d(TAG, "Connecting to WebSocket: $urlWithParams")
            Log.d(TAG, "IMEI: $imei, Reconnect attempt: ${reconnectAttempts + 1}")
            
            // Set connection timeout
            scope.launch {
                delay(CONNECTION_TIMEOUT_MS)
                if (!isConnected) {
                    Log.w(TAG, "Connection timeout after ${CONNECTION_TIMEOUT_MS}ms")
                    webSocket?.close(1000, "Connection timeout")
                    onError?.invoke("Connection timeout")
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to connect", e)
            onError?.invoke("Failed to connect: ${e.message}")
        }
    }

    /**
     * Disconnect from WebSocket server
     */
    fun disconnect() {
        Log.d(TAG, "Disconnecting WebSocket")
        shouldReconnect = false
        isConnected = false
        // reconnectAttempts = 0 // Counter'ı sıfırlama - LIMITSIZ RETRY için
        lastReconnectTime = 0L

        stopHeartbeat()
        stopConnectionHealthCheck() // New: Stop health monitoring
        reconnectJob?.cancel()

        webSocket?.close(1000, "Normal closure")
        webSocket = null

        client?.dispatcher?.executorService?.shutdown()
        client = null
    }

    /**
     * Send message to WebSocket server
     */
    fun sendMessage(message: String): Boolean {
        return if (isConnected && webSocket != null) {
            val success = webSocket?.send(message) ?: false
            if (success) {
                Log.d(TAG, "Message sent: $message")
            } else {
                Log.e(TAG, "Failed to send message: $message")
            }
            success
        } else {
            Log.w(TAG, "Cannot send message: not connected")
            false
        }
    }

    /**
     * Send JSON message
     */
    fun sendJsonMessage(type: String, data: Map<String, Any>): Boolean {
        val jsonObject = JSONObject().apply {
            put("type", type)
            put("timestamp", System.currentTimeMillis())
            put("data", JSONObject(data))
        }
        return sendMessage(jsonObject.toString())
    }

    /**
     * Send device status update
     */
    fun sendDeviceStatus(status: String, details: Map<String, Any> = emptyMap()): Boolean {
        val data = mutableMapOf<String, Any>().apply {
            put("status", status)
            put("device_group", deviceInfo.getDeviceGroup())
            put("country_site", deviceInfo.getcountrySite())
            putAll(details)
        }
        return sendJsonMessage("device_status", data)
    }

    /**
     * Send alarm notification
     */
    fun sendAlarm(alarmType: String, message: String, severity: String = "warning"): Boolean {
        val data = mapOf(
            "alarm_type" to alarmType,
            "message" to message,
            "severity" to severity,
            "device_group" to deviceInfo.getDeviceGroup(),
            "country_site" to deviceInfo.getcountrySite()
        )
        return sendJsonMessage("alarm", data)
    }
    
    /**
     * Send alarm resolved notification
     */
    fun sendAlarmResolved(alarmType: String, message: String, severity: String = "info"): Boolean {
        val data = mapOf(
            "alarm_type" to alarmType,
            "message" to message,
            "severity" to severity,
            "device_group" to deviceInfo.getDeviceGroup(),
            "country_site" to deviceInfo.getcountrySite()
        )
        return sendJsonMessage("alarm_resolved", data)
    }

    /**
     * Send SMS log
     */
    fun sendSmsLog(simSlot: Int, phoneNumber: String, message: String, status: String): Boolean {
        val data = mapOf(
            "sim_slot" to simSlot,
            "phone_number" to phoneNumber,
            "message" to message,
            "status" to status,
            "device_group" to deviceInfo.getDeviceGroup(),
            "country_site" to deviceInfo.getcountrySite()
        )
        return sendJsonMessage("sms_log", data)
    }

    /**
     * Send USSD response
     */
    fun sendUssdResponse(sessionId: String, messageId: String, response: String, cleanedResponse: String, status: String, isMenu: Boolean, autoCancel: Boolean): Boolean {
        val data = mapOf(
            "session_id" to sessionId,
            "message_id" to messageId,
            "response" to response,
            "cleaned_response" to cleanedResponse,
            "status" to status,
            "is_menu" to isMenu,
            "auto_cancel" to autoCancel
        )
        return sendJsonMessage("ussd_response", data)
    }

    /**
     * Send USSD response failed
     */
    fun sendUssdResponseFailed(sessionId: String, messageId: String, ussdCode: String, simSlot: Int, failureCode: Int, errorMessage: String, status: String): Boolean {
        val data = mapOf(
            "session_id" to sessionId,
            "message_id" to messageId,
            "ussd_code" to ussdCode,
            "sim_slot" to simSlot,
            "failure_code" to failureCode,
            "error_message" to errorMessage,
            "status" to status
        )
        return sendJsonMessage("ussd_response_failed", data)
    }

    /**
     * Send USSD code received
     */
    fun sendUssdCode(sender: String, ussdCode: String, simSlot: Int): Boolean {
        val data = mapOf(
            "sender" to sender,
            "ussd_code" to ussdCode,
            "sim_slot" to simSlot,
            "device_group" to deviceInfo.getDeviceGroup(),
            "country_site" to deviceInfo.getcountrySite()
        )
        return sendJsonMessage("ussd_code", data)
    }

    /**
     * Send USSD cancelled
     */
    fun sendUssdCancelled(sessionId: String, messageId: String, ussdCode: String, simSlot: Int, status: String, reason: String): Boolean {
        val data = mapOf(
            "session_id" to sessionId,
            "message_id" to messageId,
            "ussd_code" to ussdCode,
            "sim_slot" to simSlot,
            "status" to status,
            "reason" to reason
        )
        return sendJsonMessage("ussd_cancelled", data)
    }

    /**
     * Check if connected
     */
    fun isConnected(): Boolean = isConnected

    /**
     * Get current WebSocket URL
     */
    fun getCurrentUrl(): String = url

    /**
     * Get auto reconnect setting from preferences
     */
    private fun getAutoReconnectSetting(): Boolean {
        return preferencesManager.getAutoReconnect() ?: true // Default olarak true
    }

    /**
     * Set auto reconnect setting
     */
    fun setAutoReconnect(enabled: Boolean) {
        val previousSetting = shouldReconnect
        preferencesManager.saveAutoReconnect(enabled)
        shouldReconnect = enabled
        
        Log.d(TAG, "Auto reconnect setting changed: $previousSetting -> $enabled")
        
        if (!enabled) {
            // Auto reconnect kapatıldıysa mevcut reconnect job'ını iptal et
            reconnectJob?.cancel()
            reconnectAttempts = 0
            lastReconnectTime = 0L
            Log.d(TAG, "Auto reconnect disabled - all reconnect attempts cancelled")
        } else {
            Log.d(TAG, "Auto reconnect enabled")
            
            // Eğer bağlantı kopuksa ve auto reconnect açıldıysa, yeniden bağlanmayı dene
            if (!isConnected && shouldReconnect) {
                Log.d(TAG, "Auto reconnect enabled while disconnected, attempting to reconnect")
                scheduleReconnect()
            }
        }
    }

    /**
     * Get current auto reconnect status
     */
    fun isAutoReconnectEnabled(): Boolean {
        return getAutoReconnectSetting()
    }

    /**
     * Schedule reconnection with enhanced logic
     */
    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        
        // Auto reconnect ayarını kontrol et
        if (!getAutoReconnectSetting()) {
            Log.d(TAG, "Auto reconnect is disabled, skipping reconnection")
            onError?.invoke("Auto reconnect is disabled")
            return
        }
        
        // Reconnect deneme sayısını kontrol et - LIMITSIZ RETRY
        // if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
        //     Log.w(TAG, "Max reconnect attempts reached, stopping reconnection")
        //     shouldReconnect = false
        //     onError?.invoke("Max reconnect attempts reached (${MAX_RECONNECT_ATTEMPTS} attempts)")
        //     return
        // }
        
        // Enhanced exponential backoff with jitter to prevent thundering herd
        val baseDelay = RECONNECT_DELAY_MS * (1 shl reconnectAttempts.coerceAtMost(4)) // Cap exponential growth
        val jitter = (Math.random() * 0.3 + 0.85) // 85-115% of base delay
        val delayMs = (baseDelay * jitter).toLong()
        val currentTime = System.currentTimeMillis()
        
        // Son reconnect'ten bu yana minimum süre geçti mi kontrol et
        if (currentTime - lastReconnectTime < delayMs) {
            Log.d(TAG, "Waiting ${delayMs - (currentTime - lastReconnectTime)}ms before next reconnect attempt...")
            return
        }
        
        Log.d(TAG, "Scheduling reconnect attempt ${reconnectAttempts + 1} in ${delayMs}ms (base: ${baseDelay}ms, jitter: ${String.format("%.2f", jitter)})")
        
        reconnectJob = scope.launch {
            delay(delayMs)
            Log.d(TAG, "Attempting to reconnect... (attempt ${reconnectAttempts + 1})")
            lastReconnectTime = System.currentTimeMillis()
            reconnectAttempts++
            
            // Clear any existing connection state before reconnecting
            clearConnectionState()
            
            connect()
        }
    }

    /**
     * Clear connection state to prevent stale connections
     */
    private fun clearConnectionState() {
        Log.d(TAG, "Clearing connection state before reconnection")
        
        // Close existing connection if any
        webSocket?.let { ws ->
            try {
                ws.close(1000, "Reconnecting")
            } catch (e: Exception) {
                Log.w(TAG, "Error closing existing connection: ${e.message}")
            }
        }
        
        // Reset connection state
        webSocket = null
        isConnected = false
        
        // Stop all background jobs
        stopHeartbeat()
        stopConnectionHealthCheck()
        
        // Reset timestamps
        lastHeartbeatTime.set(0L)
        lastPongTime.set(0L)
        
        Log.d(TAG, "Connection state cleared")
    }

    /**
     * Start heartbeat
     */
    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isConnected) {
                delay(HEARTBEAT_INTERVAL_MS)
                if (isConnected) {
                    sendHeartbeatMessage()
                    // Update last heartbeat time
                    lastHeartbeatTime.set(System.currentTimeMillis())
                }
            }
        }
    }

    /**
     * Send heartbeat message with device information
     */
    private fun sendHeartbeatMessage() {
        Log.d(TAG, "Sending heartbeat message")
        val heartbeatData = mutableMapOf<String, Any>()

        // Device info
        heartbeatData["device_info"] = deviceInfo.getAllDeviceInfo()

        // Battery info
        val batteryLevel = deviceInfo.getBatteryLevel()
        if (batteryLevel != -1) {
            heartbeatData["battery_level"] = batteryLevel
        }
        heartbeatData["battery_status"] = deviceInfo.getBatteryStatus()
        
        // Battery kontrolü - device group ayarlarına göre
        val batteryThreshold = deviceGroupSettings?.get("battery_low_threshold") as? Int ?: 20
        val enableBatteryAlarms = deviceGroupSettings?.get("enable_battery_alarms") as? Boolean ?: true
        
        if (batteryLevel <= batteryThreshold && enableBatteryAlarms) {
            Log.w(TAG, "Battery level is $batteryLevel% (threshold: $batteryThreshold%), sending battery alarm")
            sendAlarm(
                "battery_low", 
                "Device battery is low (battery level: $batteryLevel%, threshold: $batteryThreshold%).", 
                "warning"
            )
        }

        // Signal info
        val signalStrength = deviceInfo.getSignalStrength()
        if (signalStrength != -1) {
            heartbeatData["signal_strength"] = signalStrength
        }
        val signalDbm = deviceInfo.getSignalDbm()
        if (signalDbm != -1) {
            heartbeatData["signal_dbm"] = signalDbm
        }
        heartbeatData["network_type"] = deviceInfo.getNetworkType()

        // Signal kontrolü - device group ayarlarına göre
        val signalThreshold = deviceGroupSettings?.get("signal_low_threshold") as? Int ?: 2
        val enableSignalAlarms = deviceGroupSettings?.get("enable_signal_alarms") as? Boolean ?: false // Signal alarmları devre dışı
        
        // Signal alarm gönderimi kaldırıldı - sadece bilgi log'u
        if (signalStrength <= signalThreshold && enableSignalAlarms) {
            Log.w(TAG, "Signal strength is $signalStrength (threshold: $signalThreshold), but signal alarms are disabled")
        } else if (signalStrength > signalThreshold) {
            Log.i(TAG, "Signal strength is $signalStrength (above threshold: $signalThreshold)")
        }

        // SIM cards info
        val simCards = deviceInfo.getSimCardsForHeartbeat()
        heartbeatData["sim_cards"] = simCards

        // Location info (if available)
        val location = deviceInfo.getLocation()
        if (location != null) {
            heartbeatData["location"] = mapOf(
                "latitude" to location.first,
                "longitude" to location.second
            )
        }

        // Add connection health info to heartbeat
        heartbeatData["connection_health"] = mapOf(
            "last_heartbeat_ms" to lastHeartbeatTime.get(),
            "last_pong_ms" to lastPongTime.get(),
            "connection_duration_ms" to (System.currentTimeMillis() - lastHeartbeatTime.get())
        )

        val success = sendJsonMessage("heartbeat", heartbeatData)
        if (success) {
            Log.d(TAG, "Heartbeat message sent successfully")
        } else {
            Log.w(TAG, "Failed to send heartbeat message")
        }

        // SIM kart değişikliklerini kontrol et (heartbeat sırasında da) - DEVRE DIŞI BIRAKILDI
        // checkSimCardChanges(simCards)
    }
    
    /**
     * Check for SIM card changes and send alarm if needed - DEVRE DIŞI BIRAKILDI
     */
    /*
    private fun checkSimCardChanges(currentSimCards: List<Map<String, Any>>) {
        try {
            val preferencesManager = PreferencesManager(context)
            val lastSimCardsJson = preferencesManager.getLastSimCards()
            
            if (lastSimCardsJson.isNotEmpty()) {
                val currentSimCardsJson = currentSimCards.toString()
                
                if (lastSimCardsJson != currentSimCardsJson) {
                    // SIM kart değişikliği tespit edildi
                    Log.w("WebSocketClient", "SIM card change detected in heartbeat!")
                    
                    // Önceki SIM kart sayısını al
                    val previousSimCardCount = getPreviousSimCardCount(lastSimCardsJson)
                    val currentSimCardCount = currentSimCards.size
                    
                    if (currentSimCardCount > previousSimCardCount) {
                        // SIM kart geri takıldı - alarm durdur
                        Log.i("WebSocketClient", "SIM card reinserted, resolving alarm")
                        sendSimCardChangeAlarmResolved(currentSimCards, lastSimCardsJson)
                    } else {
                        // SIM kart çıkarıldı - alarm gönder
                        sendSimCardChangeAlarm(currentSimCards, lastSimCardsJson)
                    }
                    
                    // Yeni SIM kart bilgilerini kaydet
                    preferencesManager.saveLastSimCards(currentSimCardsJson)
                }
            } else {
                // İlk kez çalışıyor, mevcut SIM kart bilgilerini kaydet
                preferencesManager.saveLastSimCards(currentSimCards.toString())
            }
        } catch (e: Exception) {
            Log.e("WebSocketClient", "Error checking SIM card changes", e)
        }
    }
    */
    
    /**
     * Send SIM card change alarm - DEVRE DIŞI BIRAKILDI
     */
    /*
    private fun sendSimCardChangeAlarm(currentSimCards: List<Map<String, Any>>, previousSimCards: String) {
        try {
            val changeDetails = buildSimCardChangeDetails(currentSimCards, previousSimCards)
            
            val alarmMessage = when {
                currentSimCards.isEmpty() -> "SIM card tray removed - No SIM cards detected"
                currentSimCards.size < getPreviousSimCardCount(previousSimCards) -> "SIM card removed from tray"
                else -> "SIM card configuration changed"
            }
            
            sendAlarm(
                alarmType = "sim_card_change",
                message = "$alarmMessage. $changeDetails",
                severity = "warning"
            )
            
            Log.i("WebSocketClient", "SIM card change alarm sent: $alarmMessage")
        } catch (e: Exception) {
            Log.e("WebSocketClient", "Error sending SIM card change alarm", e)
        }
    }
    */
    
    /**
     * Send SIM card change alarm resolved message - DEVRE DIŞI BIRAKILDI
     */
    /*
    private fun sendSimCardChangeAlarmResolved(currentSimCards: List<Map<String, Any>>, previousSimCards: String) {
        try {
            val changeDetails = buildSimCardChangeDetails(currentSimCards, previousSimCards)
            
            val resolvedMessage = when {
                currentSimCards.isEmpty() -> "SIM card configuration resolved - No SIM cards detected"
                currentSimCards.size > getPreviousSimCardCount(previousSimCards) -> "SIM card reinserted into tray"
                else -> "SIM card configuration resolved"
            }
            
            sendAlarmResolved(
                alarmType = "sim_card_change",
                message = "$resolvedMessage. $changeDetails",
                severity = "info"
            )
            
            Log.i("WebSocketClient", "SIM card change alarm resolved: $resolvedMessage")
        } catch (e: Exception) {
            Log.e("WebSocketClient", "Error sending SIM card change alarm resolved", e)
        }
    }
    */
    
    /**
     * Build SIM card change details - DEVRE DIŞI BIRAKILDI
     */
    /*
    private fun buildSimCardChangeDetails(currentSimCards: List<Map<String, Any>>, previousSimCards: String): String {
        val details = mutableListOf<String>()
        
        if (currentSimCards.isEmpty()) {
            details.add("All SIM cards removed")
        } else {
            details.add("Current SIM cards: ${currentSimCards.size}")
            currentSimCards.forEachIndexed { index, simCard ->
                val carrierName = simCard["carrier_name"] as? String ?: "Unknown"
                val phoneNumber = simCard["phone_number"] as? String ?: "No number"
                details.add("Slot ${index + 1}: $carrierName ($phoneNumber)")
            }
        }
        
        return details.joinToString("; ")
    }
    */
    
    /**
     * Get previous SIM card count - DEVRE DIŞI BIRAKILDI
     */
    /*
    private fun getPreviousSimCardCount(previousSimCards: String): Int {
        return try {
            // Basit bir yöntemle önceki SIM kart sayısını tahmin et
            previousSimCards.count { it == '0' } + previousSimCards.count { it == '1' }
        } catch (e: Exception) {
            0
        }
    }
    */

    /**
     * Start connection health check
     */
    private fun startConnectionHealthCheck() {
        healthCheckJob?.cancel()
        healthCheckJob = scope.launch {
            while (isConnected) {
                delay(CONNECTION_HEALTH_CHECK_MS)
                if (isConnected) {
                    checkConnectionHealth()
                }
            }
        }
    }

    /**
     * Stop connection health check
     */
    private fun stopConnectionHealthCheck() {
        healthCheckJob?.cancel()
        healthCheckJob = null
    }

    /**
     * Check connection health
     */
    private fun checkConnectionHealth() {
        val currentTime = System.currentTimeMillis()
        val lastHeartbeat = lastHeartbeatTime.get()
        val lastPong = lastPongTime.get()

        val timeSinceHeartbeat = currentTime - lastHeartbeat
        val timeSincePong = currentTime - lastPong

        // More lenient health check: if we have recent heartbeat activity, consider connection healthy
        // even if pong responses are delayed (server might be busy)
        val isHealthy = timeSinceHeartbeat < HEARTBEAT_TIMEOUT_MS &&
                       (timeSincePong < CONNECTION_TIMEOUT_MS * 2 || timeSinceHeartbeat < HEARTBEAT_INTERVAL_MS * 2)

        Log.d(TAG, "Connection health check - Heartbeat: ${timeSinceHeartbeat}ms ago, Pong: ${timeSincePong}ms ago, Healthy: $isHealthy")

        if (isHealthy) {
            Log.i(TAG, "Connection is healthy. Last heartbeat: ${timeSinceHeartbeat}ms ago, Last pong: ${timeSincePong}ms ago")
            onConnectionHealthChanged?.invoke(true)
        } else {
            Log.w(TAG, "Connection is unhealthy. Last heartbeat: ${timeSinceHeartbeat}ms ago, Last pong: ${timeSincePong}ms ago")
            onConnectionHealthChanged?.invoke(false)

            // If connection is unhealthy, force a reconnect attempt
            if (shouldReconnect && getAutoReconnectSetting()) {
                Log.w(TAG, "Connection unhealthy, attempting to reconnect")
                scheduleReconnect()
            }
        }
    }

    /**
     * Stop heartbeat
     */
    private fun stopHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    /**
     * Cleanup resources
     */
    fun cleanup() {
        disconnect()
        scope.cancel()
    }
    
    /**
     * Force reconnect (for network state changes)
     */
    fun forceReconnect() {
        Log.d(TAG, "Force reconnect requested")
        // reconnectAttempts = 0 // Counter'ı sıfırlama - LIMITSIZ RETRY için
        lastReconnectTime = 0L
        shouldReconnect = true
        
        if (isConnected) {
            disconnect()
        }
        
        scheduleReconnect()
    }
    
    /**
     * Reset reconnect attempts (for successful connections)
     */
    fun resetReconnectAttempts() {
        reconnectAttempts = 0
        lastReconnectTime = 0L
    }
    
    /**
     * Convert JSONObject to Map<String, Any>
     */
    private fun jsonObjectToMap(jsonObject: JSONObject): Map<String, Any> {
        val map = mutableMapOf<String, Any>()
        val keys = jsonObject.keys()
        
        while (keys.hasNext()) {
            val key = keys.next()
            val value = jsonObject.get(key)
            
            when (value) {
                is JSONObject -> map[key] = jsonObjectToMap(value)
                is org.json.JSONArray -> map[key] = jsonArrayToList(value)
                else -> map[key] = value
            }
        }
        
        return map
    }
    
    /**
     * Convert JSONArray to List<Any>
     */
    private fun jsonArrayToList(jsonArray: org.json.JSONArray): List<Any> {
        val list = mutableListOf<Any>()
        
        for (i in 0 until jsonArray.length()) {
            val value = jsonArray.get(i)
            
            when (value) {
                is JSONObject -> list.add(jsonObjectToMap(value))
                is org.json.JSONArray -> list.add(jsonArrayToList(value))
                else -> list.add(value)
            }
        }
        
        return list
    }
} 